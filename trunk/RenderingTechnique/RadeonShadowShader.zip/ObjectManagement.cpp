#include "ShaderDemo.h"
#include <limits>

VOID CMyD3DApplication::InitObjects() 
{
    for (int light = 0; light < NUM_LIGHTS; light++)
        AddLight();

    for (int object = 0; object < NUM_OBJECTS; object++)
        AddObject();
}

VOID CMyD3DApplication::AddLight()
{
    if (m_dwNumObjects >= MAX_OBJECTS)
        return;

    FLOAT scale = 1;

    scale *= 0.3f;
    m_Light[m_dwNumLights] = m_BaseLight;
    m_CollisionStyle[m_dwNumObjects] = m_CollisionStyle[m_dwNumLights];
    m_pObject[m_dwNumObjects] = m_pObject[m_dwNumLights]; // move object to end
    m_CollisionStyle[m_dwNumLights] = CS_Sphere;
    m_pObject[m_dwNumLights] = new CObject();
    m_pObject[m_dwNumLights]->m_strObjectFile = "POF\\bulb.pof";
    m_pObject[m_dwNumLights]->SetEffectFile( ET_Ambient, "solid.sha" );
    if (m_bAnimateLights)
        m_pObject[m_dwNumLights]->m_fMass           = 1.0f;
    else
        m_pObject[m_dwNumLights]->m_fMass           = 100.0f;
    m_pObject[m_dwNumLights]->m_fAirResistance      = 0.0f;
    m_pObject[m_dwNumLights]->m_fAngAirResistance   = 0.0f;
    m_pObject[m_dwNumLights]->m_fCoeffOfFriction    = 0.0f;
    m_pObject[m_dwNumLights]->m_fRigidity           = 1.0f;
    m_pObject[m_dwNumLights]->m_fAngInertiaOverMass = 0.000001f;
    m_pObject[m_dwNumLights]->Rotate( D3DXVECTOR3( D3DX_PI/2, 0, 0 ) );

    // place first objects in corners
    switch(m_dwNumLights)
    {
    case 0:
        m_pObject[m_dwNumLights]->Translate( D3DXVECTOR3( -ROOM_WIDTH/6.0f, ROOM_HEIGHT-1.0f, -ROOM_DEPTH/6.0f ) );
        break;
    case 1:
        m_pObject[m_dwNumLights]->Translate( D3DXVECTOR3( ROOM_WIDTH/6.0f, ROOM_HEIGHT-1.0f, ROOM_DEPTH/6.0f ) );
        break;
    case 2:
        m_pObject[m_dwNumLights]->Translate( D3DXVECTOR3( -ROOM_WIDTH/6.0f, ROOM_HEIGHT-1.0f, ROOM_DEPTH/6.0f ) );
        break;
    case 3:
        m_pObject[m_dwNumLights]->Translate( D3DXVECTOR3( ROOM_WIDTH/6.0f, ROOM_HEIGHT-1.0f, -ROOM_DEPTH/6.0f ) );
        break;
    default:
        m_pObject[m_dwNumLights]->Translate( D3DXVECTOR3( RandNum(-ROOM_WIDTH/2+1, ROOM_WIDTH/2-1), 
                                                        RandNum(              1, ROOM_HEIGHT-1), 
                                                        RandNum(-ROOM_DEPTH/2+1, ROOM_DEPTH/2-1) ) );
    }

    D3DXMATRIX matObject;
    D3DXMatrixScaling( &matObject, scale, scale, scale );
    D3DXMatrixMultiply( &matObject, &matObject, &m_pObject[m_dwNumLights]->GetTransform());
    m_pObject[m_dwNumLights]->SetTransform( matObject );

    if (m_pd3dDevice) 
    {
        m_pObject[m_dwNumLights]->InitDeviceObjects(m_pd3dDevice, m_pD3D);
        m_pObject[m_dwNumLights]->RestoreDeviceObjects();
        m_pObject[m_dwNumLights]->GetEffect(ET_Ambient)->SetDword("Colr", 0xFFFFFFFF);
    }

    m_dwNumLights++;
    m_dwNumObjects++;
}


VOID CMyD3DApplication::AddObject()
{
    if (m_dwNumObjects >= MAX_OBJECTS)
        return;

    static DWORD sObject = 0;

    FLOAT scale = 1;

    m_pObject[m_dwNumObjects] = new CObject();
    int type = (m_dwNumObjects-m_dwNumLights)%5;
    switch(type)
    {
    default:
    case 0:
        scale = 2.0f;
        m_CollisionStyle[m_dwNumObjects] = CS_Box;
        m_pObject[m_dwNumObjects]->m_strObjectFile = "POF\\crackbox.pof"; 
        m_pObject[m_dwNumObjects]->SetEffectFile(ET_Ambient, "base_ambient.sha");
        m_pObject[m_dwNumObjects]->SetEffectFile(ET_Lit, "bump.sha");
        m_pObject[m_dwNumObjects]->LoadTexture( "tBase", _T("Media\\White.tga"), D3DFMT_DXT1 );
        m_pObject[m_dwNumObjects]->LoadTexture( "tNormal", _T("Media\\WhiteBump.tga"), D3DFMT_A8R8G8B8,  CShaderObject::BuildNormalMap);
        m_pObject[m_dwNumObjects]->Translate(D3DXVECTOR3(0,4,0));
        m_pObject[m_dwNumObjects]->SetVelocity( D3DXVECTOR3( RandNum(-10, 10), RandNum(-10, 10), RandNum(-10, 10) ) );
        m_pObject[m_dwNumObjects]->SetAngVelocity( D3DXVECTOR3( RandNum(-10, 10), RandNum(-10, 10), RandNum(-10, 10) ) );
        m_pObject[m_dwNumObjects]->m_fMass               = 2.0f;
        m_pObject[m_dwNumObjects]->m_fAirResistance      = 0.0f;
        m_pObject[m_dwNumObjects]->m_fAngAirResistance   = 0.0f;
        m_pObject[m_dwNumObjects]->m_fCoeffOfFriction    = 1.0f;
        m_pObject[m_dwNumObjects]->m_fRigidity           = 0.9f;
        m_pObject[m_dwNumObjects]->m_fAngInertiaOverMass = 1.0f;
        break;

    case 1:
    case 2:
        switch (type-1)
        {
            case 0: 
                m_CollisionStyle[m_dwNumObjects] = CS_Sphere;
                m_pObject[m_dwNumObjects]->m_strObjectFile = "POF\\ball.pof"; 
                m_pObject[m_dwNumObjects]->SetEffectFile( ET_Ambient, "base_ambient.sha" );
                m_pObject[m_dwNumObjects]->SetEffectFile( ET_Lit, "bump.sha" );
                m_pObject[m_dwNumObjects]->LoadTexture( "tBase", _T("Media\\Basketball.bmp"), D3DFMT_DXT1 );
                m_pObject[m_dwNumObjects]->LoadTexture( "tNormal", _T("Media\\Basketball_Bump.bmp"), D3DFMT_A8R8G8B8,  CShaderObject::BuildNormalMap);
                break;
            case 1: 
                m_CollisionStyle[m_dwNumObjects] = CS_Box;
                m_pObject[m_dwNumObjects]->m_strObjectFile = "POF\\Chalice.pof"; 
                m_pObject[m_dwNumObjects]->SetEffectFile( ET_Ambient, "base_ambient.sha" );
                m_pObject[m_dwNumObjects]->SetEffectFile( ET_Lit, "bump.sha" );
                m_pObject[m_dwNumObjects]->LoadTexture( "tBase", _T("Media\\ChaliceUV_RGB.bmp"), D3DFMT_DXT1 );
                m_pObject[m_dwNumObjects]->LoadTexture( "tNormal", _T("Media\\ChaliceUV_bump.bmp"), D3DFMT_A8R8G8B8,  CShaderObject::BuildNormalMap);
                break;
        }
        scale *= RandNum(.7f, 1.5f);
        m_pObject[m_dwNumObjects]->Translate( D3DXVECTOR3( RandNum(-ROOM_WIDTH/2+1, ROOM_WIDTH/2-1), 
                                                       RandNum(              1, ROOM_HEIGHT-1), 
                                                       RandNum(-ROOM_DEPTH/2+1, ROOM_DEPTH/2-1) ) );
        m_pObject[m_dwNumObjects]->SetVelocity( D3DXVECTOR3( RandNum(-30, 30), RandNum(-30, 30), RandNum(-30, 30) ) );
        m_pObject[m_dwNumObjects]->SetAngVelocity( D3DXVECTOR3( 0, 10, 0 ) );
        m_pObject[m_dwNumObjects]->m_fMass               = 8.0f;
        m_pObject[m_dwNumObjects]->m_fAirResistance      = 0.1f;
        m_pObject[m_dwNumObjects]->m_fAngAirResistance   = 0.01f;
        m_pObject[m_dwNumObjects]->m_fCoeffOfFriction    = 10000.0f;
        m_pObject[m_dwNumObjects]->m_fRigidity           = 0.9f;
        m_pObject[m_dwNumObjects]->m_fAngInertiaOverMass = 0.1f;
        break;

    case 3:  // Squishy
    case 4:  // Squishy
        switch (type-3)
        {
            case 0: 
                m_CollisionStyle[m_dwNumObjects] = CS_Box;
                m_pObject[m_dwNumObjects]->m_strObjectFile = "POF\\torus.pof"; 
                m_pObject[m_dwNumObjects]->SetEffectFile( ET_Ambient, "base_ambient.sha" );
                m_pObject[m_dwNumObjects]->SetEffectFile( ET_Lit,     "bump.sha" );
                m_pObject[m_dwNumObjects]->LoadTexture( "tBase", _T("Media\\turtlebase.bmp"), D3DFMT_DXT1 );
                m_pObject[m_dwNumObjects]->LoadTexture( "tNormal", _T("Media\\Turtleheight.bmp"), D3DFMT_A8R8G8B8,  CShaderObject::BuildNormalMap);
                break;
            case 1: 
                m_CollisionStyle[m_dwNumObjects] = CS_Sphere;
                m_pObject[m_dwNumObjects]->m_strObjectFile = "POF\\ball.pof"; 
                m_pObject[m_dwNumObjects]->SetEffectFile( ET_Ambient, "earth_ambient.sha" );
                m_pObject[m_dwNumObjects]->SetEffectFile( ET_Lit,     "earth.sha" );
                m_pObject[m_dwNumObjects]->LoadTexture( "tBase", _T("Media\\earth.bmp"), D3DFMT_DXT1 );
                m_pObject[m_dwNumObjects]->LoadTexture( "tEmi", _T("Media\\earthlights.bmp"), D3DFMT_DXT1 );
                break;
        }
        scale *= RandNum(1.0f, 1.5f);
        m_pObject[m_dwNumObjects]->Translate( D3DXVECTOR3( RandNum(-ROOM_WIDTH/2+1, ROOM_WIDTH/2-1), 
                                                       RandNum(              1, ROOM_HEIGHT-1), 
                                                       RandNum(-ROOM_DEPTH/2+1, ROOM_DEPTH/2-1) ) );
        m_pObject[m_dwNumObjects]->SetVelocity( D3DXVECTOR3( RandNum(-30, 30), RandNum(-30, 30), RandNum(-30, 30) ) );
        m_pObject[m_dwNumObjects]->SetSquishVelocity( D3DXVECTOR3(RandNum(-10, 10), RandNum(-10, 10), RandNum(-10, 10)) );
        m_pObject[m_dwNumObjects]->m_fMass               = 0.3f;
        m_pObject[m_dwNumObjects]->m_fAirResistance      = 0.1f;
        m_pObject[m_dwNumObjects]->m_fAngAirResistance   = 0.001f;
        m_pObject[m_dwNumObjects]->m_fCoeffOfFriction    = 10.0f;
        m_pObject[m_dwNumObjects]->m_fRigidity           = 0.7f;
        m_pObject[m_dwNumObjects]->m_fAngInertiaOverMass = 0.1f;
        m_pObject[m_dwNumObjects]->m_fTension            = 40.0f;
        m_pObject[m_dwNumObjects]->m_fDampening          = 5.0f;
        break;
    }

    D3DXMATRIX matObject;
    D3DXMatrixScaling( &matObject, scale, scale, scale );
    D3DXMatrixMultiply( &matObject, &matObject, &m_pObject[m_dwNumObjects]->GetTransform());
    m_pObject[m_dwNumObjects]->SetTransform( matObject );

    if (m_pd3dDevice) 
    {
        m_pObject[m_dwNumObjects]->InitDeviceObjects(m_pd3dDevice, m_pD3D);
        m_pObject[m_dwNumObjects]->RestoreDeviceObjects();
    }

    m_dwNumObjects++;

}

VOID CMyD3DApplication::DeleteLight()
{
    if (m_dwNumLights <= 0)
        return;

    m_dwNumLights--;
    m_dwNumObjects--;
    m_pObject[m_dwNumLights]->InvalidateDeviceObjects();
    m_pObject[m_dwNumLights]->DeleteDeviceObjects();
    SAFE_DELETE(m_pObject[m_dwNumLights]);
    m_pObject[m_dwNumLights] = m_pObject[m_dwNumObjects];
    m_CollisionStyle[m_dwNumLights] = m_CollisionStyle[m_dwNumObjects];
}

VOID CMyD3DApplication::DeleteObject()
{
    if (m_dwNumObjects <= m_dwNumLights)
        return;

    m_dwNumObjects--;
    m_pObject[m_dwNumObjects]->InvalidateDeviceObjects();
    m_pObject[m_dwNumObjects]->DeleteDeviceObjects();
    SAFE_DELETE(m_pObject[m_dwNumObjects]);
}

VOID CMyD3DApplication::KickObjects()
{
    for (int object = m_bAnimateLights ? 0 : m_dwNumLights; object < m_dwNumObjects; object++)
    {
        m_pObject[object]->SetVelocity( D3DXVECTOR3( RandNum(-30, 30), RandNum(-30, 30), RandNum(-30, 30) ) );
        m_pObject[object]->SetAngVelocity( D3DXVECTOR3( RandNum(-30, 30), RandNum(-30, 30), RandNum(-30, 30) ) );
    }
}

//-----------------------------------------------------------------------------
// Name: Physics()
// Desc: Called once per frame to animate the object's motions and do collision
//       detection. Lots of cheats here.
//-----------------------------------------------------------------------------
VOID CMyD3DApplication::Physics()
{
    CObject* pObject;
    FLOAT fElapsedTime = 0;
    FLOAT fTimeSlice;
    int object, wall, object2;
    FLOAT fMaxPenetration = 0.01f;
    FLOAT fMaxTimeSlice   = .01f;
    static FLOAT fMinTimeSlice  = .001f;
    static FLOAT fLastTimeSlice = fMaxTimeSlice;

    // If physics and render time are taking longer than the longest time slice, 
    // lighten up on the precision.
    if (m_fElapsedTime > fMaxTimeSlice && fMinTimeSlice < fMaxTimeSlice)
        fMinTimeSlice *= 2;

    static BOOL bPenetrating = FALSE;
    do {

        // Save the start state
        for (object = 0; object < m_dwNumObjects; object++)
        {
            m_pObject[object]->SaveState();
        }

        // Try to take a time slice approximately the same size as the last slice.
        fTimeSlice = min(fLastTimeSlice, m_fElapsedTime - fElapsedTime);

        // Always try to take bigger jumps on the next slice
        if (fLastTimeSlice*2 <= fMaxTimeSlice)
            fLastTimeSlice *= 2;

        BOOL bDivideSlice;
        do {

            // If the last slice penetrated, but was able to be calculated 
            // without slowing down, beef up the precision.
            if (bPenetrating && m_fElapsedTime <= 1/15.0f && fMinTimeSlice/2.0f > 0.0001f)
                fMinTimeSlice /= 2;

            bPenetrating = bDivideSlice = FALSE;

            // Physics for sphere objects
            for (int object = 0; object < m_dwNumObjects; object++)
            {
                if (m_CollisionStyle[object] == CS_Sphere)
                {
                    pObject = m_pObject[object];

                    if (object >= m_dwNumLights || m_bAnimateLights)
                        pObject->Advance( fTimeSlice );

                    // Collision detect walls
                    D3DXVECTOR3 vCenter, vWallNormals[6];
                    vCenter = pObject->GetWorldCenterOfGravity();
                    for (wall = 0; wall < 6; wall++)
                    {
                        FLOAT fRadius = pObject->GetWorldRadius(m_pRoom->m_vNormal[wall]);

                        D3DXVECTOR3 vPoint = vCenter - m_pRoom->m_vNormal[wall]*fRadius;
                        FLOAT fPenetration;
                        switch(wall)
                        {
                        case 0: fPenetration = -(ROOM_WIDTH/2) - vPoint.x; break;
                        case 1: fPenetration =                 - vPoint.y; break;
                        case 2: fPenetration = -(ROOM_DEPTH/2) - vPoint.z; break;
                        case 3: fPenetration = -(ROOM_WIDTH/2) + vPoint.x; break;
                        case 4: fPenetration = - ROOM_HEIGHT   + vPoint.y; break;
                        case 5: fPenetration = -(ROOM_DEPTH/2) + vPoint.z; break;
                        }

                        if (fPenetration > fMaxPenetration*fRadius)
                            bPenetrating = TRUE;

                        if ( bPenetrating && (fTimeSlice > fMinTimeSlice) )
                        {
                            bDivideSlice = TRUE;
                            break;
                        }
                        else if (fPenetration >= 0.0f) 
                        {
                            D3DXVECTOR3 vErrorCorrection = fPenetration * m_pRoom->m_vNormal[wall];
                            pObject->Translate( vErrorCorrection );
                            vPoint = vPoint + vErrorCorrection;
                            CPEObject::Collide(*m_pRoom, *pObject, 
                                               vPoint,
                                               m_pRoom->m_vNormal[wall],
                                               -m_pRoom->m_vNormal[wall]);
                        }
                    }
                    if (bDivideSlice)
                        break;

                    // Collision detect other spheres
                    for (object2 = object+1; object2 < m_dwNumObjects; object2++)
                    {
                        if (m_CollisionStyle[object2] != CS_Sphere) continue;
                        CObject* pObject2 = m_pObject[object2];
                        D3DXVECTOR3 vCenter2;
                        D3DXVec3TransformCoord( &vCenter2, &pObject2->GetCentroid(), &pObject2->GetTransform() );

                        D3DXVECTOR3 vC2C1 = vCenter2 - vCenter;
                        D3DXVec3Normalize(&vC2C1, &vC2C1);

                        FLOAT fRadius  = pObject->GetWorldRadius(vC2C1);
                        FLOAT fRadius2 = pObject2->GetWorldRadius(vC2C1);

                        D3DXVECTOR3 vPoint  = vCenter  + vC2C1*fRadius;
                        D3DXVECTOR3 vPoint2 = vCenter2 - vC2C1*fRadius2;
                        D3DXVECTOR3 vP1P2   = vPoint - vPoint2;

                        FLOAT fPenetration = D3DXVec3Dot( &vC2C1, &vP1P2);

                        if (fPenetration > fMaxPenetration*min(fRadius, fRadius2))
                            bPenetrating = TRUE;

                        if ( bPenetrating && (fTimeSlice > fMinTimeSlice) )
                        {
                            bDivideSlice = TRUE;
                            break;
                        }
                        else if (fPenetration >= 0.0f) 
                        {
                            D3DXVECTOR3 vErrorCorrection =  0.5f * fPenetration * vC2C1;
                            pObject->Translate( -vErrorCorrection );
                            pObject2->Translate( vErrorCorrection );
                            CPEObject::Collide(*pObject2, *pObject, 
                                               vPoint,
                                               -vC2C1,
                                               vC2C1);
                        }
                    }
                }
                else if (m_CollisionStyle[object] == CS_Box)
                {
                    m_pObject[object]->Advance( fTimeSlice );

                    // Collision detect walls
                    D3DXVECTOR3 vCenter, vWallNormals[6];
                    vCenter = m_pObject[object]->GetWorldCenterOfGravity();
                    for (wall = 0; wall < 6; wall++)
                    {
                        D3DXVECTOR3 min, max;
                        m_pObject[object]->GetBoundingBox(&min, &max);

                        D3DXVECTOR3 vPoint, vPointAve;
                        FLOAT fPenetrationAve = -1;
                        int numCollisions = 0;
                        for(int corner = 0; corner < 8; corner++)
                        {
                            switch (corner)
                            {
                            case 0: vPoint = D3DXVECTOR3(min.x, min.y, min.z); break;
                            case 1: vPoint = D3DXVECTOR3(min.x, min.y, max.z); break;
                            case 2: vPoint = D3DXVECTOR3(min.x, max.y, min.z); break;
                            case 3: vPoint = D3DXVECTOR3(min.x, max.y, max.z); break;
                            case 4: vPoint = D3DXVECTOR3(max.x, min.y, min.z); break;
                            case 5: vPoint = D3DXVECTOR3(max.x, min.y, max.z); break;
                            case 6: vPoint = D3DXVECTOR3(max.x, max.y, min.z); break;
                            case 7: vPoint = D3DXVECTOR3(max.x, max.y, max.z); break;
                            }

                            D3DXVec3TransformCoord(&vPoint, &vPoint, &m_pObject[object]->GetTransform());

                            FLOAT fPenetration;

                            switch(wall)
                            {
                            case 0: fPenetration = -(ROOM_WIDTH/2) - vPoint.x; break;
                            case 1: fPenetration =                 - vPoint.y; break;
                            case 2: fPenetration = -(ROOM_DEPTH/2) - vPoint.z; break;
                            case 3: fPenetration = -(ROOM_WIDTH/2) + vPoint.x; break;
                            case 4: fPenetration = - ROOM_HEIGHT   + vPoint.y; break;
                            case 5: fPenetration = -(ROOM_DEPTH/2) + vPoint.z; break;
                            }
                            if (fPenetration > 0)
                            {
                                if (fPenetration > fPenetrationAve)
                                    fPenetrationAve = fPenetration;
                                vPointAve = (vPointAve*numCollisions + vPoint) / (numCollisions+1);
                                numCollisions++;
                            }
                        }

                        if (fPenetrationAve > fMaxPenetration)
                            bPenetrating = TRUE;

                        if ( bPenetrating && (fTimeSlice > fMinTimeSlice) )
                        {
                            bDivideSlice = TRUE;
                            break;
                        }
                        else if (fPenetrationAve >= 0.0f) 
                        {
                            D3DXVECTOR3 vErrorCorrection = fPenetrationAve * m_pRoom->m_vNormal[wall];
                            m_pObject[object]->Translate( vErrorCorrection );
                            vPointAve = vPointAve + vErrorCorrection;
                            CPEObject::Collide(*m_pRoom, *m_pObject[object], 
                                               vPointAve,
                                               m_pRoom->m_vNormal[wall],
                                               -m_pRoom->m_vNormal[wall]);
                        }
                    }

                    // Collision detect objects
                }
            }

            if (bDivideSlice)
            {
                // when collisions are happening, make next starting slice amount smaller
                fTimeSlice /= 2;
                fLastTimeSlice = fTimeSlice;
                for (object = 0; object < m_dwNumObjects; object++)
                {
                    m_pObject[object]->RestoreState();
                }
            }
        } while (bDivideSlice);

        fElapsedTime += fTimeSlice;
        CPEObject::m_sfTime += fTimeSlice;

    } while (fElapsedTime < m_fElapsedTime);
}


HRESULT CMyD3DApplication::RestoreObjectDeviceObjects()
{
    HRESULT hr, hr2 = S_OK;

    // RestoreDeviceObjects for file objects (build textures and vertex buffers)
    for (int ball = 0; ball < m_dwNumObjects; ball++)
    {
        if ( FAILED( hr = m_pObject[ball]->RestoreDeviceObjects() ) )
            hr2 = hr;
        if (ball < m_dwNumLights)
            m_pObject[ball]->GetEffect(ET_Ambient)->SetDword("Colr", 0xFFFFFFFF);
        if (m_bShowVolumes)
            if ( FAILED( hr = m_pObject[ball]->SetTechnique(ET_Shadow, "ShowVolumes") ) )
                hr2 = hr;
        else
            if ( FAILED( hr = m_pObject[ball]->SetTechnique(ET_Shadow, "ShadowVolumes") ) )
                hr2 = hr;
    }
    return hr2;
}