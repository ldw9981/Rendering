#ifndef __DEUBGOUTPUT_H
#define __DEBUGOUTPUT_H

#include <windows.h>
#include <stdio.h>
#include <stdarg.h>

void DebugPrintf(const char *szFmt, ...);
void MessageBoxPrintf(const char *titleStr, const char *szFmt, ...);

#endif
