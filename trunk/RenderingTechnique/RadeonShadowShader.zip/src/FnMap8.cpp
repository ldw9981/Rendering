//-----------------------------------------------------------------------------
// FnMap8
// 
// Dx8 C++ style implementation of a procedural textures
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------

#include "FnMap8.h"
#include <tchar.h>
#include <D3DX8.h>
#include "DXUtil.h"
#include "D3DUtil.h"


//////////////////////////////////////////////////////////////////////////////
// CBaseMap8 implementation /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

CBaseMap8::CBaseMap8()
{
   m_pTexture = NULL;
   m_Format = D3DFMT_A8R8G8B8;
   m_dwLevels = 0;
}

CBaseMap8::~CBaseMap8()
{
   SAFE_RELEASE( m_pTexture );
}

//////////////////////////////////////////////////////////////////////////////
// CFnMap8 implementation /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

CFnMap8::CFnMap8()
{
   m_dwWidth = m_dwHeight = 1;
}

VOID CFnMap8::Fill2DWrapper(D3DXVECTOR4* pOut, D3DXVECTOR2* pTexCoord, D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    CFnMap8* map = (CFnMap8*)pData;
    const D3DXCOLOR& c = map->Function( pTexCoord, pTexelSize );
    *pOut = D3DXVECTOR4((const float*)c);
}

HRESULT CFnMap8::Initialize(LPDIRECT3DDEVICE8 d3dDevice)
{
   // take device pointer from app
   m_pd3dDevice = d3dDevice;

   LPDIRECT3DTEXTURE8 pTexture;
   HRESULT hr;

   if ( FAILED( hr = D3DXCheckTextureRequirements(m_pd3dDevice, &m_dwWidth, 
       &m_dwHeight, &m_dwLevels, 0, &m_Format, D3DPOOL_MANAGED) ) )
   {
      OutputDebugString("Can't find valid texture format.\n");
      return hr;
   }

   if (FAILED (hr = m_pd3dDevice->CreateTexture(m_dwWidth, m_dwHeight,
       0, 0, m_Format, D3DPOOL_MANAGED, &pTexture) ) )
   {
      OutputDebugString("Can't create texture\n");
      return hr;
   }

   if (FAILED (hr = D3DXFillTexture(pTexture, Fill2DWrapper, (void*)this) ) )
       return hr;

   m_pTexture = pTexture;

   return S_OK;
}

//////////////////////////////////////////////////////////////////////////////
// CVolumeMap8 implementation /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

CVolumeMap8::CVolumeMap8()
{
   m_dwWidth = m_dwHeight = m_dwDepth = 1;
}

VOID CVolumeMap8::Fill3DWrapper(D3DXVECTOR4* pOut, D3DXVECTOR3* pTexCoord, D3DXVECTOR3* pTexelSize, LPVOID pData)
{
    CVolumeMap8* map = (CVolumeMap8*)pData;
    const D3DXCOLOR& c = map->Function( pTexCoord, pTexelSize );
    *pOut = D3DXVECTOR4((const float*)c);
}

HRESULT CVolumeMap8::Initialize(LPDIRECT3DDEVICE8 d3dDevice)
{
   // take device pointer from app
   m_pd3dDevice = d3dDevice;

   LPDIRECT3DVOLUMETEXTURE8 pTexture;
   HRESULT hr;

   if ( FAILED( hr = D3DXCheckVolumeTextureRequirements(m_pd3dDevice, &m_dwWidth, 
       &m_dwHeight, &m_dwDepth, &m_dwLevels, 0, &m_Format, D3DPOOL_MANAGED) ) )
   {
      OutputDebugString("Can't find valid volume texture format.\n");
      return hr;
   }

   if (FAILED (hr = m_pd3dDevice->CreateVolumeTexture(m_dwWidth, m_dwHeight, m_dwDepth,
       0, 0, m_Format, D3DPOOL_MANAGED, &pTexture) ) )
   {
      OutputDebugString("Can't create volume texture\n");
      return hr;
   }

   if (FAILED (hr = D3DXFillVolumeTexture(pTexture, Fill3DWrapper, (void*)this) ) )
       return hr;

   m_pTexture = pTexture;

   return S_OK;
}

//////////////////////////////////////////////////////////////////////////////
// CCubeMap8 implementation /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

CCubeMap8::CCubeMap8()
{
   m_dwSize = 1;
}

VOID CCubeMap8::Fill3DWrapper(D3DXVECTOR4* pOut, D3DXVECTOR3* pTexCoord, D3DXVECTOR3* pTexelSize, LPVOID pData)
{
    CCubeMap8* map = (CCubeMap8*)pData;
    const D3DXCOLOR& c = map->Function( pTexCoord, pTexelSize );
    *pOut = D3DXVECTOR4((const float*)c);
}

HRESULT CCubeMap8::Initialize(LPDIRECT3DDEVICE8 d3dDevice)
{
   // take device pointer from app
   m_pd3dDevice = d3dDevice;

   LPDIRECT3DCUBETEXTURE8 pTexture;
   HRESULT hr;

   if ( FAILED( hr = D3DXCheckCubeTextureRequirements(m_pd3dDevice, &m_dwSize, 
       &m_dwLevels, 0, &m_Format, D3DPOOL_MANAGED) ) )
   {
      OutputDebugString("Can't find valid cube texture format.\n");
      return hr;
   }

   if (FAILED (hr = m_pd3dDevice->CreateCubeTexture(m_dwSize,
       0, 0, m_Format, D3DPOOL_MANAGED, &pTexture) ) )
   {
      OutputDebugString("Can't create cube texture\n");
      return hr;
   }

   if (FAILED (hr = D3DXFillCubeTexture(pTexture, Fill3DWrapper, (void*)this) ) )
       return hr;

   m_pTexture = pTexture;

   return S_OK;
}

//////////////////////////////////////////////////////////////////////////////
// CNormalizeMap8 implementation /////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

CNormalizerMap8::CNormalizerMap8()
{
   m_dwSize = 128;
}


D3DXCOLOR CNormalizerMap8::Function(D3DXVECTOR3* p, D3DXVECTOR3* s)
{
    D3DXVec3Normalize(p, p);
    *p /= 2;
    *p += D3DXVECTOR3(.5, .5, .5);
    return D3DXCOLOR(p->x, p->y, p->z, 1);
}
