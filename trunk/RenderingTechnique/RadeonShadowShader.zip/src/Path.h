//
// File: Path.h
// Author: Evan Hart, ATI Research Inc
// Date: September 26, 2000
//
///////////////////////////////////////////////////////////////////////////////


#ifndef PATH_H
#define PATH_H

//
// Class: path
//
// Description:
//    This is a virtual class used to represent a generic
//  cubic spline path. It contains both 3-space positions
//  and quaternion orientations. It contains pure virtual
//  functions, and therefor cannot be instantiated
//  directly. It is sub classed to provide support for
//  closed and open paths.
//
// Issues:
//    Should this class be generalized to include other
//  order curves?
//
//    Should this base class contain both position and
//  orientation?
//
//    How should this deal with non-monotonically
//  increasing times?
//
///////////////////////////////////////////////////////////
class path
{
   public:

      //
      // Constructor and destructor
      /////////////////////////////////////////////////////
      path();
      virtual ~path();

      //
      // Get the length of the path in time
      /////////////////////////////////////////////////////
      float getLength( );

      //
      // Get the number of control points
      /////////////////////////////////////////////////////
      int getNumControlPoints( );

      //
      // Get a control point from the array
      /////////////////////////////////////////////////////
      void getControlPoint( int which, float &time, float position[3], float orientation[4]);

      //
      // Set a contol point
      /////////////////////////////////////////////////////
      virtual void setControlPoint( int which, float time, float position[3], float orientation[4]);

      //
      // Find the closest control point to a dive position
      /////////////////////////////////////////////////////
      int getClosest( float position[3]);

      //
      // Evaluate the postion for the given time
      /////////////////////////////////////////////////////
      virtual void evalPosition( float time, float position[3]) = 0;

      //
      // Evaulate the orientation for the given time
      /////////////////////////////////////////////////////
      virtual void evalOrientation( float time, float orientation[4]) = 0;

      //
      // Evaluate the postion and orientation for the
      // given time and return an OpenGL ordered matrix
      /////////////////////////////////////////////////////
      virtual void evalGLMatrix( float time, float matrix[16]) = 0;

   protected:
      
      //
      // Internal data structures to simplify allocation
      /////////////////////////////////////////////////////
      struct Position
      {
         float pos[3];
      };

      struct Quaternion
      {
         float quat[4];
      };

      //
      // Data members
      /////////////////////////////////////////////////////
      int m_numPoints;

      float *m_times;
      Position *m_positions;
      Quaternion *m_orientations;
};

//
// Class: openPath
//
// Description:
//    This class propvides the interface for an open
//  cubic spline. 
///////////////////////////////////////////////////////////
class openPath : public path
{
   public:

      //
      // Constructors and Destructors
      /////////////////////////////////////////////////////
      openPath();
      ~openPath();

   private:

      //
      // Private functions
      /////////////////////////////////////////////////////
      void Compile();

      //
      // Data Members
      /////////////////////////////////////////////////////
      bool m_compiled;

      //position data
      float *m_X;
      float *m_Y;
      float *m_Z;
      float *m_d2X;
      float *m_d2Y;
      float *m_d2Z;

      //orientation data
      float *m_qX;
      float *m_qY;
      float *m_qZ;
      float *m_qW;
      float *m_d2qX;
      float *m_d2qY;
      float *m_d2qZ;
      float *m_d2qW;
};

//
// Class: closedPath
//
// Description:
//    This class propvides the interface for an closed
//  cubic spline. 
///////////////////////////////////////////////////////////
class closedPath : public path
{
   public:

      //
      // Constructors and Destructors
      /////////////////////////////////////////////////////
      closedPath();
      ~closedPath();

      //
      // Set the length in time until the path loops
      /////////////////////////////////////////////////////
      void SetDuration(float duration);

      //
      // Get the length in time until the path loops
      /////////////////////////////////////////////////////
      float GetDuration();

      //
      // Evaluate the postion for the given time
      /////////////////////////////////////////////////////
      virtual void evalPosition( float time, float position[3]);

      //
      // Evaulate the orientation for the given time
      /////////////////////////////////////////////////////
      virtual void evalOrientation( float time, float orientation[4]);

      //
      // Evaluate the postion and orientation for the
      // given time and return an OpenGL ordered matrix
      /////////////////////////////////////////////////////
      virtual void evalGLMatrix( float time, float matrix[16]);

   private:

      //
      // Private functions
      /////////////////////////////////////////////////////
      void Compile();

      //
      // Data Members
      /////////////////////////////////////////////////////
      bool m_compiled;

      float m_duration;

      //position data
      float *m_X;
      float *m_Y;
      float *m_Z;
      float *m_d2X;
      float *m_d2Y;
      float *m_d2Z;

      //orientation data
      float *m_qX;
      float *m_qY;
      float *m_qZ;
      float *m_qW;
      float *m_d2qX;
      float *m_d2qY;
      float *m_d2qZ;
      float *m_d2qW;

      //time data
      float *m_T;
};


#endif