//-----------------------------------------------------------------------------
// ArcBallObject.h
// 
// Adds mouse control to a CPEObject
// Right mouse button controls rotation
// Left mouse button control position
// Middle mouse button moves in and out
// 
// Derivative classes can change the transforms for motion and rotation to
// whatever is needed to align the screen to the object.
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#ifndef _ARCBALLOBJECT_H_
#define _ARCBALLOBJECT_H_
#include <D3DX8.h>
#include "PEObject.h"

class CArcBallObject : public CPEObject
{
protected:
    static int m_sScreenWidth, m_sScreenHeight;

public:
    static void SetScreenSize(int x, int y);
    virtual const D3DXMATRIX& GetMouseMotionTransform();
    virtual const D3DXMATRIX& GetMouseRotationTransform();
    virtual D3DXVECTOR3 GetMouseRotationSpeed();
    LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
};

#endif
