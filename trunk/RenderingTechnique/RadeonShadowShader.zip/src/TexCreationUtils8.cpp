/*
TexCreationUtils


A set of utilities to find available formats for textures 


*/


/*
static globals common to all the routines in this file
*/

#include "TexCreationUtils8.hpp"

#define FORMAT_END_SENTINEL 0xffffffff
#define MAX_USAGE_BITS 9


static char *sg_ResourceTypeName[10]={
"",
"D3DRTYPE_SURFACE",         
"D3DRTYPE_VOLUME",               
"D3DRTYPE_TEXTURE",                
"D3DRTYPE_VOLUMETEXTURE",        
"D3DRTYPE_CUBETEXTURE",           
"D3DRTYPE_VERTEXBUFFER",          
"D3DRTYPE_INDEXBUFFER",           
};


//note these are names of bits e.g. D3DUSAGE_DEPTHSTENCIL = 1<<1,
static char *sg_UsageName[MAX_USAGE_BITS]={
"D3DUSAGE_RENDERTARGET",
"D3DUSAGE_DEPTHSTENCIL",
"D3DUSAGE_LOADONCE",
"D3DUSAGE_WRITEONLY",
"D3DUSAGE_SOFTWAREPROCESSING",
"D3DUSAGE_DONOTCLIP",
"D3DUSAGE_POINTS",
"D3DUSAGE_HOSURFACES",
"D3DUSAGE_NPATCHES",
};


//number of each format
static int sg_FormatIndices[]={
	0,1,2,3,4,5,6,7,8,9,
	20,21,22,23,24,25,26,27,28,29,30,
	40,41,
	50,51,52,
	60,61,62,
	'UYVY','YUY2','DXT1','DXT2','DXT3','DXT4','DXT5',
	70,
	90,91,92,93,94,
	100,101,102, FORMAT_END_SENTINEL,
	};


//number of bytes needed to represent a pixel
static int sg_CorrespondingFormatPixelDepth[]={
	4,1,1,1,2,2,2,3,4,4,
	3,4,4,2,2,2,2,1,1,2,2,
	2,1,
	1,1,2,
	2,4,2,
	4,4,4,4,4,4,4,
	2,
	4,4,4,4,4,
	4,2,4, FORMAT_END_SENTINEL,
	};


static char *sg_CorrespondingFormatName[]={
	"D3DFMT_UNKNOWN",
    "D3DFMT_UNKNOWN_C5",           
    "D3DFMT_UNKNOWN_C5A1",        
    "D3DFMT_UNKNOWN_C8",          
    "D3DFMT_UNKNOWN_C8A8",         
    "D3DFMT_UNKNOWN_D16",          
    "D3DFMT_UNKNOWN_D15S1",       
    "D3DFMT_UNKNOWN_D24",         
    "D3DFMT_UNKNOWN_D24S8",        
    "D3DFMT_UNKNOWN_D32",          

    "D3DFMT_R8G8B8",           
    "D3DFMT_A8R8G8B8",            
    "D3DFMT_X8R8G8B8",             
    "D3DFMT_R5G6B5",              
    "D3DFMT_X1R5G5B5",             
    "D3DFMT_A1R5G5B5",             
    "D3DFMT_A4R4G4B4",            
    "D3DFMT_R3G3B2",              
    "D3DFMT_A8",               
    "D3DFMT_A8R3G3B2",           
    "D3DFMT_X4R4G4B4",            

    "D3DFMT_A8P8",                
    "D3DFMT_P8",                

    "D3DFMT_L8",                 
    "D3DFMT_A8L8",               
    "D3DFMT_A4L4",  
	
    "D3DFMT_V8U8",                
    "D3DFMT_L6V5U5",               
    "D3DFMT_X8L8V8U8",            

    "D3DFMT_UYVY",            
    "D3DFMT_YUY2",             
    "D3DFMT_DXT1",             
    "D3DFMT_DXT2",             
    "D3DFMT_DXT3",             
    "D3DFMT_DXT4",               
    "D3DFMT_DXT5", 
	
    "D3DFMT_D16",               

    "D3DFMT_DXV1",                
    "D3DFMT_DXV2",               
    "D3DFMT_DXV3",               
    "D3DFMT_DXV4",                
    "D3DFMT_DXV5",                
    "D3DFMT_VERTEXDATA",         
    "D3DFMT_INDEX16",              
    "D3DFMT_INDEX32",            
};


/*
given a D3DFORMAT, returns a name of the format

*/
char *GetFormatName(D3DFORMAT p_d3dfFormat)
{
DWORD i;

i=0;
while(sg_FormatIndices[i]!=FORMAT_END_SENTINEL)
	{	
	if(sg_FormatIndices[i]==p_d3dfFormat)
		return sg_CorrespondingFormatName[i];

	i++;
	}

return NULL;
}


/*
given a d3dformat, returns the pixel depth, e.g. the number of bits in each pixel

*/
int GetFormatPixelDepth(D3DFORMAT p_d3dfFormat)
{
DWORD i;

i=0;
while(sg_FormatIndices[i]!=FORMAT_END_SENTINEL)
	{	
	if(sg_FormatIndices[i]==p_d3dfFormat)
		return sg_CorrespondingFormatPixelDepth[i];

	i++;
	}

return 0;
}


/*
given a DWORD corresponding to a usage bit, returns a name of usage bit

*/

char *GetUsageBitName(DWORD p_dwUsage)
{

return sg_UsageName[p_dwUsage];
}


/*
given a DWORD corresponding to a usage bit, returns a name of usage bit

*/
char *GetResourceTypeName(D3DRESOURCETYPE p_d3drtType)
{

return sg_ResourceTypeName[p_d3drtType];
}




/*
finds a available format for a certain type of resource (texture, cubetexture, etc) given a list of Formats, and a usage

*/
D3DFORMAT FindSupportedFormat(LPDIRECT3DDEVICE8 p_pd3dDevice, D3DFORMAT *p_d3dfFormat, DWORD p_dwNumFormats, DWORD p_dwUsage, D3DRESOURCETYPE p_d3drtType)
{
D3DDEVICE_CREATION_PARAMETERS l_d3ddcpCreationParms;
D3DDISPLAYMODE  l_d3ddmMode;

LPDIRECT3D8 l_pd3d;
DWORD i=0;

p_pd3dDevice->GetDirect3D(&l_pd3d);
p_pd3dDevice->GetDisplayMode(&l_d3ddmMode);
p_pd3dDevice->GetCreationParameters(&l_d3ddcpCreationParms);


for(i=0; i<p_dwNumFormats; i++)
	{
	if(SUCCEEDED(l_pd3d->CheckDeviceFormat(D3DADAPTER_DEFAULT, l_d3ddcpCreationParms.DeviceType, l_d3ddmMode.Format,   
		p_dwUsage, p_d3drtType, p_d3dfFormat[i] )) )
		{
        SAFE_RELEASE( l_pd3d );
		return(p_d3dfFormat[i]);
		}
	}

char str[1024];
sprintf(str, "FindSupportedFormat: No available resource of type %s, and usage type: \n", GetResourceTypeName(p_d3drtType) );
OutputDebugString(str);

for(i=0; i<MAX_USAGE_BITS; i++)
	{
	char str[1024];
	if(p_dwUsage & (1<<i))
		{
		sprintf(str,"%s |",GetUsageBitName(i));
		OutputDebugString(str);
		}
	}

OutputDebugString("\nthat supports format types :\n");

for(i=0; i<p_dwNumFormats; i++)
	{
	char str[1024];
	sprintf(str,"%s, ", GetFormatName(p_d3dfFormat[i]));
	OutputDebugString(str);
	}

OutputDebugString("\n");

SAFE_RELEASE( l_pd3d );
return D3DFMT_UNKNOWN;
}