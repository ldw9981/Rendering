#include "d3dutil.h"
#include "dxutil.h"
#include "d3dapp.h"
#include "object.h"

#define SHADOW_EFFECT 2

#define cShd    MAKEFOURCC('c', 'S', 'h', 'd')

CObject::IsFurther(CObject *obj1, CObject *obj2)
{
    D3DXMATRIX matView;
    m_spD3DDevice->GetTransform( D3DTS_VIEW, &matView );

    D3DXVECTOR3 vPos1 = obj1->GetWorldCenterOfGravity();
    D3DXVECTOR3 vPos2 = obj2->GetWorldCenterOfGravity();
    D3DXVec3TransformNormal(&vPos1, &vPos1, &matView);
    D3DXVec3TransformNormal(&vPos2, &vPos2, &matView);
    return vPos1.z > vPos2.z;
}

CObject::CObject() 
{
    m_pObject = NULL;

    // Physics variables defaults
    m_fMass               = 1.0f;
    m_fAirResistance      = 0.1f;
    m_fAngAirResistance   = 0.001f;
    m_fCoeffOfFriction    = 1.0f;
    m_fRigidity           = 1.0f;
    m_fAngInertiaOverMass = 0.1f;

    m_bSetScale = FALSE;

    SetEffectFile(SHADOW_EFFECT, "shadow.sha");
    m_strObjectFile = NULL;
}

HRESULT CObject::RenderShadowVolume(const D3DLIGHT8* pLight)
{
    if ( NULL == m_pEffect[SHADOW_EFFECT] )
        return D3DAPPERR_MEDIANOTFOUND;

    SetRenderTransform( D3DTS_WORLD, &m_matWorld );

    SetCommonShaderConstants(SHADOW_EFFECT, pLight);

    D3DXVECTOR4 vShadowConst(pLight->Range, 0, .501f, 9999.0f);
    m_pEffect[SHADOW_EFFECT]->SetVector( "cShd", &vShadowConst );

    // Render Effect
    UINT uPasses;
    m_pEffect[SHADOW_EFFECT]->Begin(&uPasses, NULL);

    for(UINT uPass = 0; uPass < uPasses; uPass++)
    {
        m_pEffect[SHADOW_EFFECT]->Pass(uPass);
        m_pObject->DrawShadow();
    }

    m_pEffect[SHADOW_EFFECT]->End();

    return S_OK;
}

HRESULT CObject::Render(DWORD effect, const D3DLIGHT8* pLight)
{
    if ( NULL == m_pEffect[effect] )
        return D3DAPPERR_MEDIANOTFOUND;

    SetRenderTransform( D3DTS_WORLD, &m_matWorld );

    SetCommonShaderConstants(effect, pLight);

    // Render Effect
    UINT uPasses;
    m_pEffect[effect]->Begin(&uPasses, NULL);

    for(UINT uPass = 0; uPass < uPasses; uPass++)
    {
        m_pEffect[effect]->Pass(uPass);
        m_pObject->Draw(POFMESH_DRAW_COMPACT_BUFFER);
    }

    m_pEffect[effect]->End();

    return S_OK;
}

FLOAT CObject::GetWorldRadius(const D3DXVECTOR3& vDirection)
{
    FLOAT size = GetObjectSize();
    D3DXVECTOR3 vRadius = size*vDirection;
    D3DXVec3TransformNormal(&vRadius, &vRadius, &GetInvWorldMatrix());
    vRadius *= size/D3DXVec3Length(&vRadius);
    D3DXVec3TransformNormal(&vRadius, &vRadius, &GetTransform());
    return D3DXVec3Length(&vRadius);
}

HRESULT CObject::InitDeviceObjects( LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d )
{
    HRESULT hr, hr2 = S_OK;

    if ( FAILED( hr = CShaderObject::InitDeviceObjects( d3dDevice, d3d ) ) )
        hr2 = hr;

    m_pObject = new CShadowPOF();
    if ( FAILED( hr = m_pObject->Initialize(m_strObjectFile, m_spD3DDevice, m_spD3D) ) )
        hr2 = hr;
    else 
        m_vCenterOfGravity = GetCentroid();

    if (m_bSetScale == FALSE)
    {
        FLOAT scale = 1/m_pObject->GetScale();
        D3DXMATRIX matScale;
        D3DXMatrixScaling( &matScale, scale, scale, scale );
        D3DXMatrixMultiply( &matScale, &matScale, &GetTransform());
        SetTransform( matScale );
        m_bSetScale = TRUE;
    }

    return hr2;
}

HRESULT CObject::DeleteDeviceObjects()
{
    HRESULT hr;

    if ( FAILED( hr = CShaderObject::DeleteDeviceObjects() ) )
        return hr;

    SAFE_DELETE(m_pObject);

    return S_OK;
}

