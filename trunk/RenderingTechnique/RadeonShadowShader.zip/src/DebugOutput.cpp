#include "DebugOutput.h"

void DebugPrintf(const char *szFmt, ...)
{
    char sz[4096], szMsg[4096];

    va_list va;
    va_start(va, szFmt);
    vsprintf(szMsg, szFmt, va);
    va_end(va);

    sprintf(sz, "%s", szMsg);

    sz[sizeof(sz)-1] = '\0';

#ifdef _DEBUG
    OutputDebugString(sz);
#endif
}

void MessageBoxPrintf(const char *titleStr, const char *szFmt, ...)
{
    char sz[4096], szMsg[4096];

    va_list va;
    va_start(va, szFmt);
    vsprintf(szMsg, szFmt, va);
    va_end(va);

    sprintf(sz,  "%s\r\n", szMsg);

    sz[sizeof(sz)-1] = '\0';

    MessageBox(NULL, sz, titleStr, MB_OK);
}





