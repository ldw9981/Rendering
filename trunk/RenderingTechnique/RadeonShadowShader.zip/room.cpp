#include "d3dutil.h"
#include "d3dapp.h"
#include "room.h"

#define D3DFVF_VERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX2)

#define WALL_BAS_FILE  "Media\\Fieldstone.tga"
#define WALL_DOT_FILE  "Media\\FieldstoneDOT3.tga"
#define CEIL_BAS_FILE  "Media\\Tile4.tga"
#define CEIL_DOT_FILE  "Media\\Tile4BumpDOT3.tga"
#define FLOOR_BAS_FILE "Media\\Wood.tga"
#define FLOOR_DOT_FILE "Media\\WoodDOT3.tga"

CRoom::CRoom(FLOAT fWidth, FLOAT fHeight, FLOAT fDepth)
{
    m_fCoeffOfFriction = 1.0f;
    m_fRigidity        = 1.0f;

    m_pVertexBuffer = NULL;
    D3DXMatrixIdentity(&m_matWorld);
    
    m_vNormal[0] = D3DXVECTOR3( 1,  0,  0);
    m_vNormal[1] = D3DXVECTOR3( 0,  1,  0);
    m_vNormal[2] = D3DXVECTOR3( 0,  0,  1);
    m_vNormal[3] = D3DXVECTOR3(-1,  0,  0);
    m_vNormal[4] = D3DXVECTOR3( 0, -1,  0);
    m_vNormal[5] = D3DXVECTOR3( 0,  0, -1);

    m_pWall[0][0]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, 0.0f, -fDepth/2.0f), 
                          D3DXVECTOR3 ( 1,  0,  0), -fDepth/10.0f, 0.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[0][1]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, fHeight, -fDepth/2.0f), 
                          D3DXVECTOR3 ( 1,  0,  0), -fDepth/10.0f, fHeight/5.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[0][2]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, 0.0f, fDepth/2.0f), 
                          D3DXVECTOR3 ( 1,  0,  0), fDepth/10.0f, 0.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[0][3]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, fHeight, fDepth/2.0f), 
                          D3DXVECTOR3 ( 1,  0,  0), fDepth/10.0f, fHeight/5.0f,
                          D3DXVECTOR3 ( 0,  1,  0));

    m_pWall[1][0]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, 0.0f, -fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 1.0f, 0.0f), -fWidth/10.0f, -fDepth/10.0f,
                          D3DXVECTOR3 ( 0,  0,  1));
    m_pWall[1][1]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, 0.0f, fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 1.0f, 0.0f), -fWidth/10.0f, fDepth/10.0f,
                          D3DXVECTOR3 ( 0,  0,  1));
    m_pWall[1][2]=Vertex (D3DXVECTOR3 (fWidth/2.0f, 0.0f, -fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 1.0f, 0.0f), fWidth/10.0f, -fDepth/10.0f,
                          D3DXVECTOR3 ( 0,  0,  1));
    m_pWall[1][3]=Vertex (D3DXVECTOR3 (fWidth/2.0f, 0.0f, fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 1.0f, 0.0f), fWidth/10.0f, fDepth/10.0f,
                          D3DXVECTOR3 ( 0,  0,  1));

    m_pWall[2][0]=Vertex (D3DXVECTOR3 (fWidth/2.0f, 0.0f, -fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 0.0f, 1.0f), fWidth/10.0f, 0.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[2][1]=Vertex (D3DXVECTOR3 (fWidth/2.0f, fHeight, -fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 0.0f, 1.0f), fWidth/10.0f, fHeight/5.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[2][2]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, 0.0f, -fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 0.0f, 1.0f), -fWidth/10.0f, 0.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[2][3]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, fHeight, -fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 0.0f, 1.0f), -fWidth/10.0f, fHeight/5.0f,
                          D3DXVECTOR3 ( 0,  1,  0));

    m_pWall[3][0]=Vertex (D3DXVECTOR3 (fWidth/2.0f, 0.0f, fDepth/2.0f), 
                          D3DXVECTOR3 (-1.0f, 0.0f, 0.0f), -fDepth/10.0f, 0.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[3][1]=Vertex (D3DXVECTOR3 (fWidth/2.0f, fHeight, fDepth/2.0f), 
                          D3DXVECTOR3 (-1.0f, 0.0f, 0.0f), -fDepth/10.0f, fHeight/5.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[3][2]=Vertex (D3DXVECTOR3 (fWidth/2.0f, 0.0f, -fDepth/2.0f), 
                          D3DXVECTOR3 (-1.0f, 0.0f, 0.0f), fDepth/10.0f, 0.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[3][3]=Vertex (D3DXVECTOR3 (fWidth/2.0f, fHeight, -fDepth/2.0f), 
                          D3DXVECTOR3 (-1.0f, 0.0f, 0.0f), fDepth/10.0f, fHeight/5.0f,
                          D3DXVECTOR3 ( 0,  1,  0));

    m_pWall[4][0]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, fHeight, fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, -1.0f, 0.0f), -fWidth/10.0f, -fDepth/10.0f,
                          D3DXVECTOR3 ( 0,  0,  -1));
    m_pWall[4][1]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, fHeight, -fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, -1.0f, 0.0f), -fWidth/10.0f, fDepth/10.0f,
                          D3DXVECTOR3 ( 0,  0,  -1));
    m_pWall[4][2]=Vertex (D3DXVECTOR3 (fWidth/2.0f, fHeight, fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, -1.0f, 0.0f), fWidth/10.0f, -fDepth/10.0f,
                          D3DXVECTOR3 ( 0,  0,  -1));
    m_pWall[4][3]=Vertex (D3DXVECTOR3 (fWidth/2.0f, fHeight, -fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, -1.0f, 0.0f), fWidth/10.0f, fDepth/10.0f,
                          D3DXVECTOR3 ( 0,  0,  -1));

    m_pWall[5][0]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, 0.0f, fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 0.0f, -1.0f), -fWidth/10.0f, 0.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[5][1]=Vertex (D3DXVECTOR3 (-fWidth/2.0f, fHeight, fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 0.0f, -1.0f), -fWidth/10.0f, fHeight/5.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[5][2]=Vertex (D3DXVECTOR3 (fWidth/2.0f, 0.0f, fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 0.0f, -1.0f), fWidth/10.0f, 0.0f,
                          D3DXVECTOR3 ( 0,  1,  0));
    m_pWall[5][3]=Vertex (D3DXVECTOR3 (fWidth/2.0f, fHeight, fDepth/2.0f), 
                          D3DXVECTOR3 (0.0f, 0.0f, -1.0f), fWidth/10.0f, fHeight/5.0f,
                          D3DXVECTOR3 ( 0,  1,  0));

    for (int wall = 0; wall < 6; wall++)
    {
        m_dwVBStartWall[wall] = 0;
    }
}

HRESULT CRoom::InitVertexBuffer ()
{
    HRESULT hr;

    // Compute vertex buffer size.
    DWORD dwNumVBVertices = 4*6;

    // Create the vertex buffer
    if( FAILED( hr = m_spD3DDevice->CreateVertexBuffer( dwNumVBVertices*sizeof(Vertex),
                                                       D3DUSAGE_WRITEONLY, D3DFVF_VERTEX,
                                                       D3DPOOL_MANAGED, &m_pVertexBuffer ) ) )
        return hr;

    // Lock the buffer and fill it.
    Vertex* pData;
    DWORD wallSize = sizeof (Vertex) * 4;

    if( FAILED( hr = m_pVertexBuffer->Lock (0, 0, (BYTE**)&pData, 0) ) )
        return hr;

    // Copy walls
    DWORD dwVBCurrent = 0;
    for (int wall = 0; wall < 6; wall++)
    {
        m_dwVBStartWall[wall] = dwVBCurrent;
        CopyMemory (pData, m_pWall[wall], wallSize);
        pData += 4;
        dwVBCurrent += 4;
    }

    hr = m_pVertexBuffer->Unlock ();

    return S_OK;
}

HRESULT CRoom::Render(DWORD effect, const D3DLIGHT8* pLight)
{
    if ( NULL == m_pEffect[effect] )
        return D3DAPPERR_MEDIANOTFOUND;

    SetRenderTransform( D3DTS_WORLD, &m_matWorld );
    m_spD3DDevice->SetStreamSource( 0, m_pVertexBuffer, sizeof(Vertex) );

    SetCommonShaderConstants(effect, pLight);

    for (int wall = 0; wall < 6; wall++)
    {
        switch(wall)
        {
        case 1:
            m_pEffect[effect]->SetTexture("tBase", LoadTextureFromFile( FLOOR_BAS_FILE, D3DFMT_DXT1 ) );
            if (m_pEffect[effect]->IsParameterUsed("tNormal"))
                m_pEffect[effect]->SetTexture("tNormal", LoadTextureFromFile( FLOOR_DOT_FILE, D3DFMT_R5G6B5 ) );
            break;
        case 4:
            m_pEffect[effect]->SetTexture("tBase", LoadTextureFromFile( CEIL_BAS_FILE, D3DFMT_DXT1 ) );
            if (m_pEffect[effect]->IsParameterUsed("tNormal"))
                m_pEffect[effect]->SetTexture("tNormal", LoadTextureFromFile( CEIL_DOT_FILE, D3DFMT_R5G6B5 ) );
            break;
        default:
            m_pEffect[effect]->SetTexture("tBase", LoadTextureFromFile( WALL_BAS_FILE, D3DFMT_DXT1 ) );
            if (m_pEffect[effect]->IsParameterUsed("tNormal"))
                m_pEffect[effect]->SetTexture("tNormal", LoadTextureFromFile( WALL_DOT_FILE, D3DFMT_R5G6B5 ) );
            break;
        }

        UINT uPasses;
        m_pEffect[effect]->Begin(&uPasses, NULL);

        for(UINT uPass = 0; uPass < uPasses; uPass++)
        {
            m_pEffect[effect]->Pass(uPass);
            m_spD3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, m_dwVBStartWall[wall],  2 );
        }

        m_pEffect[effect]->End();
    }

    return S_OK;
}

HRESULT CRoom::RestoreDeviceObjects()
{
    HRESULT hr;
    if( FAILED( hr = CShaderObject::RestoreDeviceObjects() ) )
        return hr;

    if( FAILED( hr = InitVertexBuffer() ) )
        return hr;

    return S_OK;
}

HRESULT CRoom::InvalidateDeviceObjects()
{
    HRESULT hr;
   
    SAFE_RELEASE( m_pVertexBuffer );

    if( FAILED( hr = CShaderObject::InvalidateDeviceObjects() ) )
        return hr;

    return S_OK;
}
