/*
This file contains utilities to create a uv offset texture, from a height field texture


*/


#include "TexBumpUtils8.hpp"


#define SBYTE signed char


/*
BuildUVOffsetTexture

Purpose:
Builds UV offset Bumpmaps from a texture
  
Description:
This function takes an input texture and uses the red or luminance channel as a height value.  

To generate the uv offset map, a simple first derivative filter is applied to the height field.
  
The x filter used is  
(-1 1)
and the result is stored in the u channel

The y filter used is   
	-1
	 1  
and the result is stored in the v channel


The uv offset bumpmap is stored as a texture of type D3DFMT_V8U8 or D3DFMT_X8L8V8U8
*/

LPDIRECT3DTEXTURE8 BuildUVOffsetTexture(LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d, LPDIRECT3DTEXTURE8 pTextureHF)
{
HRESULT hr;
	
D3DLOCKED_RECT d3dlrHF;
D3DLOCKED_RECT d3dlrBump;

RECT d3dr;

D3DSURFACE_DESC d3dsdHF;

//pointers for data in each texture (number of bytes per pixel)
BYTE *pBitsHF;
BYTE *pBitsBump;

//scanline width in bytes for each texture (number of bytes per pixe)
DWORD dwPitchHF;
DWORD dwPitchBump;

//pixel depth in bytes for each texture (number of bytes per pixel)
DWORD dwDepthHF;
DWORD dwDepthBump;

DWORD dwOffsetHF; //which byte in a pixel to use as the "height of the pixel"


//pixel formats for bumpmap and pixel shader
D3DFORMAT d3dfHF;
D3DFORMAT d3dfBump;
D3DFORMAT d3dfp_BumpFormatsToTry[2]={
	D3DFMT_V8U8,
	D3DFMT_X8L8V8U8,
	};


//both have the same number of bits for width and height
DWORD dwWidth;
DWORD dwHeight;

//texture to be created
LPDIRECT3DTEXTURE8 pTextureBump;

//get surface description about mip level 0
pTextureHF->GetLevelDesc( 0, &d3dsdHF);

dwWidth=d3dsdHF.Width;
dwHeight=d3dsdHF.Height;

d3dfHF=d3dsdHF.Format;


if(d3dfHF == D3DFMT_A8R8G8B8 || 
   d3dfHF == D3DFMT_X8R8G8B8 ||
   d3dfHF == D3DFMT_R8G8B8   ||
   d3dfHF == D3DFMT_L8 )
	{
	dwDepthHF=GetFormatPixelDepth(d3dfHF);
	dwOffsetHF=0;
	}
else
	{
	MessageBox(NULL,
		"Input Heightfield ERROR\n"
		"Can't accept heightfield in format sent in to BuildUVOffsetTexture",
		"Input Heightfield ERROR",MB_OK);
	exit(15);
	}


d3dr.left=0;
d3dr.top=0;
d3dr.right=dwWidth;
d3dr.bottom=dwHeight;


//try to create uv offset map of type D3DFMT_V8U8 or D3DFMT_X8L8V8U8
d3dfBump=FindSupportedFormat(d3dDevice, d3dfp_BumpFormatsToTry, 2, 0, D3DRTYPE_TEXTURE);
dwDepthBump=GetFormatPixelDepth(d3dfBump);
	
if(d3dfBump==D3DFMT_UNKNOWN)
	return NULL;
else  //texture type is available, now try to create the texture
	if(FAILED(hr=d3dDevice->CreateTexture(dwWidth, dwHeight, 1, 0, d3dfBump, D3DPOOL_MANAGED, &pTextureBump))) 
		{
		//PUDebugPrintf("Can't create uv offset bumpmap texture of size %d,%d\n",dwWidth,dwHeight );
		pTextureBump=NULL;
		return NULL;
		}


//get pointer to data in incoming heightfield texture (uses first component as height)
pTextureHF->LockRect( 0,  &d3dlrHF, &d3dr, NULL );
dwPitchHF = (DWORD)d3dlrHF.Pitch;
pBitsHF   = (BYTE*)d3dlrHF.pBits;


//get pointer to data in destination bumpmap texture 
pTextureBump->LockRect( 0,  &d3dlrBump, &d3dr, NULL );
dwPitchBump = (DWORD)d3dlrBump.Pitch;
pBitsBump   = (BYTE*)d3dlrBump.pBits;


BYTE* pSrcPtr = pBitsHF;
SBYTE* pDstPtr = (SBYTE*)pBitsBump; //ptr conversion because bumpmaps are signed data 


   for( DWORD y=0; y<dwHeight; y++ )
    {

        for( DWORD x=0; x<dwWidth; x++ )
		{
			float iDu;
			float iDv;

			iDu=(float)*(pSrcPtr+dwOffsetHF+(((x+1)%dwWidth)*dwDepthHF)+(dwPitchHF*y));
			iDu-=(float)*(pSrcPtr+dwOffsetHF+(x*dwDepthHF)+(dwPitchHF*y));

			iDv=(float)*(pSrcPtr+dwOffsetHF+(x*dwDepthHF)+(dwPitchHF*((y+1)%dwHeight)) );
			iDv-=(float)*(pSrcPtr+dwOffsetHF+(x*dwDepthHF)+(dwPitchHF*y));

            //uv offset maps expect a signed byte as the texture pixel data format 
			//-128 (10000000 in binary)  represents max negative displacement,  
			// 0   (00000000 in binary)  represents no displacement
			// 127 (01111111 in binary)  represents max positive disp
			*(pDstPtr+0+(x*dwDepthBump)) = (SBYTE)(iDu*0.5);
            *(pDstPtr+1+(x*dwDepthBump)) = (SBYTE)(-iDv*0.5);
		
        }
        pDstPtr += dwPitchBump;

   }


//unlock texture
pTextureBump->UnlockRect( 0 );
pTextureHF->UnlockRect( 0 );

D3DXFilterTexture(pTextureBump, NULL, 0,  D3DX_FILTER_BOX);


return pTextureBump;

}


/*
BuildNormalTexture

Purpose:
This function builds a xyz normal map texture used for dot3 bump mapping.

Description:
The red or luminance value of each pixel of the input texture is used as a height value for each pixel


To generate the xyz normal map, a simple first derivative filter is applied to the height field.
  
The uv offset bumpmap is stored as a texture of type D3DFMT_V8U8 or D3DFMT_X8L8V8U8
*/

LPDIRECT3DTEXTURE8 BuildNormalTexture(LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d, LPDIRECT3DTEXTURE8 pTextureHF, FLOAT fBumpiness)
{
HRESULT hr;

D3DLOCKED_RECT d3dlrHF;
D3DLOCKED_RECT d3dlrBump;

RECT d3dr;

D3DSURFACE_DESC d3dsdHF;

//pointers for data in each texture (number of bytes per pixel)
BYTE *pBitsHF;
BYTE *pBitsBump;

//scanline width in bytes for each texture (number of bytes per pixe)
DWORD dwPitchHF;
DWORD dwPitchBump;

//pixel depth in bytes for each texture (number of bytes per pixel)
DWORD dwDepthHF;
DWORD dwDepthBump;

DWORD dwOffsetHF; //which byte in a pixel to use as the "height of the pixel"


D3DFORMAT d3dfp_BumpFormatsToTry[3]={
	D3DFMT_A8R8G8B8,
	D3DFMT_X8R8G8B8,
	D3DFMT_R8G8B8,
	};


//pixel formats for bumpmap and pixel shader
D3DFORMAT d3dfHF;
D3DFORMAT d3dfBump;


//both have the same number of bits for width and height
DWORD dwWidth;
DWORD dwHeight;

//texture to be created
LPDIRECT3DTEXTURE8 pTextureBump;

//get surface description about mip level 0
pTextureHF->GetLevelDesc(0,&d3dsdHF);

dwWidth=d3dsdHF.Width;
dwHeight=d3dsdHF.Height;

d3dfHF=d3dsdHF.Format;



if(d3dfHF == D3DFMT_A8R8G8B8 || 
   d3dfHF == D3DFMT_X8R8G8B8 ||
   d3dfHF == D3DFMT_R8G8B8   ||
   d3dfHF == D3DFMT_L8 )
	{
	dwDepthHF=GetFormatPixelDepth(d3dfHF);
	dwOffsetHF=0;
	}
else
	{
	MessageBox(NULL,
		"Input Heightfield ERROR\n"
		"Can't accept heightfield in format sent in to BuildUVOffsetTexture",
		"Input Heightfield ERROR",MB_OK);
	exit(15);
	}

d3dr.left=0;
d3dr.top=0;
d3dr.right=dwWidth;
d3dr.bottom=dwHeight;


//try to create uv offset map of type D3DFMT_V8U8 or D3DFMT_X8L8V8U8
d3dfBump=FindSupportedFormat(d3dDevice, d3dfp_BumpFormatsToTry, 3, 0, D3DRTYPE_TEXTURE);
dwDepthBump=GetFormatPixelDepth(d3dfBump);
	
if(d3dfBump==D3DFMT_UNKNOWN)
	return NULL;
else  //texture type is available, now try to create the texture
	if(FAILED(hr=d3dDevice->CreateTexture(dwWidth, dwHeight, 0, 0, d3dfBump, D3DPOOL_MANAGED, &pTextureBump))) 
		{
//		PUDebugPrintf("Can't create rgb offset bumpmap texture of size %d,%d\n", dwWidth, dwHeight );
		pTextureBump=NULL;
		return NULL;
		}


//get pointer to data in incoming heightfield texture (uses first component as height)
pTextureHF->LockRect( 0,  &d3dlrHF, &d3dr, NULL );
dwPitchHF = (DWORD)d3dlrHF.Pitch;
pBitsHF   = (BYTE*)d3dlrHF.pBits;

//get pointer to data in destination bumpmap texture 
pTextureBump->LockRect( 0,  &d3dlrBump, &d3dr, NULL );
dwPitchBump = (DWORD)d3dlrBump.Pitch;
pBitsBump   = (BYTE*)d3dlrBump.pBits;

BYTE* pSrcPtr = pBitsHF;
BYTE* pDstPtr = (BYTE*)pBitsBump; //ptr conversion because normal maps use unsigned data 


   for( DWORD y=0; y<dwHeight; y++ )
      {
      for( DWORD x=0; x<dwWidth; x++ )
		   {
			D3DXVECTOR3 vx,vy,vz;

			float iDu;
			float iDv;

			iDu=(float)*(pSrcPtr+dwOffsetHF+(((x+1)%dwWidth)*dwDepthHF)+(dwPitchHF*y));
			iDu-=(float)*(pSrcPtr+dwOffsetHF+(x*dwDepthHF)+(dwPitchHF*y));

			iDv=(float)*(pSrcPtr+dwOffsetHF+(x*dwDepthHF)+(dwPitchHF*((y+1)%dwHeight)) );
			iDv-=(float)*(pSrcPtr+dwOffsetHF+(x*dwDepthHF)+(dwPitchHF*y));

			vx=D3DXVECTOR3(1.0f, 0.0f, iDu*fBumpiness);  //vector between current pixel and pixel to the right of it
			vy=D3DXVECTOR3(0.0f, 1.0f, -iDv*fBumpiness);  //vector between current pixel and pixel to the bottom of it

			D3DXVec3Cross(&vz,&vx,&vy);
			D3DXVec3Normalize(&vz,&vz);

            //normal maps expect an unsigned byte as the texture pixel data format 
			// 0   (00000000 in binary)  represents a -1.0 component value
			// 128 (10000000 in binary)  represents a  0.0 component value  
			// 255 (11111111 in binary)  represents a  1.0 component value

         //alpha channel gets copy of original image alpha
         if(d3dfBump==D3DFMT_A8R8G8B8)
            {
			   *(pDstPtr+3+(x*dwDepthBump)) = *(pSrcPtr+3+((x%dwWidth)*dwDepthHF)+(dwPitchHF*y));
            }

         //red channel gets x component 
			*(pDstPtr+2+(x*dwDepthBump)) = (BYTE)((vz.x)*127.0f+128.0f);

			//green channel gets y component 
         *(pDstPtr+1+(x*dwDepthBump)) = (BYTE)((vz.y)*127.0f+128.0f);

			//blue channel gets z component 
         *(pDstPtr+0+(x*dwDepthBump)) = (BYTE)((vz.z)*127.0f+128.0f); 
         }
      pDstPtr += dwPitchBump;
//        pSrcPtr += dwPitchHF;
   }

//unlock texture
pTextureBump->UnlockRect( 0 );
pTextureHF->UnlockRect( 0 );

D3DXFilterTexture(pTextureBump, NULL, 0,  D3DX_FILTER_BOX);



return pTextureBump;

}
