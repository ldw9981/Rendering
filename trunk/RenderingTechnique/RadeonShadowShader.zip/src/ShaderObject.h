//-----------------------------------------------------------------------------
// Shader Object
//
// A wrapper around the D3DX effects files and a cached texture manager.
// Also sets many of the common constants that are used in vertex and 
// pixel shaders.
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#ifndef __SHADEROBJECT_HPP
#define __SHADEROBJECT_HPP

#include <D3DX8.h>
#include <tchar.h>

#include "FnMap8.h"
#include "TexBumpUtils8.hpp"

#pragma warning(disable:4786) // turn off warning: 'identifier was truncated to 255 characters'
#include <vector>

#define MAX_NUM_EFFECTS 7
#define MAX_SHADER_TEXTURES 16

class CShaderObject
{
public:
    typedef enum {
        AsIs,
        BuildDuDvMap,
        BuildNormalMap
    } TexProcess;

    // Registers textures for shared usage among all shader objects
    static VOID LoadSharedTexture(TCHAR* name, TCHAR* filename, D3DFORMAT format, TexProcess = AsIs, FLOAT fBumpiness = TBU_BUMPINESS);
    static VOID RegisterSharedTexture(TCHAR* name, IDirect3DBaseTexture8* pTexture);

public:
    CShaderObject();
    ~CShaderObject();

    HRESULT      SetEffectFile( DWORD effect, TCHAR* strFile );
    TCHAR*       GetEffectFile( DWORD effect ) {return m_strEffectFile[effect];};
    HRESULT      RecompileEffectFiles();
    HRESULT      SetTechnique( DWORD effect, DWORD dwTechnique );
    HRESULT      SetTechnique( DWORD effect, LPCSTR strTechnique );
    DWORD        GetTechnique( DWORD effect );
    LPD3DXEFFECT GetEffect( DWORD effect ) { return m_pEffect[effect]; };
    LPCSTR       GetTechniqueName( DWORD effect );
    BOOL         IsTransparent( DWORD effect );
    VOID         SetEffectNum( DWORD effect );
    DWORD        GetEffectNum() { return m_dwCurrentEffect; };

    // Implied effect #
    HRESULT      SetEffectFile( TCHAR* strFile ) {return SetEffectFile(m_dwCurrentEffect, strFile);};
    TCHAR*       GetEffectFile() {return m_strEffectFile[m_dwCurrentEffect];};
    HRESULT      SetTechnique( DWORD technique ) {return SetTechnique(m_dwCurrentEffect, technique);};
    HRESULT      SetTechnique( LPCSTR strTechnique ) {return SetTechnique(m_dwCurrentEffect, strTechnique);};
    DWORD        GetTechnique() {return GetTechnique(m_dwCurrentEffect);};
    LPD3DXEFFECT GetEffect() { return m_pEffect[m_dwCurrentEffect]; };
    LPCSTR       GetTechniqueName() {return GetTechniqueName(m_dwCurrentEffect);};
    BOOL         IsTransparent() {return IsTransparent(m_dwCurrentEffect);};

    // Texure Management
    VOID   LoadTexture(TCHAR* name, TCHAR* filename, D3DFORMAT format, TexProcess = AsIs, FLOAT fBumpiness = TBU_BUMPINESS);
    VOID   RegisterTexture(TCHAR* name, IDirect3DBaseTexture8* pTexture);

    // D3D resource management
    HRESULT InitDeviceObjects( LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d );
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();

protected:

    static LPDIRECT3DDEVICE8  m_spD3DDevice;
    static LPDIRECT3D8        m_spD3D;

    // Shared Texture Management  -- need to make this a growable struct
    static TCHAR* m_sTexName[MAX_SHADER_TEXTURES];
    static TCHAR* m_sStrTexFilename[MAX_SHADER_TEXTURES];
    static D3DFORMAT m_sTexFormat[MAX_SHADER_TEXTURES];
    static TexProcess m_sTexProcess[MAX_SHADER_TEXTURES];
    static FLOAT m_sfBumpiness[MAX_SHADER_TEXTURES];
    static IDirect3DBaseTexture8* m_spTexture[MAX_SHADER_TEXTURES];

    // Has cubic normalizer map built in as a shared texture.
    static CNormalizerMap8*   m_spNormalizerMap;

    // Cached wrapper around the D3DX function
    static IDirect3DBaseTexture8* LoadTextureFromFile(TCHAR* filename, D3DFORMAT format, TexProcess proc = AsIs, FLOAT fBumpiness = TBU_BUMPINESS);

protected:
    BOOL    TestTransparency( DWORD effect );
    VOID    SetUsedTextures( DWORD effect );
    VOID    SetCommonShaderConstants(DWORD effect);
    VOID    SetCommonShaderConstants(DWORD effect, const D3DLIGHT8* pLight);
    VOID    SetCommonShaderConstants(DWORD effect, DWORD numLights, const D3DLIGHT8* pLight);
    VOID    SetLightShaderConstants(DWORD effect, DWORD numLights, const D3DLIGHT8* pLight);
    VOID    SetLightShaderConstants(DWORD effect, const D3DLIGHT8* pLight, TCHAR* suffix = _T(""));

    // Effect file state
    DWORD           m_dwCurrentEffect;
    TCHAR*          m_strEffectFile[MAX_NUM_EFFECTS];
    LPD3DXEFFECT    m_pEffect[MAX_NUM_EFFECTS];
    LPCSTR          m_strTechnique[MAX_NUM_EFFECTS];
    BOOL            m_IsTransparent[MAX_NUM_EFFECTS];

    // Texture Management  -- need to make this a growable struct
    TCHAR* m_texName[MAX_SHADER_TEXTURES];
    TCHAR* m_strTexFilename[MAX_SHADER_TEXTURES];
    D3DFORMAT m_texFormat[MAX_SHADER_TEXTURES];
    TexProcess m_texProcess[MAX_SHADER_TEXTURES];
    FLOAT      m_fBumpiness[MAX_SHADER_TEXTURES];
    IDirect3DBaseTexture8* m_pTexture[MAX_SHADER_TEXTURES];

    // Parameter usage info
    typedef struct
    {
        int param;
        LPCSTR index;
    } ParamIndexMap;
    std::vector<ParamIndexMap> m_ParamsUsed[MAX_NUM_EFFECTS];
    void MapUsedParameters();
    void MapUsedParameters(DWORD effect);

private:
    static D3DMATRIX m_sMatWorld;
    static D3DMATRIX m_sMatView;
    static D3DMATRIX m_sMatProj;

public:
    static void GetRenderTransform(D3DTRANSFORMSTATETYPE state, D3DMATRIX* pMatrix);
    static void SetRenderTransform(D3DTRANSFORMSTATETYPE state, const D3DMATRIX* pMatrix);
};

void inline CShaderObject::GetRenderTransform(D3DTRANSFORMSTATETYPE state, D3DMATRIX* pMatrix)
{
    switch(state)
    {
    case D3DTS_WORLD: *pMatrix = m_sMatWorld; break;
    case D3DTS_VIEW:  *pMatrix = m_sMatView; break;
    case D3DTS_PROJECTION:  *pMatrix = m_sMatProj; break;
    }
}

void inline CShaderObject::SetRenderTransform(D3DTRANSFORMSTATETYPE state, const D3DMATRIX* pMatrix)
{
    switch(state)
    {
    case D3DTS_WORLD: m_sMatWorld = *pMatrix; break;
    case D3DTS_VIEW:  m_sMatView = *pMatrix; break;
    case D3DTS_PROJECTION:  m_sMatProj = *pMatrix; break;
    }
    m_spD3DDevice->SetTransform( state, pMatrix );
}

#endif
