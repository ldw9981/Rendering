#ifndef _SHADERDEMO_H_
#define _SHADERDEMO_H_
#define STRICT
#include <D3DX8.h>
#include "D3DApp.h"
#include "D3DFont.h"
#include "object.h"
#include "room.h"
#include "camera.h"
#include "FnMap8.h"

// This hack allows for ARGB support for destination alpha blending.
#define HACK_FORCE_ARGB_BACKBUFFER_HACK 1

#define NUM_LIGHTS 2
#define NUM_OBJECTS  10
#define MAX_OBJECTS  20
#define ROOM_WIDTH  30
#define ROOM_HEIGHT 10
#define ROOM_DEPTH  30

typedef enum _EFFECTTYPE {
    ET_Ambient = 0,
    ET_Lit,
    ET_Shadow
} EFFECTTYPE;

typedef enum _CollisionStyle {
    CS_Sphere,
    CS_Box
} CollisionStyle;

//-----------------------------------------------------------------------------
// Function lookup texture classes
//-----------------------------------------------------------------------------
class CFalloffMap : public CVolumeMap8
{
public:
    CFalloffMap(UINT size);
    D3DXCOLOR Function(D3DXVECTOR3* p, D3DXVECTOR3* s);
};
class C1DFalloffMap : public CFnMap8
{
public:
    C1DFalloffMap(DWORD size);
    D3DXCOLOR Function(D3DXVECTOR2* p, D3DXVECTOR2* s);
};
class CSpecularMap : public CFnMap8
{
public:
    CSpecularMap(DWORD size);
    D3DXCOLOR Function(D3DXVECTOR2* p, D3DXVECTOR2* s);
};

//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
    CD3DFont* m_pFont;

    BOOL      m_bShowStatistics;
    BOOL      m_bShadowsOn;
    BOOL      m_bShowVolumes;
    BOOL      m_bGravityOn;
    BOOL      m_bPhysicsOn;
    DWORD     m_bAnimateLights;
    BOOL      m_bWireframe;
    
    CFalloffMap*   m_pFalloffMap;
    C1DFalloffMap* m_p1DFalloffMap;
    CSpecularMap*  m_pSpecularMap;
    CObject*       m_pObject[MAX_OBJECTS];
    CollisionStyle m_CollisionStyle[MAX_OBJECTS];
    CRoom*         m_pRoom;
    DWORD          m_dwNumLights;
    DWORD          m_dwNumObjects;

    EFFECTTYPE m_ActiveEffect;

    CCamera m_Camera;

    D3DLIGHT8 m_BaseLight;
    D3DLIGHT8 m_Light[MAX_OBJECTS];

    VOID    InitObjects();
    VOID    AddLight();
    VOID    AddObject();
    VOID    DeleteLight();
    VOID    DeleteObject();
    VOID    KickObjects();
    VOID    Physics();
    HRESULT RenderScene();
    VOID    SetMenuStates();

protected:
    HRESULT AdjustWindowForChange();
    HRESULT OneTimeSceneInit();
    HRESULT InitDeviceObjects();
    HRESULT RestoreDeviceObjects();
    HRESULT RestoreObjectDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();
    HRESULT Render();
    HRESULT FrameMove();
    HRESULT FinalCleanup();
    HRESULT ConfirmDevice( D3DCAPS8*, DWORD, D3DFORMAT );

public:
    CMyD3DApplication();

    LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
};


inline FLOAT RandNum(FLOAT low, FLOAT high)
{
    return ((rand() % 32768) / 32767.0f )* (high - low) + low;
}

#endif
