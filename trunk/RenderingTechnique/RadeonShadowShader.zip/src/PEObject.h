//-----------------------------------------------------------------------------
// Physics Engine Object
// 
// A base class for maintaining an object's position, velocity, etc and 
// animation.  Also provides basic physics groundwork for collisions (but not
// detection).  Can be used as a base class for all objects for maintaining
// position and velocity.
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#ifndef __PEOBJECT_HPP
#define __PEOBJECT_HPP

#include <math.h>
#include <stdio.h>
#include <D3DX8.h>

class CPEObject
{
public:

    // Class members
    static FLOAT       m_sfTime;
    static D3DXVECTOR3 m_svGravity;
    static VOID Collide(CPEObject& o1, CPEObject& o2, 
                        const D3DXVECTOR3& vPoint, 
                        const D3DXVECTOR3& vNormal1,
                        const D3DXVECTOR3& vNormal2);

    // Object specific
    D3DXVECTOR3 m_vCenterOfGravity;
    FLOAT       m_fMass;
    FLOAT       m_fAngInertiaOverMass;
    FLOAT       m_fAirResistance;
    FLOAT       m_fAngAirResistance;
    FLOAT       m_fCoeffOfFriction;
    FLOAT       m_fRigidity;        // Amount of collision energy reflected.

    // only really works for balls. And not well at all.
    FLOAT       m_fTension;   // on squish spring
    FLOAT       m_fDampening; // Resistance on the spring.

    // Forces in world space
    D3DXVECTOR3 m_vForce;
    D3DXVECTOR3 m_vAngForce;

    // Forces in object space
    D3DXVECTOR3 m_vObjForce;
    D3DXVECTOR3 m_vObjAngForce;

    CPEObject();

    VOID Advance(FLOAT fElapsedTime);
    VOID SaveState();
    VOID RestoreState();

    VOID SetTransform(const D3DXMATRIX& matrix);
    const D3DXMATRIX& GetTransform() const { return m_matWorld; };
    const D3DXVECTOR3& GetWorldCenterOfGravity();

    // in world space
    VOID Rotate(const D3DXQUATERNION& quat);
    VOID Rotate(const D3DXVECTOR3& vAmount);
    VOID Translate(const D3DXVECTOR3& vAmount);
    VOID SetVelocity(const D3DXVECTOR3& vVel);
    VOID SetAngVelocity(const D3DXVECTOR3& vAngVel);
    VOID SetSquishVelocity(const D3DXVECTOR3& vSquishVel);

protected:
    D3DXMATRIX  m_matStart;

    D3DXVECTOR3    m_vPosition;
    D3DXVECTOR3    m_vVelocity;
    D3DXQUATERNION m_qRotate;
    D3DXVECTOR3    m_vAngVelocity;
    D3DXVECTOR3    m_vSquish;
    D3DXVECTOR3    m_vSquishVelocity;
    D3DXMATRIX     m_matWorld;

    D3DXVECTOR3    m_vLastPosition;
    D3DXVECTOR3    m_vLastVelocity;
    D3DXQUATERNION m_qLastRotate;
    D3DXVECTOR3    m_vLastAngVelocity;
    D3DXVECTOR3    m_vLastSquish;
    D3DXVECTOR3    m_vLastSquishVelocity;
    D3DXMATRIX     m_matLastWorld;

    D3DXVECTOR3* AngularToLinearVelocity(D3DXVECTOR3* pvOut, const D3DXVECTOR3& vAngVelocity, const D3DXVECTOR3& vPoint);
    D3DXVECTOR3* LinearToAngularVelocity(D3DXVECTOR3* pvOut, const D3DXVECTOR3& vAngVelocity, const D3DXVECTOR3& vPoint);
    D3DXVECTOR3* GetPointVelocity(D3DXVECTOR3* pvOut, const D3DXVECTOR3& vPoint); 
    VOID         AddWorldspaceSquishVelocity(const D3DXVECTOR3& vSquishImpulse);

    D3DXMATRIX   m_matWorldInv;
    BOOL         m_bWorldInvValid;
    VOID         UpdateWorldMatrix();
    const D3DXMATRIX&  GetInvWorldMatrix();

    D3DXVECTOR3  m_vWorldCenterOfGravity;
    BOOL         m_bWorldCenterOfGravityValid;
};

#endif
