//-----------------------------------------------------------------------------
// POFMesh: Portable Object File Reader
//
// Reads a POF into a D3DXMesh object and lets D3DX optimize it.
// Then it builds various vertex buffers from the optimized stream.
// 
//-----------------------------------------------------------------------------
#ifndef __CPOFMESH_H
#define __CPOFMESH_H

#include <math.h>
#include "pof.h"

#define D3DFVF_POLY      (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_DIFFUSE | D3DFVF_SPECULAR | D3DFVF_TEX3 | D3DFVF_TEXCOORDSIZE3(1) | D3DFVF_TEXCOORDSIZE3(2)  )

#define POFMESH_DRAW_FVF_BUFFER 0
#define POFMESH_DRAW_COMPACT_BUFFER 1

#define POFMESH_INDEX_BUFFER_USAGE D3DUSAGE_WRITEONLY
#define POFMESH_INDEX_BUFFER_POOL  D3DPOOL_MANAGED

#define POFMESH_BUFFER_USAGE D3DUSAGE_WRITEONLY
#define POFMESH_BUFFER_POOL  D3DPOOL_MANAGED

#define POFMESH_NON_FVF_BUFFER_USAGE D3DUSAGE_WRITEONLY 
#define POFMESH_NON_FVF_BUFFER_POOL  D3DPOOL_MANAGED

#define POFMESH_MESH_OPTIONS (D3DXMESH_SYSTEMMEM)

class CPofMesh
{
protected:
   float          m_min[3];
   float          m_max[3];
   D3DXVECTOR3    m_centroid;
   float          m_dimensions[3];
   BOOL*          m_bHasTangentSpace;

   D3DXMATRIX    *m_xforms;
   D3DXMATRIX    *m_invXforms;

   LPDIRECT3DDEVICE8  m_pd3dDevice;
   LPDIRECT3D8        m_pd3d;

   DWORD m_numVerts;
   DWORD m_numFaces;

   D3DXVECTOR3 m_minPos;
   D3DXVECTOR3 m_maxPos;
   float       m_maxAbs;

   unsigned int             m_numFaceLists;           // Number of index buffers
   IDirect3DIndexBuffer8**  m_IndexBuffers;
   DWORD*                   m_IndexBufferSize;
   DWORD*                   m_IndexBufferMaxIndex;
   DWORD*                   m_CorrespondingVB;

   ID3DXMesh**              m_FVFMeshes;       // Pointer to array of FVF meshes
   ID3DXBuffer**            m_VtxRemap;        // Vertex optimization remapping

   IDirect3DVertexBuffer8** m_CompactVertexBuffers;   // Pointer to array of compact vertex buffers for vertex shader

   D3DXVECTOR3**            m_pAppSpacePos;           // Application-space positions
   D3DXVECTOR3**            m_pAppSpaceNormal;        // Application-space normals
   D3DXVECTOR3**            m_pAppSpaceTangent;       // Application-space tangents
   D3DXVECTOR3**            m_pAppSpaceBinormal;      // Application-space binormals

   void SetBoundingBox();

   virtual HRESULT InitializeBuffers(POF* pof);

public:
   CPofMesh();
   ~CPofMesh();

   HRESULT Initialize(char* pofFile, LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d);

   void Draw(unsigned int flags);
   void SetVertexShader(void);
   BYTE PackFloatInByte(float in);

   D3DXVECTOR3* GetCentroid();
   float* GetDimensions();
   void GetBoundingBox(D3DXVECTOR3* pMin, D3DXVECTOR3* pMax);
   float GetScale();

   DWORD  GetNumVerts();
   DWORD  GetNumFaces();

   BOOL m_bOptimizeMesh;
};


#endif __CPOFMESH_H
