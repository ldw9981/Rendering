//-----------------------------------------------------------------------------
// Shader Object
//
// A wrapper around the D3DX effects files and a cached texture manager.
// Also sets many of the common constants that are used in vertex and 
// pixel shaders.
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#include <tchar.h>
#include "d3dutil.h"
#include "dxutil.h"
#include "d3dapp.h"
#include "ShaderObject.h"
#include "DebugOutput.h"

#include <map>
#include <string>

static DWORD sgDeviceObjects  = 0;

LPDIRECT3DDEVICE8  CShaderObject::m_spD3DDevice                          = NULL;
LPDIRECT3D8        CShaderObject::m_spD3D                                = NULL;
TCHAR*             CShaderObject::m_sTexName[MAX_SHADER_TEXTURES]        = {NULL};
TCHAR*             CShaderObject::m_sStrTexFilename[MAX_SHADER_TEXTURES] = {NULL};
D3DFORMAT          CShaderObject::m_sTexFormat[MAX_SHADER_TEXTURES];
FLOAT              CShaderObject::m_sfBumpiness[MAX_SHADER_TEXTURES];
CShaderObject::TexProcess CShaderObject::m_sTexProcess[MAX_SHADER_TEXTURES];
IDirect3DBaseTexture8* CShaderObject::m_spTexture[MAX_SHADER_TEXTURES]   = {NULL};
CNormalizerMap8*   CShaderObject::m_spNormalizerMap                      = NULL;
D3DMATRIX          CShaderObject::m_sMatWorld;
D3DMATRIX          CShaderObject::m_sMatView;
D3DMATRIX          CShaderObject::m_sMatProj;

typedef struct _MapSource {
    std::string filename;
    CShaderObject::TexProcess proc;
    FLOAT bumpiness;

    // Comparison used for searching.
    bool operator <(const struct _MapSource& rhs) const
    {
        if (proc < rhs.proc) return true;
        if (proc > rhs.proc) return false;

        if (bumpiness < rhs.bumpiness) return true;
        if (bumpiness > rhs.bumpiness) return false;

        if (filename < rhs.filename) return true;
        return false;
    }
} MapSource;

typedef std::map<MapSource, IDirect3DBaseTexture8*> TextureHashTable;
static  TextureHashTable s_Textures;

// Loads a texture from a file, or returns a pointer if it was already loaded.
IDirect3DBaseTexture8* CShaderObject::LoadTextureFromFile(TCHAR* filename, D3DFORMAT format, TexProcess process, FLOAT fBumpiness)
{
    MapSource source;
    source.filename = filename;
    source.proc = process;
    source.bumpiness = fBumpiness;

    if (s_Textures.find(source) != s_Textures.end())
    {
        return s_Textures[source];
    }
    else
    {
        IDirect3DTexture8* pTex;
        if( FAILED( D3DUtil_CreateTexture( m_spD3DDevice, filename, &pTex, format ) ) )
        {
            OutputDebugString("Error loading texture, ");
            OutputDebugString(filename);
            OutputDebugString(".\n");
            s_Textures[source] = NULL;
        }
        else
        {
            switch(process)
            {
            case AsIs:
                s_Textures[source] = pTex;
                break;

            case BuildDuDvMap:
                s_Textures[source] = BuildUVOffsetTexture(m_spD3DDevice, m_spD3D, pTex);
                SAFE_RELEASE(pTex);
                break;

            case BuildNormalMap:
                s_Textures[source] = BuildNormalTexture(m_spD3DDevice, m_spD3D, pTex, fBumpiness);
                SAFE_RELEASE(pTex);
                break;
            }
        }
    }
    return s_Textures[source];
}


// Registers this texture for shared usage among all shader objects
VOID CShaderObject::LoadSharedTexture(TCHAR* name, TCHAR* filename, D3DFORMAT format, TexProcess process, FLOAT fBumpiness)
{
    int i;
    for (i = 0; i < MAX_SHADER_TEXTURES; i++)
    {
        if (m_sTexName[i] == NULL || strcmp(m_sTexName[i], name)==0 )
        {
            m_sTexName[i] = name;
            m_sStrTexFilename[i] = filename;
            m_sTexFormat[i] = format;
            m_sTexProcess[i] = process;
            m_sfBumpiness[i] = fBumpiness;
            if (m_spD3DDevice)
                m_spTexture[i] = LoadTextureFromFile(filename, format, process, fBumpiness);
            return;
        }
    }
    OutputDebugString("Too many registered shared textures! Increase the #define in ShaderObject.cpp\n");
}

// Textures that are registered this way are not recreated with the device.
VOID CShaderObject::RegisterSharedTexture(TCHAR* name, IDirect3DBaseTexture8* pTexture)
{
    for (int i = 0; i < MAX_SHADER_TEXTURES; i++)
    {
        if (m_sTexName[i] == NULL || strcmp(m_sTexName[i], name)==0 )
        {
            m_sTexName[i] = name;
            m_spTexture[i] = pTexture;
            return;
        }
    }
    OutputDebugString("Too many registered shared textures! Increase the #define in ShaderObject.cpp\n");
}

CShaderObject::CShaderObject() 
{
    m_dwCurrentEffect = 0;

    for (int i = 0; i < MAX_NUM_EFFECTS; i++)
    {
        m_strEffectFile[i]  = NULL;
        m_pEffect[i]        = NULL;
        m_strTechnique[i]   = NULL;
        m_IsTransparent[i]  = -1;
    }

    for (i = 0; i < MAX_SHADER_TEXTURES; i++)
    {
        m_texName[i] = NULL;
        m_strTexFilename[i] = NULL;
        m_pTexture[i] = NULL;
    }
}

CShaderObject::~CShaderObject()
{
    for (int i = 0; i < MAX_NUM_EFFECTS; i++)
        SAFE_DELETE(m_strEffectFile[i]);
}

HRESULT CShaderObject::SetEffectFile( DWORD effect, TCHAR* strFile )
{
    m_dwCurrentEffect = effect;

    if (strFile == NULL)
    {
        SAFE_DELETE(m_strEffectFile[effect]);
        SAFE_RELEASE(m_pEffect[effect]);
        return S_OK;
    }

    HRESULT hr;
    TCHAR* buf;

    if (strchr(strFile, '/') || strchr(strFile, '\\'))
    {
        buf = new TCHAR[strlen(strFile)+1];
        strcpy(buf, strFile);
    }
    else
    {
        buf = new TCHAR[strlen(strFile)+9];
        sprintf(buf, "Shaders\\%s", strFile);
    }

    SAFE_DELETE(m_strEffectFile[effect]);
    SAFE_RELEASE(m_pEffect[effect]);
    m_strEffectFile[effect] = buf;

    if (m_spD3DDevice)
    {
        // Load effects file
        if ( FAILED (hr = D3DXCreateEffectFromFile( m_spD3DDevice, m_strEffectFile[effect], &m_pEffect[effect], NULL) ) )
        {
            OutputDebugString("Error compiling effects file, ");
            OutputDebugString(m_strEffectFile[effect]);
            OutputDebugString(":\n");

            return hr;
        }

        if( FAILED( hr = SetTechnique(effect, m_strTechnique[effect]) ) )
            return hr;
    }

    return S_OK;
}

HRESULT CShaderObject::RecompileEffectFiles()
{
    HRESULT hr, hr2 = S_OK;
    DWORD curEffect = m_dwCurrentEffect;
    for (int effect = 0; effect < MAX_NUM_EFFECTS; effect++)
    {
        if ( FAILED( hr = SetEffectFile(effect, m_strEffectFile[effect]) ) )
            hr2 = hr;
    }
    m_dwCurrentEffect = curEffect;

    return hr2;
}

HRESULT CShaderObject::SetTechnique( DWORD effect, LPCSTR strTechnique )
{
    m_dwCurrentEffect = effect;

    if ((DWORD)strTechnique < 0x255) 
        return SetTechnique(effect, (DWORD)strTechnique);

    HRESULT hr;
    D3DXTECHNIQUE_DESC techniqueDesc;

    if (m_pEffect[effect] == NULL)
    {
        m_strTechnique[effect] = strTechnique;
        return S_OK;
    }

    if ( FAILED (hr = m_pEffect[effect]->FindNextValidTechnique(strTechnique, &techniqueDesc) ) )
    {
        DebugPrintf("%s: Failed to set technique, (%s).\n", m_strEffectFile[effect], strTechnique);
        return SetTechnique(effect, (DWORD)0);
    }

    m_pEffect[effect]->SetTechnique(strTechnique);
    if ( FAILED (hr = m_pEffect[effect]->Validate() ) )
    {
        DebugPrintf("%s: Failed to set technique, (%s).\n", m_strEffectFile[effect], strTechnique);
        return SetTechnique(effect, (DWORD)0);
    }

    m_strTechnique[effect] = strTechnique;

    m_IsTransparent[effect] = -1;

    SetUsedTextures(effect);

    MapUsedParameters(effect);

    return S_OK;
}

HRESULT CShaderObject::SetTechnique( DWORD effect, DWORD dwTechnique )
{
    m_dwCurrentEffect = effect;

    D3DXEFFECT_DESC effectDesc;

    if (m_pEffect[effect] == NULL)
        return E_FAIL;

    m_pEffect[effect]->GetDesc(&effectDesc);

    if(dwTechnique >= effectDesc.Techniques)
        dwTechnique = 0;

    m_strTechnique[effect] = (LPCSTR)dwTechnique;

    while(TRUE)
    {
        m_pEffect[effect]->SetTechnique((LPCSTR)dwTechnique);

        if( SUCCEEDED( m_pEffect[effect]->Validate() ) )
        {
            m_strTechnique[effect] = (LPCSTR)dwTechnique;
            
            m_IsTransparent[effect] = -1;

            SetUsedTextures(effect);

            MapUsedParameters(effect);

            return S_OK;
        } 
        else
        {
            D3DXTECHNIQUE_DESC desc;
            m_pEffect[effect]->GetTechniqueDesc((LPCSTR)dwTechnique, &desc);
            DebugPrintf("%s: Failed to set technique, %d (%s). Trying next.\n", m_strEffectFile[effect], dwTechnique+1, desc.Name);
            dwTechnique++;
            if(dwTechnique >= effectDesc.Techniques)
                dwTechnique = 0;

        }

        if(dwTechnique == (DWORD)m_strTechnique[effect])
        {
            DebugPrintf("Failed to set any technique.\n");
            SAFE_RELEASE(m_pEffect[effect]);
            break;
        }
    }

    return E_FAIL;
}

DWORD CShaderObject::GetTechnique( DWORD effect )
{
    if ((DWORD)m_strTechnique[effect] <= 255) 
        return (DWORD)m_strTechnique[effect];

    if (!m_pEffect[effect])
        return 0;

    D3DXTECHNIQUE_DESC desc;
    m_pEffect[effect]->GetTechniqueDesc(m_strTechnique[effect], &desc);
    return (DWORD)desc.Index;
}

LPCSTR CShaderObject::GetTechniqueName( DWORD effect )
{
    static char str[4];

    if ((DWORD)m_strTechnique[effect] > 255) 
        return m_strTechnique[effect];
    else if (!m_pEffect[effect])
    {
        sprintf(str, "%d", m_strTechnique[effect]);
        return str;
    }
    else
    {
        D3DXTECHNIQUE_DESC desc;
        m_pEffect[effect]->GetTechniqueDesc(m_strTechnique[effect], &desc);
        return desc.Name;
    }
}

BOOL CShaderObject::IsTransparent( DWORD effect )
{
    if (m_IsTransparent[effect] != -1)
        return m_IsTransparent[effect];
    else
        return TestTransparency(effect);
    
}

VOID CShaderObject::SetEffectNum( DWORD effect ) 
{ 
    if (effect < MAX_NUM_EFFECTS) 
        m_dwCurrentEffect = effect; 
}

BOOL CShaderObject::TestTransparency( DWORD effect )
{
    // Check if object this technique is transparent.
    DWORD dwAlphaBlendEnable;
    m_pEffect[effect]->Begin(NULL, NULL);
    m_pEffect[effect]->Pass(0);
    m_spD3DDevice->GetRenderState( D3DRS_ALPHABLENDENABLE, &dwAlphaBlendEnable );
    m_IsTransparent[effect] = (dwAlphaBlendEnable > 0);
    m_pEffect[effect]->End();

    return m_IsTransparent[effect];
}

void CShaderObject::SetUsedTextures(DWORD effect)
{
    // Set shared textures
    for (int i = 0; i < MAX_SHADER_TEXTURES; i++)
    {
        if (m_sTexName[i])
            if (m_pEffect[effect]->IsParameterUsed(m_sTexName[i]))
                m_pEffect[effect]->SetTexture(m_sTexName[i], m_spTexture[i]);
    }

    // Set shader specific textures
    for (i = 0; i < MAX_SHADER_TEXTURES; i++)
    {
        if (m_texName[i])
            if (m_pEffect[effect]->IsParameterUsed(m_texName[i]))
                m_pEffect[effect]->SetTexture(m_texName[i], m_pTexture[i]);
    }
}

enum CommonConsts
{
    CC_mW = 0,
    CC_mWt,
    CC_mV,
    CC_mP,
    CC_mWV,
    CC_mWVt,
    CC_mWVP,
    CC_pOV,
    CC_pWV,
    CC_cnst,
    CC_mWrt
};

#define FindParam(string, e) \
    if (m_pEffect[effect]->IsParameterUsed(string)) { \
        m_pEffect[effect]->GetParameterDesc(string, &desc); \
        map.param = e; \
        map.index = desc.Index; \
        m_ParamsUsed[effect].push_back(map); \
    }

void CShaderObject::MapUsedParameters(DWORD effect)
{
    D3DXPARAMETER_DESC desc;
    ParamIndexMap map;

    m_ParamsUsed[effect].clear();

    if(m_pEffect[effect] == NULL)
        return;

    FindParam("mW", CC_mW);
    FindParam("mV", CC_mV);
    FindParam("mP", CC_mP);
    FindParam("mWV", CC_mWV);
    FindParam("mWVt", CC_mWVt);
    FindParam("mWVP", CC_mWVP);
    FindParam("pOV", CC_pOV);
    FindParam("pWV", CC_pWV);
    FindParam("cnst", CC_cnst);
    FindParam("mWrt", CC_mWrt);
}

VOID CShaderObject::SetCommonShaderConstants(DWORD effect) 
{
    if (m_pEffect[effect] == NULL)
        return;

    // Set up vertex shader constants
    // Needs optimization.
    D3DXMATRIX matWorld, matView, matProj;
    D3DXMATRIX matWorldView, matWorldViewProj;
    D3DXMATRIX matWorldInv, matWorldInvTrans, matViewInv;
    D3DXMATRIX matWorldViewInv, matWorldViewInvTrans;

    GetRenderTransform( D3DTS_WORLD, &matWorld );
    GetRenderTransform( D3DTS_VIEW, &matView );
    GetRenderTransform( D3DTS_PROJECTION, &matProj );

    D3DXMatrixMultiply( &matWorldView, &matWorld, &matView ); 
    D3DXMatrixMultiply( &matWorldViewProj, &matWorldView, &matProj ); 
    D3DXMatrixInverse( &matWorldInv, NULL, &matWorld );
    D3DXMatrixTranspose( &matWorldInvTrans, &matWorldInv );
    D3DXMatrixInverse( &matViewInv, NULL, &matView );
    D3DXMatrixInverse( &matWorldViewInv, NULL, &matWorldView );
    D3DXMatrixTranspose( &matWorldViewInvTrans, &matWorldViewInv );

    D3DXVECTOR4 worldViewPos, objectViewPos;
    D3DXVec4Transform(&worldViewPos, &D3DXVECTOR4(0,0,0,1), &matViewInv);
    D3DXVec4Transform(&objectViewPos, &worldViewPos, &matWorldInv);

    // Common Constants 
    D3DXVECTOR4 vConst = D3DXVECTOR4(0.0f, 0.5f, 1.0f, 2.0f);

    // Assign constants
    for (std::vector<ParamIndexMap>::iterator iter = m_ParamsUsed[effect].begin(); iter != m_ParamsUsed[effect].end(); iter++)
    {
        switch(iter->param)
        {
        case CC_mW:   m_pEffect[effect]->SetMatrix( iter->index, &matWorld ); break;
        case CC_mWt:  m_pEffect[effect]->SetMatrix( iter->index, &matWorldInvTrans ); break;
        case CC_mV:   m_pEffect[effect]->SetMatrix( iter->index, &matView ); break;
        case CC_mP:   m_pEffect[effect]->SetMatrix( iter->index, &matProj ); break;
        case CC_mWV:  m_pEffect[effect]->SetMatrix( iter->index, &matWorldView ); break;
        case CC_mWVt: m_pEffect[effect]->SetMatrix( iter->index, &matWorldViewInvTrans ); break;
        case CC_mWVP: m_pEffect[effect]->SetMatrix( iter->index, &matWorldViewProj ); break;
        case CC_pOV:  m_pEffect[effect]->SetVector( iter->index, &objectViewPos ); break;
        case CC_pWV:  m_pEffect[effect]->SetVector( iter->index, &worldViewPos ); break;
        case CC_cnst: m_pEffect[effect]->SetVector( iter->index, &vConst ); break;
        case CC_mWrt: 
            {
                D3DXMATRIX matWorldRotation, matWorldRotationInv, matWorldRotationInvTrans;
                D3DXVECTOR3 p(1,1,1);
                D3DXVec3TransformNormal(&p,&p,&matWorld);
                float scale = D3DXVec3Length(&p)*.57735f;
                matWorldRotation = matWorld/scale;
                D3DXMatrixInverse(&matWorldRotationInv, NULL, &matWorldRotation);
                D3DXMatrixTranspose(&matWorldRotationInvTrans, &matWorldRotationInv);
                m_pEffect[effect]->SetMatrix( "mWrt", &matWorldRotationInvTrans );
            }
        }
    }
}

VOID CShaderObject::SetCommonShaderConstants(DWORD effect, const D3DLIGHT8* pLight) 
{
    SetCommonShaderConstants(effect);
    SetLightShaderConstants(effect, pLight);
}

VOID CShaderObject::SetCommonShaderConstants(DWORD effect, DWORD numLights, const D3DLIGHT8* pLight) 
{
    SetCommonShaderConstants(effect);
    SetLightShaderConstants(effect, numLights, pLight);
}

VOID CShaderObject::SetLightShaderConstants(DWORD effect, DWORD numLights, const D3DLIGHT8* pLight) 
{
    char suffix[4];
    for (int l = 0; l < numLights; l++)
    {
        if (l > 0)
        {
            sprintf(suffix,"%d",l+1);
            SetLightShaderConstants(effect, &(pLight[l]), suffix);
        } 
        else
        {
            SetLightShaderConstants(effect, &(pLight[l]));
        }  
    }
}

VOID CShaderObject::SetLightShaderConstants(DWORD effect, const D3DLIGHT8* pLight, char* suffix) 
{
    if (pLight == NULL)
        return;

    if (m_pEffect[effect] == NULL)
        return;

    // Set up vertex shader constants
    D3DXMATRIX matWorld, matView;
    D3DXMATRIX matWorldInv;

    GetRenderTransform( D3DTS_WORLD, &matWorld );
    GetRenderTransform( D3DTS_VIEW, &matView );

    D3DXMatrixInverse( &matWorldInv, NULL, &matWorld );

    // Calculate Light constants
    D3DXVECTOR4 worldLightPos, objectLightPos, viewLightPos, lightConsts, lightDirection;
    worldLightPos = D3DXVECTOR4(pLight->Position.x,
                                pLight->Position.y,
                                pLight->Position.z, 1);
    objectLightPos, viewLightPos;
    D3DXVec4Transform(&objectLightPos, &worldLightPos, &matWorldInv);
    D3DXVec4Transform(&viewLightPos, &worldLightPos, &matView);
    lightConsts = D3DXVECTOR4(1.0f/pLight->Range, 
                              pLight->Range, 
                              1/pLight->Attenuation2, 
                              pLight->Attenuation2);
    lightDirection = D3DXVECTOR4(pLight->Direction.x, pLight->Direction.y, pLight->Direction.z, 0);



    // Assign Light constants
    char pOL[16] = "pOL", pWL[16] = "pWL", pVL[16]="pVL", cLgt[16]="cLgt", cOLgtDir[16] = "cOLgtDir";
    strcat(pOL,suffix);
    strcat(pWL,suffix);
    strcat(pVL,suffix);
    strcat(cLgt,suffix);
    strcat(cOLgtDir,suffix);
    if (m_pEffect[effect]->IsParameterUsed(pOL))  m_pEffect[effect]->SetVector( pOL, &objectLightPos );
    if (m_pEffect[effect]->IsParameterUsed(pWL))  m_pEffect[effect]->SetVector( pWL, &worldLightPos );
    if (m_pEffect[effect]->IsParameterUsed(pVL))  m_pEffect[effect]->SetVector( pVL, &viewLightPos );
    if (m_pEffect[effect]->IsParameterUsed(cLgt)) m_pEffect[effect]->SetVector( cLgt, &lightConsts );
    if (m_pEffect[effect]->IsParameterUsed(cOLgtDir))
    {
        D3DXVECTOR4 objectLightDirection;
        D3DXVec4Transform(&objectLightDirection, &lightDirection, &matWorldInv);
        m_pEffect[effect]->SetVector( cOLgtDir, &objectLightDirection );
    }
}



VOID CShaderObject::LoadTexture(TCHAR* name, TCHAR* filename, D3DFORMAT format, TexProcess process, FLOAT fBumpiness)
{
    int i;
    for (i = 0; i < MAX_SHADER_TEXTURES; i++)
    {
        if (m_texName[i] == NULL || strcmp(m_texName[i], name)==0 )
        {
            m_texName[i] = name;
            m_strTexFilename[i] = filename;
            m_texFormat[i] = format;
            m_texProcess[i] = process;
            m_fBumpiness[i] = fBumpiness;
            if (m_spD3DDevice)
            {
                m_pTexture[i] = LoadTextureFromFile(filename, format, process, fBumpiness);
                for (int effect = 0; effect < MAX_NUM_EFFECTS; effect++)
                    if(m_pEffect[effect] != NULL)
                        if (m_pEffect[effect]->IsParameterUsed(m_texName[i]))
                            m_pEffect[effect]->SetTexture(m_texName[i], m_pTexture[i]);
            }
            return;
        }
    }
    OutputDebugString("Too many textures in one object! Increase the #define in ShaderObject.cpp\n");
}

VOID CShaderObject::RegisterTexture(TCHAR* name, IDirect3DBaseTexture8* pTexture)
{
    for (int i = 0; i < MAX_SHADER_TEXTURES; i++)
    {
        if (m_texName[i] == NULL || strcmp(m_texName[i], name)==0 )
        {
            m_texName[i] = name;
            m_pTexture[i] = pTexture;
            return;
        }
    }
    OutputDebugString("Too many textures in one object! Increase the #define in ShaderObject.cpp\n");
}

HRESULT CShaderObject::InitDeviceObjects(LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d)
{
    // Create object
    if (sgDeviceObjects++ == 0)
    {
        m_spD3DDevice = d3dDevice;
        m_spD3D = d3d;

        for (int i = 0; i < MAX_SHADER_TEXTURES; i++)
            if (m_sTexName[i] != NULL && m_sStrTexFilename[i] != NULL)
                m_spTexture[i] = LoadTextureFromFile(m_sStrTexFilename[i], m_sTexFormat[i], m_sTexProcess[i], m_sfBumpiness[i]);

        m_spNormalizerMap = new CNormalizerMap8();
        m_spNormalizerMap->Initialize(m_spD3DDevice);
        RegisterSharedTexture( "tNormalizer", m_spNormalizerMap->GetTexture() );
    }

    for (int i = 0; i < MAX_SHADER_TEXTURES; i++)
        if (m_texName[i] != NULL && m_strTexFilename[i] != NULL)
            m_pTexture[i] = LoadTextureFromFile(m_strTexFilename[i], m_texFormat[i], m_texProcess[i], m_fBumpiness[i]);

    return S_OK;
}

HRESULT CShaderObject::RestoreDeviceObjects()
{
    HRESULT hr, hr2 = S_OK;

    DWORD curEffect = m_dwCurrentEffect;
    for (int effect = 0; effect < MAX_NUM_EFFECTS; effect++)
    {
        if ( FAILED( hr = SetEffectFile(effect, m_strEffectFile[effect]) ) )
            hr2 = hr;
    }
    m_dwCurrentEffect = curEffect;

    for (effect = 0; effect < MAX_NUM_EFFECTS; effect++)
        if (m_pEffect[effect])
        {
            MapUsedParameters(effect);
            SetUsedTextures(effect);
        }

    return hr2;
}


HRESULT CShaderObject::InvalidateDeviceObjects()
{
    for (int effect = 0; effect < MAX_NUM_EFFECTS; effect++)
    {
        SAFE_RELEASE(m_pEffect[effect]);
    }

    return S_OK;
}

HRESULT CShaderObject::DeleteDeviceObjects()
{
    for (int i = 0; i < MAX_SHADER_TEXTURES; i++)
        if (m_texName[i] != NULL)
            m_pTexture[i] = NULL;

    sgDeviceObjects--;
    if (sgDeviceObjects == 0)
    {
        // Delete all cached textures
        TextureHashTable::iterator iter;
        for (iter = s_Textures.begin(); iter != s_Textures.end(); ++iter)
        {
            SAFE_RELEASE(iter->second);
        }
        s_Textures.clear();

        // clear shared texture list
        for (int i = 0; i < MAX_SHADER_TEXTURES; i++)
        {
            if (m_sTexName[i] != NULL)
                m_spTexture[i] = NULL;
            if (m_sStrTexFilename[i] == NULL)
                m_sTexName[i] = NULL;
        }

        SAFE_DELETE(m_spNormalizerMap);
        m_spD3DDevice = NULL;
        m_spD3D = NULL;
    }
    return S_OK;    
}
