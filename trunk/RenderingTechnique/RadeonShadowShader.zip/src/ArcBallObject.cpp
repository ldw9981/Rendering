//-----------------------------------------------------------------------------
// ArcBallObject.cpp
// 
// Adds mouse and keyboard control to a CPEObject
// Right mouse button controls rotation
// Left mouse button control position
// Middle mouse button moves in and out
// 
// Derivative classes can change the transforms for motion and rotation to
// whatever is needed to align the screen to the object.
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#include "ArcBallObject.h"
#include "dxutil.h"
#include "resource.h"

int CArcBallObject::m_sScreenWidth;
int CArcBallObject::m_sScreenHeight;

void CArcBallObject::SetScreenSize(int w, int h)
{
    m_sScreenWidth = w;
    m_sScreenHeight = h;
}

//-----------------------------------------------------------------------------
// Transform matrix for mouse motion UI. 
//-----------------------------------------------------------------------------
const D3DXMATRIX& CArcBallObject::GetMouseMotionTransform()
{
    return m_matWorld;
}

const D3DXMATRIX& CArcBallObject::GetMouseRotationTransform()
{
    return m_matWorld;
}

D3DXVECTOR3 CArcBallObject::GetMouseRotationSpeed()
{
    return D3DXVECTOR3(1,1,1);
}

//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Message proc function to handle key and menu input
//-----------------------------------------------------------------------------
LRESULT CArcBallObject::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    // Parse mouse messages
    static int lastx, lasty;
    static D3DXVECTOR3 pos;
    if( WM_MOUSEMOVE == uMsg )
    {
        float scale = (float)min(m_sScreenWidth, m_sScreenHeight);

        D3DXVECTOR2 drag((LOWORD(lParam) - lastx) / scale, (HIWORD(lParam) - lasty) / scale);

        if (wParam & MK_RBUTTON)
        {
            D3DXVECTOR3 v(drag.x, drag.y, 0);
            D3DXVec3TransformNormal(&v, &v, &GetMouseMotionTransform());
            Translate(v);
        } 
        else if (wParam & MK_MBUTTON)
        {
            D3DXVECTOR3 v(0, 0, drag.y);
            D3DXVec3TransformNormal(&v, &v, &GetMouseMotionTransform());
            Translate(v);
        }
        else if (wParam & MK_LBUTTON)
        {
            D3DXVECTOR3 drag3, axis;
            drag3.x = max(-1, min(1,  (2*(LOWORD(lParam) - m_sScreenWidth/2)/scale)));
            drag3.y = max(-1, min(1, -(2*(HIWORD(lParam) - m_sScreenHeight/2)/scale)));
            drag3.z = sqrtf(max(0,1 - drag3.x*drag3.x - drag3.y*drag3.y));
            D3DXVec3Cross(&axis, &drag3, &pos);
            if (D3DXVec3LengthSq(&axis) > 0 && D3DXVec3LengthSq(&drag3) > 0 && D3DXVec3LengthSq(&pos) > 0) {
                D3DXVec3Normalize(&axis, &axis);
                D3DXVec3Normalize(&drag3, &drag3);
                D3DXVec3Normalize(&pos, &pos);
                float angle = acosf(max(-1.0f, min(1.0f, D3DXVec3Dot(&drag3, &pos))));
                D3DXVECTOR3 vSpeed = GetMouseRotationSpeed();
                vSpeed.x *= axis.x;
                vSpeed.y *= axis.y;
                vSpeed.z *= axis.z;
                FLOAT speed = D3DXVec3Length(&vSpeed);
                D3DXVec3TransformNormal(&axis, &axis, &GetMouseRotationTransform());
                D3DXQUATERNION quat;
                D3DXQuaternionRotationAxis(&quat, &axis, speed*angle);
                Rotate(quat);
            }
        } 

        pos.x = max(-1, min(1,  (2*(LOWORD(lParam) - m_sScreenWidth/2)/scale)));
        pos.y = max(-1, min(1, -(2*(HIWORD(lParam) - m_sScreenHeight/2)/scale)));
        pos.z = sqrtf(max(0,1 - pos.x*pos.x - pos.y*pos.y));

        lastx = LOWORD(lParam);
        lasty = HIWORD(lParam);
    }

    return S_OK;
}

