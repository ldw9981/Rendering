#ifndef TEXBUMPUTIL_HPP
#define TEXBUMPUTIL_HPP

#include <stdio.h>

#include <d3d8.h>
#include <d3dx8.h>

#include "DXUtil.h"
//#include "SSPrintUtils.hpp"
#include "TexCreationUtils8.hpp"

//set this to -(bumpheight in pixels)/256 to change size of bumps
#define TBU_BUMPINESS 0.02f  /*full intensity range represents bumps of roughly 5 pixels in height*/

LPDIRECT3DTEXTURE8 BuildUVOffsetTexture(LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d, LPDIRECT3DTEXTURE8 pTextureHF);
LPDIRECT3DTEXTURE8 BuildNormalTexture(LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d, LPDIRECT3DTEXTURE8 pTextureHF, FLOAT fBumpiness = TBU_BUMPINESS);


#endif //TEXBUMPUTIL_HPP
