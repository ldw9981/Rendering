//
// File: Path.cpp
// Author: Evan Hart, ATI Research Inc
// Date: September 26, 2000
//
///////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <string.h>

#include "Path.h"


//////////////////////////////////////////////////////////////////////////
//
// Methods for path virtual base class
//
//
//////////////////////////////////////////////////////////////////////////

//
// Constructor and destructor
/////////////////////////////////////////////////////
path::path()
{
   m_numPoints = 0;
   m_times = NULL;
   m_positions = NULL;
   m_orientations = NULL;
}

path::~path()
{
   if (m_times)
   {
      delete []m_times;
   }

   if (m_positions)
   {
      delete []m_positions;
   }

   if (m_orientations)
   {
      delete []m_orientations;
   }
}

//
// Get the length of the path in time
/////////////////////////////////////////////////////
float path::getLength( )
{
   return m_times[m_numPoints-1];
}

//
// Get the number of control points
/////////////////////////////////////////////////////
int path::getNumControlPoints( )
{
   return m_numPoints;
}

//
// Get a control point from the array
/////////////////////////////////////////////////////
void path::getControlPoint( int which, float &time, float position[3], float orientation[4])
{
   //ignoring error checking for perf
   time = m_times[which];
   memcpy( position, m_positions[which].pos, sizeof(float)*3);
   memcpy( orientation, m_orientations[which].quat, sizeof(float)*4);
}

//
// Set a contol point
/////////////////////////////////////////////////////
void path::setControlPoint( int which, float time, float position[3], float orientation[4])
{
   if ( which >= m_numPoints)
   {
      if ( ( which >= (((m_numPoints/20)+((m_numPoints%20)?1:0))*20) ) || (m_numPoints==0) )
      {
         //reallocate and copy the arrays
         int alloc;
         Position *tempP;
         Quaternion *tempQ;
         float *tempT;

         alloc = (((which+1)/20)+1)*20;

         tempP = new Position[alloc];
         tempQ = new Quaternion[alloc];
         tempT = new float[alloc];

         //is this correct???
         memcpy( tempP, m_positions, sizeof(Position)*m_numPoints);
         memcpy( tempQ, m_orientations, sizeof(Quaternion)*m_numPoints);
         memcpy( tempT, m_times, sizeof(float)*m_numPoints);

         delete []m_positions;
         delete []m_orientations;
         delete []m_times;

         m_positions = tempP;
         m_orientations = tempQ;
         m_times = tempT;

         
      }
      m_numPoints = which+1;
   }

   m_times[which] = time;
   memcpy( m_positions[which].pos, position, sizeof(float)*3);
   memcpy( m_orientations[which].quat, orientation, sizeof(float)*4);
}

//
// Find the closest control point to a dive position
/////////////////////////////////////////////////////
int path::getClosest( float position[3])
{
   int ii;
   int min = -1;
   float dist;
   float vector[3];
   float minDist = 100000000.0f;

   for (ii=0; ii<m_numPoints; ii++)
   {
      vector[0] = position[0] - m_positions[ii].pos[0];
      vector[1] = position[1] - m_positions[ii].pos[1];
      vector[2] = position[2] - m_positions[ii].pos[2];
      
      dist = vector[0]*vector[0] + vector[1]*vector[1] + vector[2]*vector[2];

      if ( dist < minDist )
      {
         minDist = dist;
         min = ii;
      }
   }

   return min;
}


//////////////////////////////////////////////////////////////////////////
//
// Methods for closed path class
//
//
//////////////////////////////////////////////////////////////////////////

//
// constructor
/////////////////////////////////////////////////////
closedPath::closedPath()
{
   m_compiled = false;
   m_duration = 0.0f;

   m_X = NULL;
   m_Y = NULL;
   m_Z = NULL;
   m_d2X = NULL;
   m_d2Y = NULL;
   m_d2Z = NULL;

   m_qX = NULL;
   m_qY = NULL;
   m_qZ = NULL;
   m_qW = NULL;
   m_d2qX = NULL;
   m_d2qY = NULL;
   m_d2qZ = NULL;
   m_d2qW = NULL;

   m_T = NULL;
}

//
// destructor
/////////////////////////////////////////////////////
closedPath::~closedPath()
{
   if ( m_X )
   {
      delete []m_X;
      m_X = NULL;

      delete []m_Y;
      m_Y = NULL;

      delete []m_Z;
      m_Z = NULL;

      delete []m_d2X;
      m_d2X = NULL;

      delete []m_d2Y;
      m_d2Y = NULL;

      delete []m_d2Z;
      m_d2Z = NULL;

      delete []m_qX;
      m_qX = NULL;

      delete []m_qY;
      m_qY = NULL;

      delete []m_qZ;
      m_qZ = NULL;

      delete []m_qW;
      m_qW = NULL;

      delete []m_d2qX;
      m_d2qX = NULL;

      delete []m_d2qY;
      m_d2qY = NULL;

      delete []m_d2qZ;
      m_d2qZ = NULL;

      delete []m_d2qW;
      m_d2qW = NULL;

      delete []m_T;
      m_T = NULL;
   }
}


//
// 
/////////////////////////////////////////////////////
void closedPath::evalPosition( float time, float position[3])
{
   float t;
   int hi,lo,test;
   float a,b,interval;
   float a3,b3;

   if (!m_compiled)
   {
      Compile();
   }

   t = (float) fmod( time, m_duration);

   //binary search
   lo=0;
   hi=m_numPoints;

   while ( (hi-lo) > 1 )
   {
      test = (hi+lo) >>1;
      if ( t < m_T[test])
      {
         hi = test;
      }
      else
      {
         lo=test;
      }
   }

   interval = m_T[hi] - m_T[lo];
   a = (m_T[hi]-t) / interval;
   b = (t-m_T[lo]) / interval;
   a3 = a*a*a;
   b3 = b*b*b;

   position[0] = (a*m_X[lo]) + (b*m_X[hi]) + ((a3-a)*m_d2X[lo] + (b3-b)*m_d2X[hi]) * ((interval*interval)/6.0f);
   position[1] = (a*m_Y[lo]) + (b*m_Y[hi]) + ((a3-a)*m_d2Y[lo] + (b3-b)*m_d2Y[hi]) * ((interval*interval)/6.0f);
   position[2] = (a*m_Z[lo]) + (b*m_Z[hi]) + ((a3-a)*m_d2Z[lo] + (b3-b)*m_d2Z[hi]) * ((interval*interval)/6.0f);

}

//
// 
/////////////////////////////////////////////////////
void closedPath::evalOrientation( float time, float orientation[4])
{
   float t;
   int hi,lo,test;
   float a,b,interval;
   float a3,b3;
   float temp, tempQ[4];

   if (!m_compiled)
   {
      Compile();
   }

   t = (float) fmod( time, m_duration);

   //binary search
   lo=0;
   hi=m_numPoints;

   while ( (hi-lo) > 1 )
   {
      test = (hi+lo) >>1;
      if ( t < m_T[test])
      {
         hi = test;
      }
      else
      {
         lo=test;
      }
   }

   interval = m_T[hi] - m_T[lo];
   a = (m_T[hi]-t) / interval;
   b = (t-m_T[lo]) / interval;
   a3 = a*a*a;
   b3 = b*b*b;

   tempQ[0] = (a*m_qX[lo]) + (b*m_qX[hi]) + ((a3-a)*m_d2qX[lo] + (b3-b)*m_d2qX[hi]) * ((interval*interval)/6.0f);
   tempQ[1] = (a*m_qY[lo]) + (b*m_qY[hi]) + ((a3-a)*m_d2qY[lo] + (b3-b)*m_d2qY[hi]) * ((interval*interval)/6.0f);
   tempQ[2] = (a*m_qZ[lo]) + (b*m_qZ[hi]) + ((a3-a)*m_d2qZ[lo] + (b3-b)*m_d2qZ[hi]) * ((interval*interval)/6.0f);
   tempQ[3] = (a*m_qW[lo]) + (b*m_qW[hi]) + ((a3-a)*m_d2qW[lo] + (b3-b)*m_d2qW[hi]) * ((interval*interval)/6.0f);

   //R4 space -> S3 space
  temp = 1.0f/((tempQ[0]*tempQ[0])+(tempQ[1]*tempQ[1])+(tempQ[2]*tempQ[2])+(tempQ[3]*tempQ[3]));
  orientation[0] =(2.0f*tempQ[0]*tempQ[3]) * temp;
  orientation[1] =(2.0f*tempQ[1]*tempQ[3]) * temp;
  orientation[2] =(2.0f*tempQ[2]*tempQ[3]) * temp;
  orientation[3] =((tempQ[0]*tempQ[0])+(tempQ[1]*tempQ[1])+(tempQ[2]*tempQ[2])-(tempQ[3]*tempQ[3]))*temp;

  temp = orientation[0]*orientation[0] + orientation[1]*orientation[1] +
         orientation[2]*orientation[2] + orientation[3]*orientation[3];

  if (temp>0.0f)
  {
     temp = 1.0f/(float)sqrt(temp);
  }

  orientation[0] *= temp;
  orientation[1] *= temp;
  orientation[2] *= temp;
  orientation[3] *= temp;
}

//
// 
/////////////////////////////////////////////////////
void closedPath::evalGLMatrix( float time, float matrix[16])
{

}

//
// 
/////////////////////////////////////////////////////
void closedPath::Compile()
{
   int ii;
   float *tX, *tY, *tZ, *tW, *iX, *iY, *iZ, *iW, *td2X, *td2Y, *td2Z, *td2W, *tT;
   float temp, deltaT;
//   float tempQuat[4];
   float dot;

   //make sure we have enough points
   if (m_numPoints<4)
   {
      return;
   }

   //first deallocate any old data
   if ( m_X )
   {
      delete []m_X;
      m_X = NULL;

      delete []m_Y;
      m_Y = NULL;

      delete []m_Z;
      m_Z = NULL;

      delete []m_d2X;
      m_d2X = NULL;

      delete []m_d2Y;
      m_d2Y = NULL;

      delete []m_d2Z;
      m_d2Z = NULL;

      delete []m_qX;
      m_qX = NULL;

      delete []m_qY;
      m_qY = NULL;

      delete []m_qZ;
      m_qZ = NULL;

      delete []m_qW;
      m_qW = NULL;

      delete []m_d2qX;
      m_d2qX = NULL;

      delete []m_d2qY;
      m_d2qY = NULL;

      delete []m_d2qZ;
      m_d2qZ = NULL;

      delete []m_d2qW;
      m_d2qW = NULL;

      delete []m_T;
      m_T = NULL;
   }

   tX = new float[m_numPoints+5];
   tY = new float[m_numPoints+5];
   tZ = new float[m_numPoints+5];
   tW = new float[m_numPoints+5];
   iX = new float[m_numPoints+5];
   iY = new float[m_numPoints+5];
   iZ = new float[m_numPoints+5];
   iW = new float[m_numPoints+5];
   td2X = new float[m_numPoints+5];
   td2Y = new float[m_numPoints+5];
   td2Z = new float[m_numPoints+5];
   td2W = new float[m_numPoints+5];
   tT = new float[m_numPoints+5];

   m_X = new float[m_numPoints+1];
   m_Y = new float[m_numPoints+1];
   m_Z = new float[m_numPoints+1];
   m_d2X = new float[m_numPoints+1];
   m_d2Y = new float[m_numPoints+1];
   m_d2Z = new float[m_numPoints+1];

   m_qX = new float[m_numPoints+1];
   m_qY = new float[m_numPoints+1];
   m_qZ = new float[m_numPoints+1];
   m_qW = new float[m_numPoints+1];
   m_d2qX = new float[m_numPoints+1];
   m_d2qY = new float[m_numPoints+1];
   m_d2qZ = new float[m_numPoints+1];
   m_d2qW = new float[m_numPoints+1];

   m_T = new float[m_numPoints+1];

   for (ii=0; ii<m_numPoints; ii++)
   {
      tX[ii+2] = m_positions[ii].pos[0];
      tY[ii+2] = m_positions[ii].pos[1];
      tZ[ii+2] = m_positions[ii].pos[2];
      tT[ii+2] = m_times[ii];

      if ( (ii) && (m_times[ii-1] >= m_times[ii]))
      {
            delete []tX;
            delete []tY;
            delete []tZ;
            delete []tW;
            delete []iX;
            delete []iY;
            delete []iZ;
            delete []iW;
            delete []tT;
            delete []td2X;
            delete []td2Y;
            delete []td2Z;
            delete []td2W;
            return; //times are not monotonically increasing
      }
   }

   tX[0] = m_positions[m_numPoints-2].pos[0];
   tY[0] = m_positions[m_numPoints-2].pos[1];
   tZ[0] = m_positions[m_numPoints-2].pos[2];
   tX[1] = m_positions[m_numPoints-1].pos[0];
   tY[1] = m_positions[m_numPoints-1].pos[1];
   tZ[1] = m_positions[m_numPoints-1].pos[2];
   tX[m_numPoints+2] = m_positions[0].pos[0];
   tY[m_numPoints+2] = m_positions[0].pos[1];
   tZ[m_numPoints+2] = m_positions[0].pos[2];
   tX[m_numPoints+3] = m_positions[1].pos[0];
   tY[m_numPoints+3] = m_positions[1].pos[1];
   tZ[m_numPoints+3] = m_positions[1].pos[2];

   tT[0] = m_times[m_numPoints-2] - m_duration;
   tT[1] = m_times[m_numPoints-1] - m_duration;
   tT[m_numPoints+2] = m_duration;
   tT[m_numPoints+3] = m_duration + m_times[1] - m_times[0];
   tT[m_numPoints+4] = m_duration + m_times[2] - m_times[0];

   
   td2X[0] = 0.0f;
   td2Y[0] = 0.0f;
   td2Z[0] = 0.0f;
   iX[0] = 0.0f;
   iY[0] = 0.0f;
   iZ[0] = 0.0f;

   //now compute the terms
   for (ii=1; ii<m_numPoints+3; ii++)
   {
      //calculate time delta
      deltaT = (tT[ii] - tT[ii-1]) / (tT[ii+1] - tT[ii-1]);

      //calculate X terms
      temp = (deltaT * td2X[ii-1] + 2.0f);
      td2X[ii] = (deltaT - 1.0f) / temp;
      iX[ii] = ((tX[ii+1] - tX[ii]) / (tT[ii+1] - tT[ii])) -
               ((tX[ii] - tX[ii-1]) / (tT[ii] - tT[ii-1]));
      iX[ii] = (((6.0f * iX[ii]) / (tT[ii+1] - tT[ii-1])) - (deltaT * iX[ii-1])) / temp;

      //calculate Y terms
      temp = (deltaT * td2Y[ii-1] + 2.0f);
      td2Y[ii] = (deltaT - 1.0f) / temp;
      iY[ii] = ((tY[ii+1] - tY[ii]) / (tT[ii+1] - tT[ii])) -
               ((tY[ii] - tY[ii-1]) / (tT[ii] - tT[ii-1]));
      iY[ii] = (((6.0f * iY[ii]) / (tT[ii+1] - tT[ii-1])) - (deltaT * iY[ii-1])) / temp;

      //calculate Z terms
      temp = (deltaT * td2Z[ii-1] + 2.0f);
      td2Z[ii] = (deltaT - 1.0f) / temp;
      iZ[ii] = ((tZ[ii+1] - tZ[ii]) / (tT[ii+1] - tT[ii])) -
               ((tZ[ii] - tZ[ii-1]) / (tT[ii] - tT[ii-1]));
      iZ[ii] = (((6.0f * iZ[ii]) / (tT[ii+1] - tT[ii-1])) - (deltaT * iZ[ii-1])) / temp;
   }

   //flatten everything
   td2X[m_numPoints+3] = 0.0f;
   td2Y[m_numPoints+3] = 0.0f;
   td2Z[m_numPoints+3] = 0.0f;

   for (ii=m_numPoints+2; ii>=0; ii--)
   {
      td2X[ii] = td2X[ii]*td2X[ii+1] + iX[ii];
      td2Y[ii] = td2Y[ii]*td2Y[ii+1] + iY[ii];
      td2Z[ii] = td2Z[ii]*td2Z[ii+1] + iZ[ii];
   }


   //copy the data (this can probably be eliminated)
   for (ii=0; ii<m_numPoints; ii++)
   {
      m_X[ii] = tX[ii+2];
      m_Y[ii] = tY[ii+2];
      m_Z[ii] = tZ[ii+2];
      m_d2X[ii] = td2X[ii+2];
      m_d2Y[ii] = td2Y[ii+2];
      m_d2Z[ii] = td2Z[ii+2];

      m_T[ii] = tT[ii+2];
   }

   m_X[m_numPoints] =tX[2];
   m_Y[m_numPoints] =tY[2];
   m_Z[m_numPoints] =tZ[2];
   m_d2X[m_numPoints] =td2X[2];
   m_d2Y[m_numPoints] =td2Y[2];
   m_d2Z[m_numPoints] =td2Z[2];

   m_T[m_numPoints] = m_duration;

   //////
   //
   // Now do the quaternions
   //
   //////

   //load the quaternions into a linear array to handle sign problems
   for (ii=0; ii<m_numPoints; ii++)
   {
      tX[ii+2] = m_orientations[ii].quat[0];
      tY[ii+2] = m_orientations[ii].quat[1];
      tZ[ii+2] = m_orientations[ii].quat[2];
      tW[ii+2] = m_orientations[ii].quat[3];
   }

   tX[0] = m_orientations[m_numPoints-2].quat[0];
   tY[0] = m_orientations[m_numPoints-2].quat[1];
   tZ[0] = m_orientations[m_numPoints-2].quat[2];
   tW[0] = m_orientations[m_numPoints-2].quat[3];

   tX[1] = m_orientations[m_numPoints-1].quat[0];
   tY[1] = m_orientations[m_numPoints-1].quat[1];
   tZ[1] = m_orientations[m_numPoints-1].quat[2];
   tW[1] = m_orientations[m_numPoints-1].quat[3];

   tX[m_numPoints+2] = m_orientations[0].quat[0];
   tY[m_numPoints+2] = m_orientations[0].quat[1];
   tZ[m_numPoints+2] = m_orientations[0].quat[2];
   tW[m_numPoints+2] = m_orientations[0].quat[3];

   tX[m_numPoints+3] = m_orientations[1].quat[0];
   tY[m_numPoints+3] = m_orientations[1].quat[1];
   tZ[m_numPoints+3] = m_orientations[1].quat[2];
   tW[m_numPoints+3] = m_orientations[1].quat[3];

   tX[m_numPoints+4] = m_orientations[2].quat[0];
   tY[m_numPoints+4] = m_orientations[2].quat[1];
   tZ[m_numPoints+4] = m_orientations[2].quat[2];
   tW[m_numPoints+4] = m_orientations[2].quat[3];

   //swap and remap to R4 space
   for (ii=0; ii<m_numPoints+4; ii++)
   {
      dot = tX[ii]*tX[ii+1] + tY[ii]*tY[ii+1] + tZ[ii]*tZ[ii+1] + tW[ii]*tW[ii+1];

      if (dot<0.0f)
      {
         tX[ii+1] *= -1.0f;
         tY[ii+1] *= -1.0f;
         tZ[ii+1] *= -1.0f;
         tW[ii+1] *= -1.0f;
      }
      temp = 1.0f / (float)sqrt(2.0f*(1.0f - tW[ii]));
      tX[ii] = tX[ii] * temp;
      tY[ii] = tY[ii] * temp;
      tZ[ii] = tZ[ii] * temp;
      tW[ii] = (1.0f - tW[ii]) * temp;
   }

   temp = 1.0f / (float)sqrt(2.0f*(1.0f - tW[m_numPoints+4]));
   tX[m_numPoints+4] = tX[m_numPoints+4] * temp;
   tY[m_numPoints+4] = tY[m_numPoints+4] * temp;
   tZ[m_numPoints+4] = tZ[m_numPoints+4] * temp;
   tW[m_numPoints+4] = (1.0f - tW[m_numPoints+4]) * temp;


   td2X[0] = 0.0f;
   td2Y[0] = 0.0f;
   td2Z[0] = 0.0f;
   td2W[0] = 0.0f;
   iX[0] = 0.0f;
   iY[0] = 0.0f;
   iZ[0] = 0.0f;
   iW[0] = 0.0f;

   //now compute the terms
   for (ii=1; ii<m_numPoints+4; ii++)
   {
      //calculate time delta
      deltaT = (tT[ii] - tT[ii-1]) / (tT[ii+1] - tT[ii-1]);

      //calculate X terms
      temp = (deltaT * td2X[ii-1] + 2.0f);
      td2X[ii] = (deltaT - 1.0f) / temp;
      iX[ii] = ((tX[ii+1] - tX[ii]) / (tT[ii+1] - tT[ii])) -
               ((tX[ii] - tX[ii-1]) / (tT[ii] - tT[ii-1]));
      iX[ii] = (((6.0f * iX[ii]) / (tT[ii+1] - tT[ii-1])) - (deltaT * iX[ii-1])) / temp;

      //calculate Y terms
      temp = (deltaT * td2Y[ii-1] + 2.0f);
      td2Y[ii] = (deltaT - 1.0f) / temp;
      iY[ii] = ((tY[ii+1] - tY[ii]) / (tT[ii+1] - tT[ii])) -
               ((tY[ii] - tY[ii-1]) / (tT[ii] - tT[ii-1]));
      iY[ii] = (((6.0f * iY[ii]) / (tT[ii+1] - tT[ii-1])) - (deltaT * iY[ii-1])) / temp;

      //calculate Z terms
      temp = (deltaT * td2Z[ii-1] + 2.0f);
      td2Z[ii] = (deltaT - 1.0f) / temp;
      iZ[ii] = ((tZ[ii+1] - tZ[ii]) / (tT[ii+1] - tT[ii])) -
               ((tZ[ii] - tZ[ii-1]) / (tT[ii] - tT[ii-1]));
      iZ[ii] = (((6.0f * iZ[ii]) / (tT[ii+1] - tT[ii-1])) - (deltaT * iZ[ii-1])) / temp;

      //calculate W terms
      temp = (deltaT * td2W[ii-1] + 2.0f);
      td2W[ii] = (deltaT - 1.0f) / temp;
      iW[ii] = ((tW[ii+1] - tW[ii]) / (tT[ii+1] - tT[ii])) -
               ((tW[ii] - tW[ii-1]) / (tT[ii] - tT[ii-1]));
      iW[ii] = (((6.0f * iW[ii]) / (tT[ii+1] - tT[ii-1])) - (deltaT * iW[ii-1])) / temp;
   }

   //flatten everything
   td2X[m_numPoints+4] = 0.0f;
   td2Y[m_numPoints+4] = 0.0f;
   td2Z[m_numPoints+4] = 0.0f;
   td2W[m_numPoints+4] = 0.0f;

   for (ii=m_numPoints+3; ii>=0; ii--)
   {
      td2X[ii] = td2X[ii]*td2X[ii+1] + iX[ii];
      td2Y[ii] = td2Y[ii]*td2Y[ii+1] + iY[ii];
      td2Z[ii] = td2Z[ii]*td2Z[ii+1] + iZ[ii];
      td2W[ii] = td2W[ii]*td2W[ii+1] + iW[ii];
   }

   //copy the data (this can probably be eliminated)
   for (ii=0; ii<=m_numPoints; ii++)
   {
      m_qX[ii] = tX[ii+2];
      m_qY[ii] = tY[ii+2];
      m_qZ[ii] = tZ[ii+2];
      m_qW[ii] = tW[ii+2];
      m_d2qX[ii] = td2X[ii+2];
      m_d2qY[ii] = td2Y[ii+2];
      m_d2qZ[ii] = td2Z[ii+2];
      m_d2qW[ii] = td2W[ii+2];

   }
/*
   m_qX[m_numPoints] =tX[2];
   m_qY[m_numPoints] =tY[2];
   m_qZ[m_numPoints] =tZ[2];
   m_qW[m_numPoints] =tW[2];
   m_d2qX[m_numPoints] =td2X[2];
   m_d2qY[m_numPoints] =td2Y[2];
   m_d2qZ[m_numPoints] =td2Z[2];
   m_d2qW[m_numPoints] =td2W[2];
*/
   delete []tX;
   delete []tY;
   delete []tZ;
   delete []tW;
   delete []iX;
   delete []iY;
   delete []iZ;
   delete []iW;
   delete []tT;
   delete []td2X;
   delete []td2Y;
   delete []td2Z;
   delete []td2W;

   m_compiled = true;
}

//
// 
/////////////////////////////////////////////////////
void closedPath::SetDuration( float duration)
{
   m_duration = duration;
}

//
// Get the length in time until the path loops
/////////////////////////////////////////////////////
float closedPath::GetDuration()
{
   return m_duration;
}