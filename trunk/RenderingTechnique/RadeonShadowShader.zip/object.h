//-----------------------------------------------------------------------------
// object.hpp
//-----------------------------------------------------------------------------
#ifndef __OBJECT_HPP
#define __OBJECT_HPP

#include <D3DX8.h>
#include "ShadowPOF.h"
#include "PEObject.h"
#include "ShaderObject.h"

class CObject : public CPEObject, public CShaderObject
{
    CShadowPOF* m_pObject;

public:
    // View space z compare for sorting
    static BOOL IsFurther(CObject* obj1, CObject* obj2); 

protected:
    BOOL m_bSetScale;

public:

    TCHAR* m_strObjectFile;

    CObject();

    HRESULT            RenderShadowVolume(const D3DLIGHT8* light);
    HRESULT            Render(DWORD effect, const D3DLIGHT8* light = NULL);
    const D3DXVECTOR3& GetCentroid() { return *m_pObject->GetCentroid(); };
    float              GetObjectSize() { return m_pObject->GetScale(); };
    VOID               GetBoundingBox(D3DXVECTOR3* pMin, D3DXVECTOR3* pMax) { 
                                    m_pObject->GetBoundingBox(pMin, pMax); };
    float              GetWorldRadius(const D3DXVECTOR3& vDirection);

    HRESULT InitDeviceObjects( LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d );
    HRESULT DeleteDeviceObjects();
};

#endif
