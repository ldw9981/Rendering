//-----------------------------------------------------------------------------
// room.hpp
//-----------------------------------------------------------------------------
#ifndef __ROOM_HPP
#define __ROOM_HPP

#include <math.h>
#include <stdio.h>
#include <D3DX8.h>
#include "DXUtil.h"
#include "PEObject.h"
#include "ShaderObject.h"

class CRoom : public CPEObject, public CShaderObject
{
    class Vertex {
    public:
        D3DXVECTOR3 p, n;
        FLOAT       s, t;
        D3DXVECTOR3 tan;

        Vertex() : s(0), t(0) {};
        Vertex(D3DXVECTOR3 _p, D3DXVECTOR3 _n, FLOAT _s, FLOAT _t, D3DXVECTOR3 _tan) :
        p(_p), n(_n), s(_s), t(_t), tan(_tan) {};

    };

    Vertex m_pWall[6][4];
    DWORD m_dwVBStartWall[6];

    LPDIRECT3DVERTEXBUFFER8 m_pVertexBuffer;

    HRESULT InitVertexBuffer();

public:
    CRoom(FLOAT fWidth, FLOAT fHeight, FLOAT fDepth);

    D3DXVECTOR3 m_vNormal[6];

    HRESULT Render(DWORD effect, const D3DLIGHT8* pLight = NULL);
    
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
};

#endif
