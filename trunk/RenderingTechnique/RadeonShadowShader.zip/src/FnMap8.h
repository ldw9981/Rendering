//-----------------------------------------------------------------------------
// FnMap8
// 
// Dx8 C++ style implementation of a procedural textures
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------

#ifndef __CFNMAP8_HPP
#define __CFNMAP8_HPP

#include <d3d8.h>
#include <d3dx8.h>


////////////////////////////////////////////////////////////////////////////////////
// CBaseMap8: Base class so that different implementations can be stored together //
////////////////////////////////////////////////////////////////////////////////////
class CBaseMap8
{
protected:
   LPDIRECT3DDEVICE8  m_pd3dDevice;
   LPDIRECT3DBASETEXTURE8 m_pTexture;

public:
   CBaseMap8();
   ~CBaseMap8();

   LPDIRECT3DBASETEXTURE8 GetTexture() { return m_pTexture; };
   virtual HRESULT Initialize(LPDIRECT3DDEVICE8 d3dDevice) = 0;

   UINT m_dwLevels;
   D3DFORMAT m_Format;
};

//////////////////////////////////////////////////////////////////////////////
// CFnMap8: 2D procedural texture
//////////////////////////////////////////////////////////////////////////////
class CFnMap8 : public CBaseMap8
{
private:
   static VOID Fill2DWrapper(D3DXVECTOR4* pOut, D3DXVECTOR2* pTexCoord, D3DXVECTOR2* pTexelSize, LPVOID pData);

protected:
   virtual D3DXCOLOR Function(D3DXVECTOR2* pTexCoord, D3DXVECTOR2* pTexelSize) = 0;

public:
   CFnMap8();
   HRESULT Initialize(LPDIRECT3DDEVICE8 d3dDevice);

   UINT m_dwWidth, m_dwHeight;
};

//////////////////////////////////////////////////////////////////////////////
// CVolumeMap8: 3D procedural texture
//////////////////////////////////////////////////////////////////////////////
class CVolumeMap8 : public CBaseMap8
{
private:
   static VOID Fill3DWrapper(D3DXVECTOR4* pOut, D3DXVECTOR3* pTexCoord, D3DXVECTOR3* pTexelSize, LPVOID pData);

protected:
   virtual D3DXCOLOR Function(D3DXVECTOR3* pTexCoord, D3DXVECTOR3* pTexelSize) = 0;

public:
   CVolumeMap8();
   HRESULT Initialize(LPDIRECT3DDEVICE8 d3dDevice);

   UINT m_dwWidth, m_dwHeight, m_dwDepth;
};

//////////////////////////////////////////////////////////////////////////////
// CCubeMap8
//////////////////////////////////////////////////////////////////////////////
class CCubeMap8 : public CBaseMap8
{
private:
   static VOID Fill3DWrapper(D3DXVECTOR4* pOut, D3DXVECTOR3* pTexCoord, D3DXVECTOR3* pTexelSize, LPVOID pData);

protected:
   virtual D3DXCOLOR Function(D3DXVECTOR3* pTexCoord, D3DXVECTOR3* pTexelSize) = 0;

public:
   CCubeMap8();
   HRESULT Initialize(LPDIRECT3DDEVICE8 d3dDevice);

   UINT m_dwSize;
};


////////////////////////////////////////////////////////////////////////////////////
// CNormalizeMap8: An instance of the CCubeMap8 that creates a normalizer cube map
////////////////////////////////////////////////////////////////////////////////////
class CNormalizerMap8 : public CCubeMap8
{
protected:
   virtual D3DXCOLOR Function(D3DXVECTOR3* pTexCoord, D3DXVECTOR3* pTexelSize);

public:
   CNormalizerMap8();
};

#endif __CFNMAP8_HPP
