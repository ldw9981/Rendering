//-----------------------------------------------------------------------------
// Fly Path Object
// 
// A object that add fly path support to a physics engine object
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#include "FlyPathPEObject.h"
#include "DebugOutput.h"
#include "dxutil.h"
#include "resource.h"
#include "PofMesh.h"

// -------------------------------------------------------------------------
// Fly path 
#define NUM_FLY_LOOPS    1
#define NUM_LINE_VERTS   600

#define LINE_FVF     D3DFVF_XYZ | D3DFVF_DIFFUSE

typedef struct LINE_VERTEX
{
   D3DXVECTOR3 m_vecPos;
   DWORD       m_color;
} LINE_VERTEX;

// -------------------------------------------------------------------------

CFlyPathPEObject::CFlyPathPEObject()
{
    m_bGotFocus = FALSE;
    m_pWayPoints               = NULL;
    m_fFlyTime                 = 0.0f;
    m_bAutoFlying              = TRUE;
    m_pFlyPath                 = NULL;
}

CFlyPathPEObject::~CFlyPathPEObject()
{
    SAFE_DELETE( m_pWayPoints );
    SAFE_DELETE( m_pFlyPath );
}

void CFlyPathPEObject::LoadPath(char* filename)
{
    // Open flypath file to read
    FILE *fp = fopen(filename,"r");

    if(!fp)
    {
      DebugPrintf("FlyPathPEObject: Couldn't find the flypath file: %s!\n", filename);
      m_bAutoFlying = FALSE;
      return;
    }

    // Number of waypoints in this path file
    fscanf(fp," %d %f", &m_NumWayPoints, &m_fAnimationLength);

    // Allocate space for the waypoints and lines for drawing them
    SAFE_DELETE(m_pWayPoints);
    m_pWayPoints = new WayPoint[m_NumWayPoints];


    // Compute seconds per waypoint based on animation length, number of waypoints etc
    m_NumLoops = NUM_FLY_LOOPS;
    m_fSecondsPerWayPoint = (m_fAnimationLength * m_NumLoops) / m_NumWayPoints;

    // Read waypoints in from file
    for (int i=0; i<m_NumWayPoints; i++)
    {
      fscanf(fp," %f", &m_pWayPoints[i].pos.x);           // Read Position
      fscanf(fp," %f", &m_pWayPoints[i].pos.y); 
      fscanf(fp," %f", &m_pWayPoints[i].pos.z);
 
      fscanf(fp," %f", &m_pWayPoints[i].orientation.x);   // Read Orientation
      fscanf(fp," %f", &m_pWayPoints[i].orientation.y); 
      fscanf(fp," %f", &m_pWayPoints[i].orientation.z);
      fscanf(fp," %f", &m_pWayPoints[i].orientation.w);
    }

    fclose(fp);

    CreatePathFromWaypoints (m_pWayPoints, &m_pFlyPath);
}

void CFlyPathPEObject::Advance(FLOAT fElapsedTime) 
{
    if (m_bAutoFlying)
        m_fFlyTime += fElapsedTime;

    if (m_pFlyPath && m_bAutoFlying)
    {
        D3DXVECTOR3 pos;
        D3DXQUATERNION orientation;
        D3DXMATRIX matFudge, matView;
        m_pFlyPath->evalPosition(m_fFlyTime, (float*)&pos);
        m_pFlyPath->evalOrientation(m_fFlyTime, (float*)&orientation);
        
        SetTransform(m_matStart);
        Rotate(orientation);
        Translate(pos);
    }
}

void CFlyPathPEObject::CreatePathFromWaypoints (WayPoint *aWayPoints, closedPath **aPath)
{
    int i;
    D3DXVECTOR3 pos;
    D3DXQUATERNION orientation;

    SAFE_DELETE(*aPath);

    *aPath = new closedPath();

    // run through all the way points
    for (i=0; i<m_NumWayPoints; i++)
    {
        pos = aWayPoints[i].pos;
        orientation = aWayPoints[i].orientation;

        // add it to the closed path
        (*aPath)->setControlPoint(i, m_fSecondsPerWayPoint*i, (float*)&pos, (float*)&orientation);
    }

    (*aPath)->SetDuration(m_fAnimationLength * m_NumLoops);
}

//-----------------------------------------------------------------------------
// Transform matrix for mouse motion UI. 
//-----------------------------------------------------------------------------
const D3DXMATRIX& CFlyPathPEObject::GetMotionTransform()
{
    return m_matWorld;
}

//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Message proc function to handle key and menu input
//-----------------------------------------------------------------------------
LRESULT CFlyPathPEObject::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    if ( WM_SETFOCUS == uMsg )
        m_bGotFocus = TRUE;
    
    else if ( WM_KILLFOCUS == uMsg )
        m_bGotFocus = FALSE;

    // Handle menu commands
    else if( WM_COMMAND == uMsg )
    {
        switch( LOWORD(wParam) )
        {
            case IDM_AUTO_FLY: 
                m_bAutoFlying = !m_bAutoFlying;
                break;
       }
    }

    // Parse mouse messages
    if( WM_MOUSEMOVE == uMsg )
        CArcBallObject::MsgProc(hWnd, uMsg, wParam, lParam);

    return S_OK;
}

