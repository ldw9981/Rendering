//-----------------------------------------------------------------------------
// Camera
// 
// A Fly Path Object with a few twists of being a camera and adds keyboard controls
// Also has some frustum cull helper functions.
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#ifndef _CAMERA_H_
#define _CAMERA_H_
#include <D3DX8.h>
#include "FlyPathPEObject.h"
#include "path.h"

class CCamera : public CFlyPathPEObject
{
    LPDIRECT3DDEVICE8 m_pD3DDevice;

    virtual const D3DXMATRIX& GetMouseMotionTransform();
    virtual D3DXVECTOR3 GetMouseRotationSpeed();

public:
    CCamera();

    const D3DXMATRIX& GetViewTransform();
    VOID Advance(FLOAT fElapsedTime);
};

void CalculateFrustumPlanes (const D3DXVECTOR3& cameraPos, const D3DXMATRIX& matView, FLOAT perspectiveAngle, FLOAT aspect, FLOAT nearPlane, FLOAT farPlane);
BOOL IsBoundingSphereInFrustum (FLOAT radius, const D3DXVECTOR3& center);

#endif
