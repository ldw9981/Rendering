//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winmain.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDR_POPUP                       142
#define IDD_SELECTDEVICE                144
#define IDC_DEVICE_COMBO                1000
#define IDC_MODE_COMBO                  1001
#define IDC_ADAPTER_COMBO               1002
#define IDC_FULLSCREENMODES_COMBO       1003
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_WINDOWED_CHECKBOX           1012
#define IDC_FULLSCREEN_TEXT             1014
#define IDC_WINDOW                      1016
#define IDC_FULLSCREEN                  1018
#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_TOGGLESTART                 40004
#define IDM_SINGLESTEP                  40005
#define IDM_EXIT                        40006
#define IDM_SHOWSHADOWVOLUMES           40011
#define IDM_GRAVITY                     40012
#define IDM_PHYSICS                     40013
#define IDM_SHADOWS                     40015
#define IDM_ADDLIGHT                    40019
#define IDM_DELETELIGHT                 40020
#define IDM_ANIMATELIGHTS               40021
#define IDM_AUTO_FLY                    40031
#define IDM_ADDOBJECT                   40039
#define IDM_DELETEOBJECT                40040
#define IDM_KICKOBJECTS                 40041
#define IDM_WIREFRAME                   40043
#define IDM_SHOWSTATISTICS              40044
#define IDM_REFRESHSHADERS              40045
#define ID_KEYCONTROLHELP_PITCH         40048
#define ID_KEYCONTROLHELP_FORWARDBACK   40049
#define ID_KEYCONTROLHELP_LEFTRIGHT     40050
#define ID_KEYCONTROLHELP_UPDOWN        40051
#define ID_KEYCONTROLHELP_ROLL          40052
#define ID_KEYCONTROLHELP_SETTECHNIQUE  40053
#define ID_KEYCONTROLHELP_SETAMBIENTTECHNIQUE 40054

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         40055
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
