//-----------------------------------------------------------------------------
// POFMesh: Portable Object File Reader
//
// Reads a POF into a D3DXMesh object and lets D3DX optimize it.
// Then it builds various vertex buffers from the optimized stream.
// 
//-----------------------------------------------------------------------------
#include <stdio.h>
#include <d3d8.h>
#include <d3dapp.h>
#include <D3DX8.h>
#include <DXUtil.h>
#include "PofMesh.h"
#include "pof.h"
#include "pofDefines.h"
#include "pofTypes.h"

#define NORMAL_COLOR        0xFFFF0000
#define TANGENT_COLOR       0xFF00FF00
#define BINORMAL_COLOR      0xFF0000FF
#define WIRE_COLOR          0xFFFFFFFF

#define PACKINTOBYTE_0TO1(x)      ((char)((x)*255))
#define PACKINTOBYTE_MINUS1TO1(x) ((char)((x)*127.5+127.5))

#define SIGN(x) ((x)<0.0)?(-1.0):(1.0)



static WORD g_cubeIndices[24] = { 0, 1,
                                  1, 2,
                                  2, 3,
                                  3, 0,
                                  4, 5,
                                  5, 6,
                                  6, 7, 
                                  7, 4,
                                  0, 4,
                                  1, 5,
                                  2, 6,
                                  3, 7};


//////////////////////////////////////////////////////////////////////////////
// Types /////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

// 48 bytes per vertex/ 384 bits  FVF type for fixed function pipeline
typedef struct D3D_FVF_VERTEX
{
    D3DXVECTOR3 m_vecPos;
    D3DXVECTOR3 m_vecNorm;
    D3DCOLOR    m_color;
    D3DCOLOR    m_spec;
    D3DXVECTOR2 m_vecTex;
    D3DXVECTOR3 m_vecLight;
    D3DXVECTOR3 m_vecHalf;

} D3D_FVF_VERTEX;

//32 bytes per vertex/ 256 bits   non-fvf for programmable pipeline
typedef struct D3D_COMPACT_VERTEX
{
    D3DXVECTOR3     m_vecPos;
    char            m_ui8pNorm[4];         //normal
    D3DXVECTOR2     m_vecTex;              //base texture coords
    char            m_ui8pBinormal[4];     //binormal (encoded as direction of positive u)
    char            m_ui8pTangent[4];      //tangent (encoded as direction of positive v)
} D3D_COMPACT_VERTEX;


typedef struct D3D_LINE_VERTEX
{
    D3DXVECTOR3 m_vecPos;
    D3DCOLOR    m_color;
} D3D_LINE_VERTEX;


//////////////////////////////////////////////////////////////////////////////
// CPofMesh implementation ///////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////


CPofMesh::CPofMesh()
{
   m_numVerts=0;
   m_numFaces=0;
   m_bHasTangentSpace=NULL;

   m_xforms=NULL;
   m_invXforms=NULL;

   m_pd3dDevice=NULL;
   m_pd3d=NULL;

   m_numFaceLists=0;

   m_IndexBuffers=NULL;
   m_IndexBufferSize=NULL;
   m_IndexBufferMaxIndex=NULL;
   m_CorrespondingVB=NULL;

   m_bOptimizeMesh = TRUE;
   m_FVFMeshes=NULL;
   m_VtxRemap=NULL;
   m_CompactVertexBuffers=NULL;

   m_pAppSpacePos=NULL;
   m_pAppSpaceNormal=NULL;
   m_pAppSpaceTangent=NULL;
   m_pAppSpaceBinormal=NULL;

}


CPofMesh::~CPofMesh()
{
   unsigned int i;

   // Release index buffers and vertex buffers
   for (i=0; i < m_numFaceLists; i++)
   {
      SAFE_RELEASE( m_IndexBuffers[i] );
      if(m_FVFMeshes!=NULL)
         SAFE_RELEASE( m_FVFMeshes[i] );

      if(m_VtxRemap!=NULL)
         SAFE_RELEASE( m_VtxRemap[i] );

      if(m_CompactVertexBuffers!=NULL)
         SAFE_RELEASE( m_CompactVertexBuffers[m_CorrespondingVB[i]] );

      free( m_pAppSpacePos[m_CorrespondingVB[i]] );
      free( m_pAppSpaceNormal[m_CorrespondingVB[i]] );

      if(m_bHasTangentSpace[i])
      {
         free( m_pAppSpaceTangent[m_CorrespondingVB[i]] );
         free( m_pAppSpaceBinormal[m_CorrespondingVB[i]] );
      }
   }

   free( m_FVFMeshes );
   free( m_VtxRemap );
   free( m_CompactVertexBuffers );
   free( m_bHasTangentSpace );

   free( m_IndexBuffers );
   free( m_IndexBufferSize );
   free( m_IndexBufferMaxIndex );
   free( m_CorrespondingVB );

   free( m_pAppSpacePos );
   free( m_pAppSpaceNormal );
   free( m_pAppSpaceTangent );
   free( m_pAppSpaceBinormal );

}

D3DXVECTOR3* CPofMesh::GetCentroid()
{
  return &m_centroid;
}


float CPofMesh::GetScale()
{
  return m_maxAbs;
}

float* CPofMesh::GetDimensions()
{
  return m_dimensions;
}

VOID CPofMesh::GetBoundingBox(D3DXVECTOR3* pMin, D3DXVECTOR3* pMax)
{
  *pMin = m_minPos;
  *pMax = m_maxPos;
}

DWORD CPofMesh::GetNumVerts()
{
  return m_numVerts;
}

DWORD CPofMesh::GetNumFaces()
{
  return m_numFaces;
}


HRESULT
CPofMesh::Initialize(char* pofFile, LPDIRECT3DDEVICE8 d3dDevice, LPDIRECT3D8 d3d)
{
   HRESULT hr;

   // take device pointer from app
   m_pd3dDevice = d3dDevice;
   m_pd3d = d3d;

   // Open .pof file
   TCHAR strPath[MAX_PATH];
   if (FAILED (hr = DXUtil_FindMediaFile( strPath, pofFile ) ) )
   {
      OutputDebugString("Can't find POF file: ");
      OutputDebugString(pofFile);
      OutputDebugString("\n");
      return D3DAPPERR_MEDIANOTFOUND;
   }

   POF* pof = pofOpen(strPath, POF_MODE_READ);

   hr = InitializeBuffers(pof);

   pofClose(pof);

   return hr;
}

HRESULT
CPofMesh::InitializeBuffers(POF* pof)
{
   POFFaceChunk     face;
   POFVertexChunk   vtx;
   POFNormalChunk   norm;
   POFColorChunk    color;
   POFTexCoordChunk tex, tan, binorm;
   unsigned int *indices;
   unsigned int i, j, jr, ColorComponents;
   WORD* pIndex;
	D3D_FVF_VERTEX        *pVertices;
	D3D_COMPACT_VERTEX    *pCompactVertices;
   DWORD* pVtxRemap;


   D3DXVECTOR3* verts;
   D3DXVECTOR3* norms;
   D3DXVECTOR3* tangents;
   D3DXVECTOR3* binormals;
   float*       colors;
   D3DXVECTOR2* texCoords;
   BYTE r, g, b, a;
   
   // Set min and max positions
   m_minPos = D3DXVECTOR3( FLT_MAX, FLT_MAX, FLT_MAX );
   m_maxPos = D3DXVECTOR3( -FLT_MAX, -FLT_MAX, -FLT_MAX );

   m_numFaceLists = pofGetNumObjects(pof, POF_TYPE_FACE);

   // Allocate space for index buffers and their counts for polygons
   m_IndexBuffers = (IDirect3DIndexBuffer8 **) calloc(m_numFaceLists*sizeof(LPDIRECT3DINDEXBUFFER8),1);
   m_IndexBufferSize = (DWORD *) calloc(m_numFaceLists*sizeof(DWORD),1);
   m_IndexBufferMaxIndex = (DWORD *) calloc(m_numFaceLists*sizeof(DWORD),1);
   m_CorrespondingVB  = (DWORD *) calloc(m_numFaceLists*sizeof(DWORD),1);

   // Allocate space for vertex buffers for polygons
   m_FVFMeshes = (ID3DXMesh **) calloc(m_numFaceLists*sizeof(ID3DXMesh*),1);
   m_VtxRemap = (ID3DXBuffer **) calloc(m_numFaceLists*sizeof(ID3DXBuffer*),1);

   m_CompactVertexBuffers = (IDirect3DVertexBuffer8 **) calloc(m_numFaceLists*sizeof(LPDIRECT3DVERTEXBUFFER8),1);

   // Allocate space for pointers to application-space vertex position and tangent space axes
   m_pAppSpacePos        = (D3DXVECTOR3**) calloc(m_numFaceLists*sizeof(D3DXVECTOR3*),1);
   m_pAppSpaceNormal     = (D3DXVECTOR3**) calloc(m_numFaceLists*sizeof(D3DXVECTOR3*),1);
   m_pAppSpaceTangent    = (D3DXVECTOR3**) calloc(m_numFaceLists*sizeof(D3DXVECTOR3*),1);
   m_pAppSpaceBinormal   = (D3DXVECTOR3**) calloc(m_numFaceLists*sizeof(D3DXVECTOR3*),1);
   m_bHasTangentSpace    = (BOOL *)        calloc(m_numFaceLists*sizeof(BOOL),1);


   // clear counters
   m_numVerts = m_numFaces = 0;


   // First pass through all objects to create the base FVF buffers and compute overall bounding box 
   for (i=0; i < m_numFaceLists; i++)
   {
      indices = (unsigned int *)pofGetFaceList(pof, pofGetObjectNames(pof, POF_TYPE_FACE)[i], &face);
      verts     = (D3DXVECTOR3 *) pofGetVertexList(pof,   face.coordSet, 0, &vtx);
      norms     = (D3DXVECTOR3 *) pofGetNormalList(pof,   face.coordSet, 0, &norm);
      tangents  = (D3DXVECTOR3 *) pofGetTexCoordList(pof, face.coordSet, POF_TCI_TAN0, &tan);
      binormals = (D3DXVECTOR3 *) pofGetTexCoordList(pof, face.coordSet, POF_TCI_BINORM0, &binorm);
      texCoords = (D3DXVECTOR2 *) pofGetTexCoordList(pof, face.coordSet, 0, &tex);
      colors    = (float *)       pofGetColorList(pof, face.coordSet, 0, &color);

      m_numVerts += vtx.count;
      m_numFaces += face.count;
      m_CorrespondingVB[i] = face.coordSet;
      m_IndexBufferSize[i] = face.count * 3;


      // Create Base FVF Mesh
      if( FAILED( D3DXCreateMeshFVF(face.count, vtx.count, POFMESH_MESH_OPTIONS, D3DFVF_POLY, m_pd3dDevice, &m_FVFMeshes[i]) ) )
      {
         OutputDebugString("Unable to create FVF mesh.\n");
      }

      if((binormals != NULL) && (tangents != NULL))
         m_bHasTangentSpace[i] = TRUE;
      else
         m_bHasTangentSpace[i] = FALSE;

      switch(color.format & 0xffff)
      {
          case POF_COLOR_RGB:
            ColorComponents = 3;
            break;
          case POF_COLOR_RGBA:
            ColorComponents = 4;
            break;
          default:
            ColorComponents = 3;
//            OutputDebugString("Bad color format\n");
            break;
      };

      // Lock index buffer and fill with data
      m_FVFMeshes[i]->LockIndexBuffer( 0, (BYTE**)&pIndex);
      for(j=0; j < m_IndexBufferSize[i]; j++)
      {
         pIndex[j] = indices[j];
      }

      // Lock Vertex Buffer and fill  with data.
      m_FVFMeshes[i]->LockVertexBuffer( 0, (BYTE**)&pVertices );

      // Fill in any components of vertex that are present and find bounding box
      for(j=0; j < vtx.count; j++)
      {
         if(verts)
         {
            pVertices[j].m_vecPos = verts[j];
            if(verts[j].x < m_minPos.x)
               m_minPos.x = verts[j].x;
            if(verts[j].y < m_minPos.y)
               m_minPos.y = verts[j].y;
            if(verts[j].z < m_minPos.z)
               m_minPos.z = verts[j].z;

            if(verts[j].x > m_maxPos.x)
               m_maxPos.x = verts[j].x;
            if(verts[j].y > m_maxPos.y)
               m_maxPos.y = verts[j].y;
            if(verts[j].z > m_maxPos.z)
               m_maxPos.z = verts[j].z;
         }

         if(norms)
         {
            pVertices[j].m_vecNorm = norms[j];
         }

         if(texCoords)
         {
            // hack for ogl/d3d difference
            texCoords[j].y = 1-texCoords[j].y;
            pVertices[j].m_vecTex = texCoords[j];
         }

         if(colors)
         {
            if(ColorComponents == 3)
            {
               r = (BYTE) (255.0f * colors[j*3+0]);
               g = (BYTE) (255.0f * colors[j*3+1]);
               b = (BYTE) (255.0f * colors[j*3+2]);
               a = 0xFF;
            }
            else // must be 4
            {
               r = (BYTE) (255.0f * colors[j*4+0]);
               g = (BYTE) (255.0f * colors[j*4+1]);
               b = (BYTE) (255.0f * colors[j*4+2]);
               a = (BYTE) (255.0f * colors[j*4+3]);
            }

            pVertices[j].m_color = D3DCOLOR_RGBA(r, g, b, a); // pack into DWORD
         }
         else
         {
            pVertices[j].m_color = WIRE_COLOR;
         }
      }

      // Optimize Mesh
      if (m_bOptimizeMesh)
      {
         DWORD* pAdjacency = new DWORD[m_FVFMeshes[i]->GetNumFaces()*3];
         m_FVFMeshes[i]->GenerateAdjacency(0.0f, pAdjacency);
         if( FAILED( m_FVFMeshes[i]->OptimizeInplace(D3DXMESHOPT_COMPACT | D3DXMESHOPT_STRIPREORDER, pAdjacency, NULL, NULL, &m_VtxRemap[i]) ) )
         {
               OutputDebugString("Unable to optimize mesh.\n");
         }

         // Copy new indices back to app's index buffer
         for(j=0; j < m_IndexBufferSize[i]; j++)
         {
            indices[j] = pIndex[j];
         }
         SAFE_DELETE( pAdjacency );
      }

      m_FVFMeshes[i]->UnlockIndexBuffer();
      m_FVFMeshes[i]->UnlockVertexBuffer();
   }

   m_centroid = (m_maxPos+m_minPos)*.5;
   m_maxAbs = 0;

   // second pass: Now create vertex buffers
   for (i=0; i < m_numFaceLists; i++)
   {
      indices = (unsigned int *)pofGetFaceList(pof, pofGetObjectNames(pof, POF_TYPE_FACE)[i], &face);
      if (m_VtxRemap[i])
         pVtxRemap = (DWORD*)m_VtxRemap[i]->GetBufferPointer();
      else
         pVtxRemap = NULL;

	   if( FAILED( m_pd3dDevice->CreateIndexBuffer( m_IndexBufferSize[i]*sizeof(WORD), 
         POFMESH_INDEX_BUFFER_USAGE, D3DFMT_INDEX16, POFMESH_INDEX_BUFFER_POOL, &m_IndexBuffers[i] ) ) )
      {
         OutputDebugString("Unable to create index buffer\n");
      }

      // Lock index buffer and fill with data
      m_IndexBuffers[i]->Lock( 0, m_IndexBufferSize[i]*sizeof(WORD), (BYTE**)&pIndex, 0); //D3DLOCK_DISCARD
      for(j=0; j < m_IndexBufferSize[i]; j++)
      {
         pIndex[j] = indices[j];
      }
      m_IndexBuffers[i]->Unlock();

      // Get rest of data
      verts     = (D3DXVECTOR3 *) pofGetVertexList(pof,   face.coordSet, 0, &vtx);
      norms     = (D3DXVECTOR3 *) pofGetNormalList(pof,   face.coordSet, 0, &norm);
      tangents  = (D3DXVECTOR3 *) pofGetTexCoordList(pof, face.coordSet, POF_TCI_TAN0, &tan);
      binormals = (D3DXVECTOR3 *) pofGetTexCoordList(pof, face.coordSet, POF_TCI_BINORM0, &binorm);
      texCoords = (D3DXVECTOR2 *) pofGetTexCoordList(pof, face.coordSet, 0, &tex);
      colors    = (float *)       pofGetColorList(pof, face.coordSet, 0, &color);

      /* Initialize object vertex buffers *****************************************************************************/

      // Allocate compact vertex buffer  note: no FVF type
	  if( FAILED( m_pd3dDevice->CreateVertexBuffer( vtx.count * sizeof(D3D_COMPACT_VERTEX), POFMESH_NON_FVF_BUFFER_USAGE, 
           0, POFMESH_NON_FVF_BUFFER_POOL, &m_CompactVertexBuffers[m_CorrespondingVB[i]] ) ) )
      {
         OutputDebugString("Unable to create compact vertex buffer\n");
      }

      // Fill in vertex buffers
      m_pAppSpacePos[m_CorrespondingVB[i]]      = (D3DXVECTOR3*) calloc(vtx.count*sizeof(D3DXVECTOR3),1);
      m_pAppSpaceNormal[m_CorrespondingVB[i]]   = (D3DXVECTOR3*) calloc(vtx.count*sizeof(D3DXVECTOR3),1);

      if(m_bHasTangentSpace[i])
      {
         m_pAppSpaceTangent[m_CorrespondingVB[i]]  = (D3DXVECTOR3*) calloc(vtx.count*sizeof(D3DXVECTOR3),1);
         m_pAppSpaceBinormal[m_CorrespondingVB[i]] = (D3DXVECTOR3*) calloc(vtx.count*sizeof(D3DXVECTOR3),1);
      }

      m_CompactVertexBuffers[m_CorrespondingVB[i]]->Lock( 0, vtx.count*sizeof(D3D_COMPACT_VERTEX), (BYTE**)&pCompactVertices, 0 );

      // Hackish for now - JasonM
      m_IndexBufferMaxIndex[i] = vtx.count;

      // Fill in any components of vertex that are present. and find bounding box
      for(j=0; j < vtx.count; j++)
      {
         if (m_bOptimizeMesh)
            jr = pVtxRemap[j];
         else
            jr = j;

         if(verts)
         {
            pCompactVertices[j].m_vecPos = verts[jr];
            m_pAppSpacePos[m_CorrespondingVB[i]][j] = verts[jr];

            float distance = D3DXVec3Length(&(m_centroid - verts[jr]));
            m_maxAbs = max(m_maxAbs, distance);
         }

         if(norms)
         {
            //pack normal into byte
            pCompactVertices[j].m_ui8pNorm[0] = PACKINTOBYTE_MINUS1TO1(norms[jr].z);  //packed byte format is stored zyxw... 
            pCompactVertices[j].m_ui8pNorm[1] = PACKINTOBYTE_MINUS1TO1(norms[jr].y);  
            pCompactVertices[j].m_ui8pNorm[2] = PACKINTOBYTE_MINUS1TO1(norms[jr].x);   
            pCompactVertices[j].m_ui8pNorm[3] = PACKINTOBYTE_MINUS1TO1(0.0f);   

            m_pAppSpaceNormal[m_CorrespondingVB[i]][j] = norms[jr];
         }

         if(texCoords)
         {
            pCompactVertices[j].m_vecTex = texCoords[jr];
         }

         if(m_bHasTangentSpace[i])
         {
            m_pAppSpaceTangent[m_CorrespondingVB[i]][j] = tangents[jr];
            m_pAppSpaceBinormal[m_CorrespondingVB[i]][j] = binormals[jr];

            // Re-orthogonalize tangent basis
            D3DXVECTOR3 binorm;
            D3DXVec3Cross(&binorm, &norms[jr], &tangents[jr]);
            if (D3DXVec3Dot(&binorm, &binormals[jr]) < 0)
                binorm = -binorm;
            binormals[jr] = binorm;

            //pack tangent into byte
            pCompactVertices[j].m_ui8pBinormal[0] = PACKINTOBYTE_MINUS1TO1(binormals[jr].z);  //packed byte format is stored zyxw... 
            pCompactVertices[j].m_ui8pBinormal[1] = PACKINTOBYTE_MINUS1TO1(binormals[jr].y);  
            pCompactVertices[j].m_ui8pBinormal[2] = PACKINTOBYTE_MINUS1TO1(binormals[jr].x);   
            pCompactVertices[j].m_ui8pBinormal[3] = PACKINTOBYTE_MINUS1TO1(0.0);   
            pCompactVertices[j].m_ui8pTangent[0] = PACKINTOBYTE_MINUS1TO1(tangents[jr].z);  //packed byte format is stored zyxw... 
            pCompactVertices[j].m_ui8pTangent[1] = PACKINTOBYTE_MINUS1TO1(tangents[jr].y);  
            pCompactVertices[j].m_ui8pTangent[2] = PACKINTOBYTE_MINUS1TO1(tangents[jr].x);   
            pCompactVertices[j].m_ui8pTangent[3] = PACKINTOBYTE_MINUS1TO1(0.0);   
         }
      }

      m_CompactVertexBuffers[m_CorrespondingVB[i]]->Unlock();

    } // end (i=0; i < m_numFaceLists; i++)

    return S_OK;
}

void CPofMesh::Draw (unsigned int flags)
{
   unsigned int i;

   // Run through each face list
   
   for (i=0; i < m_numFaceLists; i++)
   {
      switch(flags)
      {         
         case POFMESH_DRAW_COMPACT_BUFFER:
            m_pd3dDevice->SetStreamSource( 0, m_CompactVertexBuffers[m_CorrespondingVB[i]], sizeof(D3D_COMPACT_VERTEX) );        
            m_pd3dDevice->SetIndices( m_IndexBuffers[i], 0);
            m_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, m_IndexBufferMaxIndex[i], 0, (UINT)(m_IndexBufferSize[i]/3));
            break;

         case POFMESH_DRAW_FVF_BUFFER:
         default:
            m_FVFMeshes[i]->DrawSubset( 0 );
            break;
      }
   }
}


void CPofMesh::SetVertexShader(void)
{
  m_pd3dDevice->SetVertexShader( D3DFVF_POLY );  // We also have a vertex shader for kicks
}



BYTE CPofMesh::PackFloatInByte(float in)
{
   return (BYTE) ((in+1.0f) / 2.0f * 255.0f);
}


