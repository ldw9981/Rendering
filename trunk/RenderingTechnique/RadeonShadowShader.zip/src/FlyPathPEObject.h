//-----------------------------------------------------------------------------
// Fly Path Object
// 
// A object that add fly path support to a physics engine object
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------

#ifndef _FLYPATHPEOBJECT_H_
#define _FLYPATHPEOBJECT_H_
#include <D3DX8.h>
#include "ArcBallObject.h"
#include "path.h"

struct WayPoint
{
   D3DXVECTOR3    pos;          // Position
   D3DXQUATERNION orientation;  // orientation
};

class CFlyPathPEObject : public CArcBallObject
{
protected:

    float       m_fAnimationLength;
    closedPath* m_pFlyPath;
    float       m_fFlyTime;
    int         m_NumWayPoints;
    WayPoint*   m_pWayPoints;
    float       m_fSecondsPerWayPoint;
    int         m_NumLoops;

    BOOL        m_bGotFocus;

    void CreatePathFromWaypoints (WayPoint *aWayPoints, closedPath **aPath);
    virtual const D3DXMATRIX& GetMotionTransform();

public:
    CFlyPathPEObject();
    ~CFlyPathPEObject();

    void LoadPath(char* filename);
    VOID Advance(FLOAT fElapsedTime);
    VOID SetFlyTime(FLOAT time) {m_fFlyTime = time;};
    FLOAT GetFlyTime(FLOAT time) {return m_fFlyTime;};
    LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

    BOOL        m_bAutoFlying;
};

#endif
