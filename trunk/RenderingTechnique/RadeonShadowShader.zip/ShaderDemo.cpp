#include "ShaderDemo.h"
#include "D3DUtil.h"
#include "resource.h"
#include <algorithm>
#include "direct.h"

//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}


//-----------------------------------------------------------------------------
// Name: CFalloffMap()
// Desc: A Volumetric Texture used for point light falloff.
//-----------------------------------------------------------------------------
CFalloffMap::CFalloffMap(UINT size)
{
    m_Format = D3DFMT_A8;
    m_dwWidth = m_dwHeight = m_dwDepth = size;
}

D3DXCOLOR CFalloffMap::Function(D3DXVECTOR3* p, D3DXVECTOR3* s)
{
   // Adjust to be 0 -> 1
   FLOAT x = (p->x-(1.0f/m_dwWidth)/2)*m_dwWidth/(m_dwWidth-1.0f);
   FLOAT y = (p->y-(1.0f/m_dwHeight)/2)*m_dwHeight/(m_dwHeight-1.0f);
   FLOAT z = (p->z-(1.0f/m_dwDepth)/2)*m_dwDepth/(m_dwDepth-1.0f);
   FLOAT distance = (float)(x*x + y*y + z*z);
   if (distance == 0) return D3DXCOLOR(1, 1, 1, 1);
   FLOAT falloff = min(1.0f, max(0.0f, ((1.0f/16.0f)/distance - 1.0f/16.0f)/8.0f ) );
   return D3DXCOLOR(falloff, falloff, falloff, falloff);
}

//-----------------------------------------------------------------------------
// Name: CFalloffMap()
// Desc: A Texture used for point light falloff.
//-----------------------------------------------------------------------------
C1DFalloffMap::C1DFalloffMap(DWORD size)
{
    m_dwWidth = size;
    m_Format = D3DFMT_A8R8G8B8;
}

D3DXCOLOR C1DFalloffMap::Function(D3DXVECTOR2* p, D3DXVECTOR2* s)
{
    // input is p->x = (Distance^2/Attenuation^2)
   FLOAT distance = (p->x-(1.0f/m_dwWidth)/2)*m_dwWidth/(m_dwWidth-1.0f);
   if (distance == 0) return D3DXCOLOR(1, 1, 1, 1);
   FLOAT falloff = (1.0f/16.0f)/distance - 1.0f/16.0f;
   FLOAT falloff1 = min(1.0f, max(0.0f, falloff/16.0f ) );
   FLOAT falloff2 = min(1.0f, max(0.0f, falloff/4.0f ) );
   return D3DXCOLOR(falloff1, falloff2, falloff1, falloff2);
}

//-----------------------------------------------------------------------------
// Name: CSpecularMap()
// Desc: A Texture used for specular lights.
//-----------------------------------------------------------------------------
CSpecularMap::CSpecularMap(DWORD size)
{
    m_dwWidth = size;
    m_Format = D3DFMT_L8;
}

D3DXCOLOR CSpecularMap::Function(D3DXVECTOR2* p, D3DXVECTOR2* s)
{
    if (p->x == 0 || (1/s->x) <= 1)return D3DXCOLOR(0, 0, 0, 0);
    // input is p->x = saturate(N.H * N.H)
    FLOAT fNH2 = (p->x-(1/m_dwWidth)/2)*m_dwWidth/(m_dwWidth-1);  // Rescale to be 0 to 1.
    FLOAT fNH  = sqrtf(fNH2);
    FLOAT fK   = 16;
    FLOAT fNHK = powf(fNH,fK);
    FLOAT fi = min(1.0f, max(0.0f, fNHK*.6f) );
    return D3DXCOLOR(fi, fi, fi, fi);
}

//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor. Sets attributes for the app.
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
    m_strWindowTitle    = _T("ATI Shadow Volume Shader Demo");
    m_dwCreationWidth   = 640;
    m_dwCreationHeight  = 480;
    m_bUseDepthBuffer   = TRUE;
    m_dwMinStencilBits  = 8;
    m_bShowCursorWhenFullscreen = TRUE;

    m_bShowStatistics   = FALSE;
    m_bShadowsOn        = TRUE;
    m_bShowVolumes      = FALSE;
    m_bGravityOn        = FALSE;
    m_bPhysicsOn        = TRUE;
    m_bAnimateLights    = FALSE;
    m_bWireframe        = FALSE;
    m_dwNumLights       = 0;
    m_dwNumObjects      = 0;

    m_pFalloffMap = NULL;
    m_p1DFalloffMap = NULL;
    m_pSpecularMap = NULL;

    for (int object = 0; object < MAX_OBJECTS; object++)
    {
        m_pObject[object] = NULL;
    }

    m_pFont   = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_pRoom   = new CRoom(ROOM_WIDTH, ROOM_HEIGHT, ROOM_DEPTH);

    m_ActiveEffect = ET_Lit;
}


HRESULT CMyD3DApplication::AdjustWindowForChange()
{
#if HACK_FORCE_ARGB_BACKBUFFER_HACK
    // This big ole hack doesnt seem to work quickly.
    D3DAdapterInfo* pAdapterInfo = &m_Adapters[m_dwAdapter];
    D3DDeviceInfo*  pDeviceInfo  = &pAdapterInfo->devices[pAdapterInfo->dwCurrentDevice];
    D3DModeInfo*    pModeInfo    = &pDeviceInfo->modes[pDeviceInfo->dwCurrentMode];

    if (pModeInfo->Format == D3DFMT_X8R8G8B8)
        pModeInfo->Format = D3DFMT_A8R8G8B8;

    if (pAdapterInfo->d3ddmDesktop.Format == D3DFMT_X8R8G8B8)
        pAdapterInfo->d3ddmDesktop.Format = D3DFMT_A8R8G8B8;
#endif
    return CD3DApplication::AdjustWindowForChange();
}


//-----------------------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Called during initial app startup, this function performs all the
//       permanent initialization.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    D3DUtil_InitLight( m_BaseLight, D3DLIGHT_POINT, 0, 0, 0 );
    m_BaseLight.Ambient.r = 0.0f;
    m_BaseLight.Ambient.g = 0.0f;
    m_BaseLight.Ambient.b = 0.0f;
    m_BaseLight.Range = 80.0f;
    m_BaseLight.Attenuation2 = 8.0f*16.0f/(m_BaseLight.Range*m_BaseLight.Range);

    m_pRoom->SetEffectFile(ET_Ambient, "floor_ambient.sha");
    m_pRoom->SetEffectFile(ET_Lit, "floor.sha");

    InitObjects();

    m_Camera.LoadPath("Paths\\combined.pth");
    m_Camera.Translate(D3DXVECTOR3(0, 5, -25));

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    m_Camera.Advance(m_fElapsedTime);

    CShaderObject::SetRenderTransform( D3DTS_VIEW, &m_Camera.GetViewTransform() );

    if (m_bPhysicsOn)
        Physics();
    
    return S_OK;
}


//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    // Begin the scene
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
        // Render the scene
        RenderScene();

        // Output statistics
        DWORD curTextLine = 0;
        if (m_bShowStatistics)
        {
            m_pFont->DrawText( 2, curTextLine, D3DCOLOR_ARGB(255,255,255,0), m_strFrameStats );
            curTextLine += 15.0f;
            m_pFont->DrawText( 2, curTextLine, D3DCOLOR_ARGB(255,255,255,0), m_strDeviceStats );
            curTextLine += 15.0f;
        }

        // End the scene.
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}


//-----------------------------------------------------------------------------
// Name: RenderScene()
// Desc: Renders all visual elements in the scene. This is called by the main
//       Render() function,
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RenderScene()
{
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL | D3DCLEAR_TARGET, 0x000000ff, 1.0f, 0x80L );

    //-------------------------------------------------------------------------
    // Render the ambient pass to set the z buffer and get the unlit component
    //-------------------------------------------------------------------------
    m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);

    m_pRoom->Render(ET_Ambient);

    CObject* transparentObjects[MAX_OBJECTS];
    DWORD numTransparentObjects = 0;
    int object;
    for (object = 0; object < m_dwNumObjects; object++)
    {
        if ( !m_pObject[object]->IsTransparent(ET_Ambient) )
            m_pObject[object]->Render(ET_Ambient);
        else
        {
            transparentObjects[numTransparentObjects] = m_pObject[object];
            numTransparentObjects++;
        }
    }

    //-------------------------------------------------------------------------
    // Render the lit pass per light
    //-------------------------------------------------------------------------
    if(m_bWireframe)
        m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
    else
        m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);

    for (int i = 0; i < m_dwNumLights; i++)
    {
        // Clear the viewport stencil buffer
        if (i > 0)
            m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_STENCIL , 0x000000ff, 1.0f, 0x80L );

        D3DXVECTOR3 position = m_pObject[i]->GetWorldCenterOfGravity();
        D3DLIGHT8 light = m_Light[i];
        light.Position.x = position.x;
        light.Position.y = position.y;
        light.Position.z = position.z;
        m_pd3dDevice->SetLight( 0, &light );
    
        //-----------------------------------------------------------------
        // Render the shadow volumes
        //-----------------------------------------------------------------

        if (m_bShadowsOn)
        {
            for (object = m_dwNumLights; object < m_dwNumObjects; object++)
            {
                if ( !m_pObject[object]->IsTransparent(ET_Ambient))
                    m_pObject[object]->RenderShadowVolume(&light);
            }
        }

        //-----------------------------------------------------------------
        // Render the lit components
        //-----------------------------------------------------------------

        m_pRoom->Render(ET_Lit, &light);

        // Draw non transparent objects
        for (object = m_dwNumLights; object < m_dwNumObjects; object++)
        {
            if ( !m_pObject[object]->IsTransparent(ET_Ambient))
                m_pObject[object]->Render(ET_Lit, &light);
        }
    }

    //-------------------------------------------------------------------------
    // Sort and draw transparent objects
    //-------------------------------------------------------------------------
    if (numTransparentObjects > 0)
    {
        std::sort(transparentObjects, &transparentObjects[numTransparentObjects-1], CObject::IsFurther);
        for (object = 0; object < numTransparentObjects; object++)
        {
            transparentObjects[object]->Render(ET_Ambient);
            for (int i = 0; i < m_dwNumLights; i++)
            {
                D3DXVECTOR3 position = m_pObject[i]->GetWorldCenterOfGravity();
                D3DLIGHT8 light = m_Light[i];
                light.Position.x = position.x;
                light.Position.y = position.y;
                light.Position.z = position.z;
                m_pd3dDevice->SetLight( 0, &light );
                transparentObjects[object]->Render(ET_Lit, &m_Light[i]);
            }
        }
    }

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Initialize scene objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr, hr2 = S_OK;

    // Create volumetric light falloff texture
    m_pFalloffMap = new CFalloffMap(32);
    m_pFalloffMap->Initialize(m_pd3dDevice);
    CShaderObject::RegisterSharedTexture( "tPointFalloff", m_pFalloffMap->GetTexture() );

    // Create 1D light falloff texture
    m_p1DFalloffMap = new C1DFalloffMap(1024);
    m_p1DFalloffMap->Initialize(m_pd3dDevice);
    CShaderObject::RegisterSharedTexture( "t1DPointFalloff", m_p1DFalloffMap->GetTexture() );

    // Create Specular highlight texture
    m_pSpecularMap = new CSpecularMap(512);
    m_pSpecularMap->Initialize(m_pd3dDevice);
    CShaderObject::RegisterSharedTexture( "tSpecular", m_pSpecularMap->GetTexture() );

    // Restore the device-dependent objects
    m_pRoom->InitDeviceObjects( m_pd3dDevice, m_pD3D );
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    for (int object = 0; object < m_dwNumObjects; object++)
    {
        if ( FAILED( hr = m_pObject[object]->InitDeviceObjects( m_pd3dDevice, m_pD3D ) ) )
            hr2 = hr;
    }

    SetMenuStates();

    return hr2;
}




//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Restore device-memory objects and state after a device is created or
//       resized.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    HRESULT hr, hr2 = S_OK;

    if ( FAILED( hr = RestoreObjectDeviceObjects() ) )
        hr2 = hr;

    if ( FAILED( hr = m_pRoom->RestoreDeviceObjects() ) )
        hr2 = hr;

    m_pFont->RestoreDeviceObjects();

    // Set default render states
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,  TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,  0x00000000 );

    // Set the transform matrices
    D3DXMATRIX matProj;
    FLOAT fAspect = m_d3dsdBackBuffer.Width / (FLOAT)m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, fAspect, 0.5f, 10000.0f );
    CShaderObject::SetRenderTransform( D3DTS_PROJECTION, &matProj );

    m_pd3dDevice->SetLight( 0, &m_BaseLight );
    m_pd3dDevice->LightEnable( 0, TRUE );
    
    m_Camera.SetScreenSize( m_d3dsdBackBuffer.Width, m_d3dsdBackBuffer.Height );
    
    return hr2;
}




//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Called when the device-dependent objects are about to be lost.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    for (int object = 0; object < m_dwNumObjects; object++)
    {
        m_pObject[object]->InvalidateDeviceObjects();
    }

    m_pRoom->InvalidateDeviceObjects();
    m_pFont->InvalidateDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    SAFE_DELETE(m_pFalloffMap);
    SAFE_DELETE(m_p1DFalloffMap);
    SAFE_DELETE(m_pSpecularMap);
    for (int object = 0; object < m_dwNumObjects; object++)
    {
        m_pObject[object]->DeleteDeviceObjects();
    }
    m_pRoom->DeleteDeviceObjects();
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    for (int object = 0; object < m_dwNumObjects; object++)
    {
        SAFE_DELETE( m_pObject[object] );
    }
    SAFE_DELETE( m_pRoom );
    SAFE_DELETE( m_pFont );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device intialization, this code checks the device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS8* pCaps, DWORD dwBehavior,
                                          D3DFORMAT Format )
{    
    if( dwBehavior & D3DCREATE_PUREDEVICE )
        return E_FAIL; // Gets don't work on PUREDEVICE

    // Check for vertex shaders
    if( (pCaps->VertexShaderVersion < D3DVS_VERSION(1,0)) &&
        ( (dwBehavior & D3DCREATE_HARDWARE_VERTEXPROCESSING) ||
          (dwBehavior & D3DCREATE_MIXED_VERTEXPROCESSING) ) )
        return E_FAIL;

    return S_OK;
}



//-----------------------------------------------------------------------------
// Name: SetMenuStates()
// Desc:
//-----------------------------------------------------------------------------
VOID CMyD3DApplication::SetMenuStates()
{
    HMENU hMenu = GetMenu( m_hWnd );

    CheckMenuItem( hMenu, IDM_SHOWSTATISTICS, 
        m_bShowStatistics ? MF_CHECKED : MF_UNCHECKED );
    CheckMenuItem( hMenu, IDM_SHADOWS, 
        m_bShadowsOn ? MF_CHECKED : MF_UNCHECKED );
    CheckMenuItem( hMenu, IDM_SHOWSHADOWVOLUMES, 
        m_bShowVolumes ? MF_CHECKED : MF_UNCHECKED );
    CheckMenuItem( hMenu, IDM_PHYSICS, 
        m_bPhysicsOn ? MF_CHECKED : MF_UNCHECKED );
    CheckMenuItem( hMenu, IDM_GRAVITY, 
        m_bGravityOn ? MF_CHECKED : MF_UNCHECKED );
    CheckMenuItem( hMenu, IDM_ANIMATELIGHTS, 
        m_bAnimateLights ? MF_CHECKED : MF_UNCHECKED );
    CheckMenuItem( hMenu, IDM_WIREFRAME, 
        m_bWireframe ? MF_CHECKED : MF_UNCHECKED );

    // Fly path stuff
    CheckMenuItem( hMenu, IDM_AUTO_FLY, 
        m_Camera.m_bAutoFlying ? MF_CHECKED : MF_UNCHECKED );

    static int oldShowVols = -1;
    if (oldShowVols != m_bShowVolumes)
    {
        for (int object = 0; object < m_dwNumObjects; object++)
        {
            if (m_bShowVolumes)
                m_pObject[object]->SetTechnique(ET_Shadow, "ShowVolumes");
            else 
                m_pObject[object]->SetTechnique(ET_Shadow, "ShadowVolumes");
        }
    }
    oldShowVols = (int) m_bShowVolumes;

    if (m_bGravityOn)
        CPEObject::m_svGravity = D3DXVECTOR3( 0, -28.0f, 0 );
    else
        CPEObject::m_svGravity = D3DXVECTOR3( 0, 0.0f, 0 );
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Message proc function to handle key and menu input
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam,
                                    LPARAM lParam )
{
    // Parse mouse messages
    m_Camera.MsgProc(hWnd, uMsg, wParam, lParam);

    // Trap context menu
    if( WM_CONTEXTMENU == uMsg )
        return 0;

    // Handle menu commands
    if( WM_COMMAND == uMsg )
    {
        int object;
        switch( LOWORD(wParam) )
        {
            case IDM_SHOWSTATISTICS: 
                m_bShowStatistics = !m_bShowStatistics;  break;
            case IDM_SHADOWS: 
                m_bShadowsOn   = !m_bShadowsOn;          break;
            case IDM_SHOWSHADOWVOLUMES: 
                m_bShowVolumes = !m_bShowVolumes;        break;
            case IDM_PHYSICS: 
                m_bPhysicsOn   = !m_bPhysicsOn;          break;
            case IDM_GRAVITY: 
                m_bGravityOn   = !m_bGravityOn;          break;
            case IDM_WIREFRAME: 
                m_bWireframe   = !m_bWireframe;          break;
            case IDM_ANIMATELIGHTS: 
                m_bAnimateLights = !m_bAnimateLights;
                for (object = 0; object < m_dwNumLights; object++)
                {
                    if (m_bAnimateLights)
                    {
                        m_pObject[object]->m_fMass = 1.0f;
                        m_pObject[object]->SetVelocity( D3DXVECTOR3( RandNum(-30, 30), RandNum(-30, 30), RandNum(-30, 30) ) );
                    }
                    else
                    {
                        m_pObject[object]->m_fMass = 100.0f;
                        m_pObject[object]->SetVelocity( D3DXVECTOR3( 0, 0, 0 ) );
                    }
                }
                break;
            case IDM_KICKOBJECTS:  KickObjects();        break;
            case IDM_ADDOBJECT:    AddObject();          break;
            case IDM_DELETEOBJECT: DeleteObject();       break;
            case IDM_ADDLIGHT:     AddLight();           break;
            case IDM_DELETELIGHT:  DeleteLight();        break;
            case IDM_REFRESHSHADERS:
                {
                    for (int object = 0; object < m_dwNumObjects; object++)
                    {
                        m_pObject[object]->RecompileEffectFiles();
                    }
                    m_pRoom->RecompileEffectFiles();
                }
                break;
        }

        // Update the menus, in case any state changes occurred
        SetMenuStates();
    }

    if( WM_KEYDOWN == uMsg )
    {
        BOOL shifted = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
        if (wParam >= '1' && wParam <= '9')
        {
            if (shifted)
                m_ActiveEffect = ET_Ambient;
            else
                m_ActiveEffect = ET_Lit;

            m_pRoom->SetTechnique(m_ActiveEffect, wParam - '1');
        }

        SetMenuStates();
    }

    // Pass remaining messages to default handler
    return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}
