#ifndef TEXCREATIONUTIL_HPP
#define TEXCREATIONUTIL_HPP

#include <stdio.h>

#include "d3d8.h"
#include "DXUtil.h"

char *GetFormatName(D3DFORMAT p_d3dfFormat);
int GetFormatPixelDepth(D3DFORMAT p_d3dfFormat);
char *GetUsageBitName(DWORD p_dwUsage);
char *GetResourceTypeName(D3DRESOURCETYPE p_dwResourceType);
D3DFORMAT FindSupportedFormat(LPDIRECT3DDEVICE8 p_pd3dDevice, 
	D3DFORMAT *p_d3dfFormat, DWORD p_dwNumFormats, DWORD p_dwUsage, D3DRESOURCETYPE p_d3drtType);

#endif //TEXCREATIONUTIL_HPP
