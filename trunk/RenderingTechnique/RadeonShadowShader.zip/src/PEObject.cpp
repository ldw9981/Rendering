//-----------------------------------------------------------------------------
// Physics Engine Object
// 
// A base class for maintaining an object's position, velocity, etc and 
// animation.  Also provides basic physics groundwork for collisions (but not
// detection).  Can be used as a base class for all objects for maintaining
// position and velocity.
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#include <limits>
#include "PEObject.h"

D3DXVECTOR3 CPEObject::m_svGravity(0, -28.0f, 0);
FLOAT       CPEObject::m_sfTime = 0.0f; 

VOID CPEObject::Collide(CPEObject& o1, CPEObject& o2, 
                        const D3DXVECTOR3& vPoint, 
                        const D3DXVECTOR3& vNormal1,
                        const D3DXVECTOR3& vNormal2)
{
    D3DXVECTOR3 vVelocity1; o1.GetPointVelocity( &vVelocity1, vPoint );
    D3DXVECTOR3 vVelocity2; o2.GetPointVelocity( &vVelocity2, vPoint );
    D3DXVECTOR3 vRelVelocity = vVelocity2 - vVelocity1;
    D3DXVECTOR3 vTangent1; 
    D3DXVec3Cross( &vTangent1, &vNormal1, &vRelVelocity );
    D3DXVec3Cross( &vTangent1, &vTangent1, &vNormal1 );
    D3DXVec3Normalize( &vTangent1, &vTangent1 );
    FLOAT fRelVolDotNormal1  = D3DXVec3Dot( &vNormal1, &vRelVelocity );
    FLOAT fRelVolDotTangent1 = D3DXVec3Dot( &vTangent1, &vRelVelocity );
    D3DXVECTOR3 vArm1          = vPoint - o1.GetWorldCenterOfGravity();
    D3DXVECTOR3 vArm2          = vPoint - o2.GetWorldCenterOfGravity();
    FLOAT fArm1Length          = D3DXVec3Length( &vArm1 );
    FLOAT fArm2Length          = D3DXVec3Length( &vArm2 );

    // Handle the collision forces along the normals.
    {
        FLOAT fNormalVelocityXfer = fRelVolDotNormal1;

        // Divy up force towards rotation and motion.
        D3DXVECTOR3 vRotationDirection1, vArmDirection1; 
        D3DXVECTOR3 vRotationDirection2, vArmDirection2; 
        D3DXVec3Cross( &vRotationDirection1, &vArm1, &vNormal1 );
        D3DXVec3Cross( &vRotationDirection2, &vArm2, &vNormal2 );
        D3DXVec3Cross( &vRotationDirection1, &vRotationDirection1, &vArm1 );
        D3DXVec3Cross( &vRotationDirection2, &vRotationDirection2, &vArm2 );
        D3DXVec3Normalize( &vArmDirection1, &vArm1 );
        D3DXVec3Normalize( &vArmDirection2, &vArm2 );
        FLOAT fNormDotArm1    = D3DXVec3Dot( &vNormal2, &vArmDirection1 );
        FLOAT fNormDotArm2    = D3DXVec3Dot( &vNormal1, &vArmDirection2 );
        FLOAT fNormDotRotDir1 = D3DXVec3Dot( &vNormal2, &vRotationDirection1 );
        FLOAT fNormDotRotDir2 = D3DXVec3Dot( &vNormal1, &vRotationDirection2 );

        FLOAT fPartTo1       = 1 / o1.m_fMass;
        FLOAT fPartToAng1    = fNormDotRotDir1*fNormDotRotDir1 / (o1.m_fMass * o1.m_fAngInertiaOverMass);
        FLOAT fPartTo2       = 1 / o2.m_fMass;
        FLOAT fPartToAng2    = -fNormDotRotDir2 / (o2.m_fMass * o2.m_fAngInertiaOverMass);

        // Apply motion
        FLOAT fCollisionForce    = fNormalVelocityXfer / (fPartTo1 + fPartToAng1 + fPartTo2 + fPartToAng2);
        FLOAT fTotalReboundMag   = (o1.m_fRigidity + o2.m_fRigidity) * fCollisionForce;
        FLOAT fAbsorbedBy1       = (1.0f - o1.m_fRigidity) * fCollisionForce;
        FLOAT fAbsorbedBy2       = (1.0f - o2.m_fRigidity) * fCollisionForce;

        o1.m_vVelocity += (fTotalReboundMag * fPartTo1) * vNormal1;
        o2.m_vVelocity -= (fTotalReboundMag * fPartTo2) * vNormal1;

        o1.AddWorldspaceSquishVelocity(fAbsorbedBy1 * fPartTo1 * vNormal1);
        o2.AddWorldspaceSquishVelocity(fAbsorbedBy2 * fPartTo2 * vNormal1);

        // Apply rotation
        D3DXVec3Normalize( &vRotationDirection1, &vRotationDirection1 );
        D3DXVECTOR3 vDLinVelocity1 = (fTotalReboundMag * fPartToAng1) * vRotationDirection1;
        D3DXVECTOR3 vDAngVelocity1;
        o1.LinearToAngularVelocity( &vDAngVelocity1, vDLinVelocity1, vArm1 );
        o1.m_vAngVelocity += vDAngVelocity1;
        
        D3DXVec3Normalize( &vRotationDirection2, &vRotationDirection2 );
        D3DXVECTOR3 vDLinVelocity2 = (fTotalReboundMag * fPartToAng2) * vRotationDirection2;
        D3DXVECTOR3 vDAngVelocity2;
        o2.LinearToAngularVelocity( &vDAngVelocity2, vDLinVelocity2, vArm2 );
        o2.m_vAngVelocity += vDAngVelocity2;
    }

    // Handle the collision forces along the tangents.
    {
        FLOAT fCoeffOfFriction     = (o1.m_fCoeffOfFriction * o2.m_fCoeffOfFriction);
        FLOAT fFrictionForce       = fCoeffOfFriction * fRelVolDotNormal1;
        FLOAT fTangentVelocityXfer = min(fabs(fFrictionForce), fRelVolDotTangent1);
        FLOAT fPartTo1             = 1.0f / o1.m_fMass;
        FLOAT fPartToAng1          = 1.0f / (o1.m_fMass * o1.m_fAngInertiaOverMass * fArm1Length);
        FLOAT fPartTo2             = 1.0f / o2.m_fMass;
        FLOAT fPartToAng2          = 1.0f / (o2.m_fMass * o2.m_fAngInertiaOverMass * fArm2Length);
        FLOAT fTotalXferMag        = fTangentVelocityXfer / (fPartTo1 + fPartToAng1 + fPartTo2 + fPartToAng2);

        o1.m_vVelocity += (fTotalXferMag * fPartTo1) * vTangent1;
        D3DXVECTOR3 vDAngVelocity1 = (fTotalXferMag * fPartToAng1) * vTangent1;
        o1.LinearToAngularVelocity( &vDAngVelocity1, vDAngVelocity1, vArm1 );
        o1.m_vAngVelocity += vDAngVelocity1;

        o2.m_vVelocity -= (fTotalXferMag * fPartTo2) * vTangent1;
        D3DXVECTOR3 vDAngVelocity2 = (fTotalXferMag * fPartToAng2) * vTangent1;
        o2.LinearToAngularVelocity( &vDAngVelocity2, vDAngVelocity2, vArm2 );
        o2.m_vAngVelocity -= vDAngVelocity2;
    }
}

CPEObject::CPEObject() 
{
    D3DXMatrixIdentity(&m_matWorld);
    SetTransform(m_matWorld);
    m_vCenterOfGravity    = D3DXVECTOR3(0, 0, 0);
    m_vVelocity           = D3DXVECTOR3(0, 0, 0);
    m_vAngVelocity        = D3DXVECTOR3(0, 0, 0);
    m_vSquish             = D3DXVECTOR3(0, 0, 0);
    m_vSquishVelocity     = D3DXVECTOR3(0, 0, 0);
    m_fMass               = std::numeric_limits<float>::infinity();
    m_fAngInertiaOverMass = 1.0f;
    m_fAirResistance      = 0.0f;
    m_fAngAirResistance   = 0.0f;
    m_fCoeffOfFriction    = 1.0f;
    m_fRigidity           = 1.0f;
    m_fTension            = 1.0e+15f;
    m_fDampening          = std::numeric_limits<float>::infinity();
    m_vForce              = D3DXVECTOR3(0, 0, 0);
    m_vAngForce           = D3DXVECTOR3(0, 0, 0);
    m_vObjForce           = D3DXVECTOR3(0, 0, 0);
    m_vObjAngForce        = D3DXVECTOR3(0, 0, 0);
    SaveState();
}

D3DXVECTOR3* CPEObject::AngularToLinearVelocity(D3DXVECTOR3* pvOut, const D3DXVECTOR3& vAngVelocity, 
                                                const D3DXVECTOR3& vArm)
{
    D3DXVECTOR3 vArmNorm;
    D3DXVec3Normalize( &vArmNorm, &vArm );
    D3DXVec3Cross( pvOut, &vAngVelocity, &vArmNorm );
    *pvOut *= D3DXVec3Length(&vArm);
    return pvOut;
}

D3DXVECTOR3* CPEObject::LinearToAngularVelocity(D3DXVECTOR3* pvOut, const D3DXVECTOR3& vVelocity, 
                                                const D3DXVECTOR3& vArm)
{
    D3DXVECTOR3 vArmNorm, vVelocityAtUnitLength;
    D3DXVec3Normalize( &vArmNorm, &vArm );
    vVelocityAtUnitLength = vVelocity / D3DXVec3Length(&vArm);
    D3DXVec3Cross( pvOut, &vArmNorm, &vVelocityAtUnitLength );
    return pvOut;
}

D3DXVECTOR3* CPEObject::GetPointVelocity(D3DXVECTOR3* pvOut, const D3DXVECTOR3& vPoint)
{
    D3DXVECTOR3 vDistanceFromCenter = vPoint - GetWorldCenterOfGravity();
    AngularToLinearVelocity(pvOut, m_vAngVelocity, vDistanceFromCenter);
    *pvOut += m_vVelocity;
    return pvOut;
}

VOID CPEObject::AddWorldspaceSquishVelocity(const D3DXVECTOR3& vSquishImpulse)
{
    m_vSquishVelocity += vSquishImpulse;
}

VOID CPEObject::Advance(FLOAT fElapsedTime)
{
    D3DXVECTOR3 v;

    // Apply external forces.
    m_vVelocity       += m_vForce * fElapsedTime;
    m_vAngVelocity    += m_vAngForce * fElapsedTime;
    D3DXVec3TransformNormal( &v, &m_vObjForce, &GetTransform() );
    m_vVelocity       += v * fElapsedTime;
    D3DXVec3TransformNormal( &v, &m_vObjAngForce, &GetTransform() );
    m_vAngVelocity    += v * fElapsedTime;

    // Apply constant forces.
    m_vVelocity       += m_svGravity * fElapsedTime;
    m_vSquishVelocity -= m_fTension * m_vSquish * fElapsedTime;

    // Add resistances
    FLOAT newVelocity = 1.0f - m_fAirResistance * fElapsedTime / m_fMass;
    if ( newVelocity > 0)
        m_vVelocity = newVelocity * m_vVelocity;
    else
        m_vVelocity = D3DXVECTOR3(0,0,0);

    FLOAT newAngVelocity = 1 - m_fAngAirResistance * fElapsedTime / (m_fMass * m_fAngInertiaOverMass);
    if ( newAngVelocity > 0)
        m_vAngVelocity = newAngVelocity * m_vAngVelocity;
    else
        m_vAngVelocity = D3DXVECTOR3(0,0,0);

    D3DXVECTOR3 vNewSquishVelocity = m_vSquishVelocity - m_vSquishVelocity * m_fDampening * fElapsedTime;
    if ( D3DXVec3Dot(&vNewSquishVelocity, &m_vSquishVelocity) > 0)
        m_vSquishVelocity = vNewSquishVelocity;
    else
        m_vSquishVelocity = D3DXVECTOR3(0,0,0);

    // Move
    m_vPosition += m_vVelocity * fElapsedTime;

    // Rotate
    {
        D3DXVECTOR3 vDAngle = m_vAngVelocity * fElapsedTime;
        D3DXQUATERNION qDRotate;
        D3DXQuaternionRotationYawPitchRoll( &qDRotate, vDAngle.y, vDAngle.x, vDAngle.z  );
        m_qRotate *= qDRotate;
        D3DXMATRIX matRotate;
        D3DXMatrixRotationQuaternion(&matRotate, &qDRotate);
        D3DXVec3TransformNormal( &m_vSquishVelocity, &m_vSquishVelocity, &matRotate );
        D3DXVec3TransformNormal( &m_vSquish, &m_vSquish, &matRotate );
    }

    // Squish
    {
        m_vSquish += m_vSquishVelocity * fElapsedTime;
        FLOAT fLength = D3DXVec3Length( &m_vSquish );
        if (fLength > 0.5f)
            m_vSquish /= (fLength / 0.5f);
    }
    UpdateWorldMatrix();
}

VOID CPEObject::UpdateWorldMatrix()
{
    // Create composite world matrix
    // Find the initially transformed object's center of gravity.
    D3DXVECTOR3 vStartCOG;
    D3DXVec3TransformCoord( &vStartCOG, &m_vCenterOfGravity, &m_matStart );

    // Convert squish amount to scaling values. HACK!
    D3DXVECTOR3 vScale = m_vSquish + D3DXVECTOR3(1,1,1);
    D3DXQUATERNION qRotateInv = m_qRotate;
    qRotateInv.w = -qRotateInv.w;

    // Find composite object transformations
    D3DXMATRIX matTransform;
    D3DXMatrixTransformation( &matTransform, 
                              &vStartCOG, &qRotateInv, &vScale, // Scaling
                              &vStartCOG, &m_qRotate,           // Rotation
                              &m_vPosition );                   // Position

    // Combine with starting transform
    D3DXMatrixMultiply( &m_matWorld, &m_matStart, &matTransform );

    m_bWorldInvValid             = FALSE;
    m_bWorldCenterOfGravityValid = FALSE;
}

VOID CPEObject::SaveState()
{
    m_vLastPosition       = m_vPosition;
    m_vLastVelocity       = m_vVelocity;
    m_qLastRotate         = m_qRotate;
    m_vLastAngVelocity    = m_vAngVelocity;
    m_vLastSquish         = m_vSquish;
    m_vLastSquishVelocity = m_vSquishVelocity;
    m_matLastWorld        = m_matWorld;
}

VOID CPEObject::RestoreState()
{
    m_vPosition       = m_vLastPosition;
    m_vVelocity       = m_vLastVelocity;
    m_qRotate         = m_qLastRotate;
    m_vAngVelocity    = m_vLastAngVelocity;
    m_vSquish         = m_vLastSquish;
    m_vSquishVelocity = m_vLastSquishVelocity;
    m_matWorld        = m_matLastWorld;

    m_bWorldInvValid = FALSE; 
    m_bWorldCenterOfGravityValid = FALSE;
}

VOID CPEObject::Translate(const D3DXVECTOR3& vAmount) {
    D3DXMATRIX matTrans;
    D3DXMatrixTranslation( &matTrans, vAmount.x, vAmount.y, vAmount.z );
    D3DXMatrixMultiply( &m_matWorld, &m_matWorld, &matTrans );
    m_vPosition += vAmount;
    m_bWorldInvValid             = FALSE;
    m_bWorldCenterOfGravityValid = FALSE;
}

VOID CPEObject::Rotate(const D3DXVECTOR3& vAmount) {
    D3DXQUATERNION quat;
    D3DXQuaternionRotationYawPitchRoll( &quat, vAmount.y, vAmount.x, vAmount.z );
    Rotate(quat);
}

VOID CPEObject::Rotate(const D3DXQUATERNION& vAmount) {
    D3DXMATRIX matRotate;
    m_qRotate *= vAmount;
    D3DXMatrixRotationQuaternion(&matRotate, &vAmount);
    D3DXVec3TransformNormal( &m_vSquishVelocity, &m_vSquishVelocity, &matRotate );
    D3DXVec3TransformNormal( &m_vSquish, &m_vSquish, &matRotate );
    UpdateWorldMatrix();
}

VOID CPEObject::SetTransform( const D3DXMATRIX& matrix )
{ 
    m_matStart = matrix;
    m_vPosition = D3DXVECTOR3(0, 0, 0);
    D3DXQuaternionIdentity(&m_qRotate);
    m_matWorld = matrix;

    m_bWorldInvValid = FALSE; 
    m_bWorldCenterOfGravityValid = FALSE;
}

VOID CPEObject::SetVelocity( const D3DXVECTOR3& velocity )
{ 
    m_vLastVelocity = m_vVelocity = velocity;
}

VOID CPEObject::SetAngVelocity( const D3DXVECTOR3& velocity )
{ 
    m_vLastAngVelocity = m_vAngVelocity = velocity;
}

VOID CPEObject::SetSquishVelocity( const D3DXVECTOR3& velocity )
{ 
    m_vLastSquishVelocity = m_vSquishVelocity = velocity;
}

const D3DXMATRIX& CPEObject::GetInvWorldMatrix()
{
    if(FALSE == m_bWorldInvValid)
    {
        D3DXMatrixInverse(&m_matWorldInv, NULL, &m_matWorld);
        m_bWorldInvValid = TRUE;
    }

    return m_matWorldInv;
}

const D3DXVECTOR3& CPEObject::GetWorldCenterOfGravity()
{
    if(FALSE == m_bWorldCenterOfGravityValid)
    {
        D3DXVec3TransformCoord( &m_vWorldCenterOfGravity, &m_vCenterOfGravity, &m_matWorld);
        m_bWorldCenterOfGravityValid = TRUE;
    }

    return m_vWorldCenterOfGravity;
}
