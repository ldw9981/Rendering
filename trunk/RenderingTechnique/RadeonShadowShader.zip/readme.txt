//-----------------------------------------------------------------------------
// Name: ShadowShader Direct3D Sample
//-----------------------------------------------------------------------------

Description
===========
   The sample RadeonShadowShader uses a stencil shadow volume technique along 
   with mutlitexturing or pixel shaders for per pixel lighting, For each light 
   and object, a volume representing the shadow is calculated with a vertex 
   shader using static geometry and rendered. Since a vertex shader is doing 
   the shadow calculations, vertex shader capable hardware can offload them 
   from the CPU. Any pixels inside the volume are in shadow, and the result is 
   left in the stencil buffer. 
     
   For each light, if pixel shader version 1.4 or later is found, true per
   pixel phong shading is used to render the room including light attenuation
   and specular highlights.
   
   If pixel shaders are not found, a volumetric texture is used to calculate 
   the attenuation of the light based on distance. Diffuse and specular 
   components are calculated by dotting the tangent space normal with a light 
   or half angle vector that is interpolated and renormalized with a cubic 
   environment map. The final light color is then masked out by the result 
   of the stencil shadow volume pass creating the shadows.   

User's Guide
============
   The following keys are implemented. The dropdown menus can be used for the
   same controls.
      <Enter>      Starts and stops the scene
      <Space>      Advances the scene by a small increment
      <F2>         Prompts user to select a new rendering device or display mode
      <Alt+Enter>  Toggles between fullscreen and windowed modes
      <Esc>        Exits the app.
      <Shift+F>    Free fly mode
      <E,D,S,F>    Fly up, down, left, right. Also right drag.
      <A,Z>        Fly forward, back. Also middle Drag
      <W,R>        Roll left, right. Also left Drag
      <Arrows>     Pitch. Also Left Drag
      <Shift+S>    Toggle shadow volumes
      <V>          Toggle shadow volume visualization
      <G>          Toggle gravity
      <L>          Animate Lights
      <Shift+I>    Toggle Wireframe Mode
      <P>          Toggle Physics
      <+>          Add Ball
      <->          Delete Ball
      <*>          Add Light
      </>          Delete Light
      <0-9>        Select room's lit rendering technique.
      <Shift+0-9>  Select room's ambient rendering technique.

Note: 8-bit stencil must be enabled in the D3D tab of the display control panel.

Programming Notes
=================
   Most of the pertinent code is in the root of the project. The shadow volumes
   are managed in ShadowPOF.cpp and rendered through shadow.sha
   
   The general idea is to create a static geometry that can be modified into a 
   shadow volume from any light direction.  To do this a geometry is created 
   with all of the original faces and their face normals, and every edge is 
   changed into an invisible quad connecting the two neighboring faces. The 
   face normals are used to calculate if a face is front or back facing to the 
   light.  Back facing faces are pushed away from the light to the light's 
   range, ripping the faces on silhouette edges apart exposing the invisible 
   quad, which then forms the shadow volume. No shadow geometry needs to 
   be created per frame. There are techniques that can extend this to animated 
   geometry as well. 
   
   The floor shaders contain the examples of per pixel lighting for volumetric
   light attenuation and diffuse and specular bump mapping. See the floor shaders.

   This sample makes use of common DirectX code (consisting of helper functions,
   etc.) that is shared with other samples on the DirectX SDK. All common
   headers and source code can be found in the following directory:
      Mssdk\Samples\Multimedia\Common

