//
// CShadowPOF8
//

#ifndef __CSHADOWPOF_H
#define __CSHADOWPOF_H

#include "PofMesh.h"

// 24 bytes per vertex
typedef struct D3D_POF_SHADOW_VERTEX
{
   D3DXVECTOR3 pos;
   D3DXVECTOR3 faceNorm;
} D3D_POF_SHADOW_VERTEX;

class CShadowPOF : public CPofMesh
{
protected:
   DWORD                    m_dwNumShadowBuffers;
   IDirect3DIndexBuffer8**  m_ppShadowIndexBuffer;
   DWORD*                   m_pdwShadowIndexBufferSize;

   IDirect3DVertexBuffer8** m_ppShadowVertexBuffer;
   DWORD*                   m_pdwShadowVertexBufferSize;

   HRESULT InitializeBuffers(POF* pof);

public:
   CShadowPOF();
   ~CShadowPOF();

   void DrawShadow();
};


#endif __CSHADOWPOF_H
