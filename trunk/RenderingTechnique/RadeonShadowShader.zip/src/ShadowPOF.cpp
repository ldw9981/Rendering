//
// CShadowPOF
//
// Child class of CProteus that adds shadow volume support
//
#include <stdio.h>
#include <d3d8.h>
#include <D3DX8.h>
#include <DXUtil.h>
#include "ShadowPOF.h"
#include "pof.h"
#include "pofDefines.h"
#include "pofTypes.h"
#include "DebugOutput.h"

#define FLOAT_EQUALITY_FUDGE 0.001f
#define DEGEN_MERGE_THRESHOLD 1.0f  // >1.0 means no merging optimizations, -1.0 means no degen quads.

#pragma warning(disable:4786) // turn off warning: 'identifier was truncated to 255 characters'
#include <map>
#include <list>
#include <vector>

CShadowPOF::CShadowPOF()
{
   m_dwNumShadowBuffers = 0;
   m_ppShadowIndexBuffer=NULL;
   m_ppShadowVertexBuffer=NULL;
   m_pdwShadowIndexBufferSize=NULL;
   m_pdwShadowVertexBufferSize=NULL;
   m_bOptimizeMesh = TRUE;
}


CShadowPOF::~CShadowPOF()
{
   for (int i = 0; i < m_dwNumShadowBuffers; i++)
   {
      SAFE_RELEASE( m_ppShadowIndexBuffer[i] );
      SAFE_RELEASE( m_ppShadowVertexBuffer[i] );
   }
   SAFE_DELETE( m_ppShadowIndexBuffer );
   SAFE_DELETE( m_ppShadowVertexBuffer );
   SAFE_DELETE( m_pdwShadowIndexBufferSize );
   SAFE_DELETE( m_pdwShadowVertexBufferSize );
}

inline bool operator < (const D3DXVECTOR3& lhs, const D3DXVECTOR3& rhs)
{
   D3DXVECTOR3 d = lhs - rhs;
   const FLOAT f = FLOAT_EQUALITY_FUDGE;
   if (d.x < -f) return true;
   if (d.x > f) return false;
   if (d.y < -f) return true;
   if (d.y > f) return false;
   if (d.z < -f) return true;
   return false;
}

inline bool operator > (const D3DXVECTOR3& lhs, const D3DXVECTOR3& rhs)
{
   if (lhs == rhs) return false;
   return !(lhs < rhs);
}

class ShadowEdgePositions {
public:
   D3DXVECTOR3 p0, p1;

   bool operator == (const ShadowEdgePositions& rhs) const
   {
      return (rhs.p0 == p1 && rhs.p1 == p0);
   }
   bool operator < (const ShadowEdgePositions& rhs) const
   {
      if (p0 < rhs.p0) return true;
      if (p0 > rhs.p0) return false;
      if (p1 < rhs.p1) return true;
      return false;
   }
};

class ShadowEdgeData {
public:
   D3DXVECTOR3 n0, n1;
   WORD i0, i1;
   WORD buffer;
};

typedef std::pair<ShadowEdgePositions, ShadowEdgeData> ShadowEdge;
typedef std::map<ShadowEdgePositions, ShadowEdgeData> EdgeMap;


// The general idea is to create a static geometry that can be modified into a shadow volume
// from any light direction.  To do this a geometry is created with all of the original faces
// and their face normals, and every edge is changed into an invisible quad connecting the two
// neighboring faces. The face normals are used to calculate if a face is front or back facing
// to the light.  Back facing faces are pushed away from the light to the light's range,
// ripping the faces on silhouette edges apart exposing the invisible quad, which then forms
// the shadow volume.
HRESULT CShadowPOF::InitializeBuffers(POF* pof)
{
   CPofMesh::InitializeBuffers(pof);

   POFFaceChunk     face;
   POFVertexChunk   vtx;
   POFNormalChunk   norm;
   DWORD *indices;
   DWORD listIdx, faceIdx, vtxIdx, edgeIdx;
   DWORD totalSourceVerts = 0;
   DWORD totalShadowVerts = 0;
   DWORD* pVtxRemap;

   D3DXVECTOR3* verts;
   D3DXVECTOR3* norms;
   
   EdgeMap edges;
   EdgeMap::iterator edgeIter;
   DWORD savedEdges = 0;

   // Allocate memory for the geometry lists.
   m_pdwShadowIndexBufferSize = new DWORD[m_numFaceLists];
   m_pdwShadowVertexBufferSize = new DWORD[m_numFaceLists];
   m_ppShadowIndexBuffer = new IDirect3DIndexBuffer8*[m_numFaceLists];
   m_ppShadowVertexBuffer = new IDirect3DVertexBuffer8*[m_numFaceLists];
   m_dwNumShadowBuffers = m_numFaceLists;

   std::vector<D3D_POF_SHADOW_VERTEX>* shadowVerts = new std::vector<D3D_POF_SHADOW_VERTEX>[m_numFaceLists];
   std::vector<WORD>* shadowIndices = new std::vector<WORD>[m_numFaceLists];

   // Step through all face lists to find edges and create degenerate quads.
   for (listIdx=0; listIdx < m_numFaceLists; listIdx++)
   {
      // Get D3D mesh optimization remap information
      if (m_VtxRemap[listIdx])
         pVtxRemap = (DWORD*)m_VtxRemap[listIdx]->GetBufferPointer();
      else
         pVtxRemap = NULL;

      // Get the face lists from the POF file
      indices = (DWORD*)pofGetFaceList(pof, pofGetObjectNames(pof, POF_TYPE_FACE)[listIdx], &face);
      verts = (D3DXVECTOR3 *) pofGetVertexList(pof, face.coordSet, 0, &vtx);
      norms = (D3DXVECTOR3 *) pofGetNormalList(pof, face.coordSet, 0, &norm);
      totalSourceVerts += vtx.count;

      // Step through all faces in list
      for(faceIdx=0; faceIdx < face.count; faceIdx++)
      {
         // Calculate face normal
         D3DXVECTOR3 faceNorm;
         if (pVtxRemap)
             D3DXVec3Cross( &faceNorm, &(verts[pVtxRemap[indices[faceIdx*3+1]]] - verts[pVtxRemap[indices[faceIdx*3]]]), 
                                       &(verts[pVtxRemap[indices[faceIdx*3+2]]] - verts[pVtxRemap[indices[faceIdx*3]]]) );
         else
             D3DXVec3Cross( &faceNorm, &(verts[indices[faceIdx*3+1]] - verts[indices[faceIdx*3]]), 
                                       &(verts[indices[faceIdx*3+2]] - verts[indices[faceIdx*3]]) );
         D3DXVec3Normalize(&faceNorm, &faceNorm);

         // Create the vertices for the face
         D3D_POF_SHADOW_VERTEX shadowVert[3];
         for (vtxIdx = 0; vtxIdx < 3; vtxIdx++)
         {
             if (pVtxRemap)
                shadowVert[vtxIdx].pos = verts[pVtxRemap[indices[faceIdx*3+vtxIdx]]];
             else
                shadowVert[vtxIdx].pos = verts[indices[faceIdx*3+vtxIdx]];
             shadowVert[vtxIdx].faceNorm = faceNorm;
         }

         // Create and search edges to see which edges have a partner
         ShadowEdgePositions edgePos[3];
         ShadowEdgeData sharedEdgeDat[3];
         BOOL sharedEdgeFound[3];
         BOOL insertQuad[3];
         for (edgeIdx = 0; edgeIdx < 3; edgeIdx++)
         {
            edgePos[edgeIdx].p0 = shadowVert[edgeIdx].pos;
            edgePos[edgeIdx].p1 = shadowVert[(edgeIdx+1)%3].pos;
            ShadowEdgePositions edgePosFind;
            edgePosFind.p0 = edgePos[edgeIdx].p1;
            edgePosFind.p1 = edgePos[edgeIdx].p0;
            edgeIter = edges.find(edgePosFind);
            // If a matching edge is found, mark it as found and add it to the list of up to 3 edges for this face.
            if (edgeIter != edges.end())
            {
               sharedEdgeDat[edgeIdx] = edgeIter->second;
               sharedEdgeFound[edgeIdx] = TRUE;
               edges.erase(edgeIter);

               // If edge has a partner, see if it can be optimized away.
               insertQuad[edgeIdx] = (D3DXVec3Dot(&faceNorm, &sharedEdgeDat[edgeIdx].n0) < DEGEN_MERGE_THRESHOLD);
               if (insertQuad[edgeIdx] == FALSE) {
                  savedEdges++;
               }

               // if these verts come from a different buffer, they must be recreated in this one
               if (sharedEdgeDat[edgeIdx].buffer != listIdx)
               {
                  shadowVerts[listIdx].push_back(shadowVerts[sharedEdgeDat[edgeIdx].buffer][sharedEdgeDat[edgeIdx].i0]);
                  shadowVerts[listIdx].push_back(shadowVerts[sharedEdgeDat[edgeIdx].buffer][sharedEdgeDat[edgeIdx].i1]);
                  sharedEdgeDat[edgeIdx].i0 = shadowVerts[listIdx].size()-2;
                  sharedEdgeDat[edgeIdx].i1 = shadowVerts[listIdx].size()-1;
                  sharedEdgeDat[edgeIdx].buffer = listIdx;
               }

            }
            else
               sharedEdgeFound[edgeIdx] = FALSE;
         }

         // Figure out which vertices need to be created, and which are shared
         DWORD index[3];
         for (vtxIdx = 0; vtxIdx < 3; vtxIdx++)
         {
            // find two neighboring edges to this vertex.
            edgeIdx = vtxIdx;
            DWORD edgeIdx2 = (edgeIdx+2)%3;
            if (sharedEdgeFound[edgeIdx] == TRUE && insertQuad[edgeIdx] == FALSE)
            {
               // if the other side of the edge on one side is already found, and it is optimized away 
               // because it is coplanar, no extra vertex is needed. Just copy the index from the other face.
               index[vtxIdx] = sharedEdgeDat[edgeIdx].i1;
            } else if (sharedEdgeFound[edgeIdx2] == TRUE && insertQuad[edgeIdx2] == FALSE) {
               // if the other side of the other edge is already found, and it is optimized away 
               // because it is coplanar, no extra vertex is needed. Just copy the index from the other face.
               index[vtxIdx] = sharedEdgeDat[edgeIdx2].i0;
            } else {
               // insert a new vertex to go with this face because it is a new vertex, or it needs an invisible quad inserted.
               index[vtxIdx] = shadowVerts[listIdx].size();
               shadowVerts[listIdx].push_back(shadowVert[vtxIdx]);
            }
         }

         // Insert Face into index list
         for (vtxIdx = 0; vtxIdx < 3; vtxIdx++)
            shadowIndices[listIdx].push_back(index[vtxIdx]);

         // Insert invisible tris and quads into index list.
         for (edgeIdx = 0; edgeIdx < 3; edgeIdx++)
         {
            ShadowEdgeData edgeDat;
            edgeDat.i0 = index[edgeIdx];
            edgeDat.i1 = index[(edgeIdx+1)%3];
            edgeDat.buffer = listIdx;
            edgeDat.n0 = faceNorm;
            if (sharedEdgeFound[edgeIdx] == FALSE)
            {
               edges[edgePos[edgeIdx]] = edgeDat;
            }
            else
            {
               if (sharedEdgeDat[edgeIdx].i1 != edgeDat.i0 && sharedEdgeDat[edgeIdx].i0 != edgeDat.i1)
               {
                  // insert quad
                  shadowIndices[listIdx].push_back(edgeDat.i1);
                  shadowIndices[listIdx].push_back(edgeDat.i0);
                  shadowIndices[listIdx].push_back(sharedEdgeDat[edgeIdx].i0);

                  shadowIndices[listIdx].push_back(sharedEdgeDat[edgeIdx].i1);
                  shadowIndices[listIdx].push_back(sharedEdgeDat[edgeIdx].i0);
                  shadowIndices[listIdx].push_back(edgeDat.i0);
               } 
               else if (sharedEdgeDat[edgeIdx].i1 != edgeDat.i0)
               {
                  // insert tri collapsed on one side.
                  shadowIndices[listIdx].push_back(edgeDat.i1);
                  shadowIndices[listIdx].push_back(edgeDat.i0);
                  shadowIndices[listIdx].push_back(sharedEdgeDat[edgeIdx].i1);
               }
               else if (sharedEdgeDat[edgeIdx].i0 != edgeDat.i1)
               {
                  // insert tri collasped on the other side.
                  shadowIndices[listIdx].push_back(edgeDat.i1);
                  shadowIndices[listIdx].push_back(edgeDat.i0);
                  shadowIndices[listIdx].push_back(sharedEdgeDat[edgeIdx].i0);
               }
            }
         }
      }
   }

   // Create vertex and index buffers from calculated lists.
   for (listIdx=0; listIdx < m_numFaceLists; listIdx++)
   {
      if (shadowIndices[listIdx].size() >= 0x10000)
         OutputDebugString("Shadow Volume exceeded 0x10000 indices.\n");
      if (shadowVerts[listIdx].size() >= 0x10000)
         OutputDebugString("Shadow Volume exceeded 0x10000 vertices.\n");

      m_pdwShadowIndexBufferSize[listIdx] = shadowIndices[listIdx].size();
      m_pdwShadowVertexBufferSize[listIdx] = shadowVerts[listIdx].size();

      totalShadowVerts += m_pdwShadowVertexBufferSize[listIdx];

      // Create index buffer
      if( FAILED( m_pd3dDevice->CreateIndexBuffer( m_pdwShadowIndexBufferSize[listIdx]*sizeof(WORD), 
          POFMESH_INDEX_BUFFER_USAGE, D3DFMT_INDEX16, POFMESH_INDEX_BUFFER_POOL, &m_ppShadowIndexBuffer[listIdx] ) ) )
      {
         OutputDebugString("Unable to create index buffer\n");
         return E_FAIL;
      }

      // Lock index buffer and fill with data
      WORD* pIndex;
      std::vector<WORD>::iterator indexIter;
      m_ppShadowIndexBuffer[listIdx]->Lock( 0, m_pdwShadowIndexBufferSize[listIdx]*sizeof(WORD), (BYTE**)&pIndex, 0);
      for (indexIter = shadowIndices[listIdx].begin(), faceIdx=0; indexIter != shadowIndices[listIdx].end(); ++indexIter, faceIdx++)
      {
         pIndex[faceIdx] = *indexIter;
      }
      m_ppShadowIndexBuffer[listIdx]->Unlock();

      // Create vertex buffer
      if( FAILED( m_pd3dDevice->CreateVertexBuffer( m_pdwShadowVertexBufferSize[listIdx]*sizeof(D3D_POF_SHADOW_VERTEX), 
         POFMESH_BUFFER_USAGE, 0, POFMESH_BUFFER_POOL, &m_ppShadowVertexBuffer[listIdx] ) ) )
      {
         OutputDebugString("Unable to create vertex buffer\n");
         return E_FAIL;
      }

      // Lock vertex buffer and fill with data
      D3D_POF_SHADOW_VERTEX* pVertex;
      std::vector<D3D_POF_SHADOW_VERTEX>::iterator vertexIter;
      m_ppShadowVertexBuffer[listIdx]->Lock( 0, m_pdwShadowVertexBufferSize[listIdx]*sizeof(D3D_POF_SHADOW_VERTEX), (BYTE**)&pVertex, 0);
      for (vertexIter = shadowVerts[listIdx].begin(), faceIdx=0; vertexIter != shadowVerts[listIdx].end(); ++vertexIter, faceIdx++)
      {
         pVertex[faceIdx] = *vertexIter;
      }
      m_ppShadowVertexBuffer[listIdx]->Unlock();
   }

   DebugPrintf("Collapsed %d edges because they won't often be silhoette edges\n", savedEdges);
   DebugPrintf("%d source vertices expanded to %d shadow verticies\n", totalSourceVerts, totalShadowVerts);

   if (edges.size() > 0)
   {
      OutputDebugString("Warning: geometry is not a closed volume.\n");
      for (edgeIter = edges.begin(), listIdx=0; edgeIter != edges.end(); ++edgeIter, listIdx++)
      {
         ShadowEdgePositions edgePos;
         edgePos = edgeIter->first;
      }
   }

   delete [] shadowVerts;
   delete [] shadowIndices;

   return S_OK;
}



void CShadowPOF::DrawShadow()
{
   for (int i = 0; i < m_dwNumShadowBuffers; i++)
   {
      m_pd3dDevice->SetStreamSource( 0, m_ppShadowVertexBuffer[i], sizeof(D3D_POF_SHADOW_VERTEX) );
      m_pd3dDevice->SetIndices( m_ppShadowIndexBuffer[i], 0);
      m_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, m_pdwShadowVertexBufferSize[i], 0, (UINT)(m_pdwShadowIndexBufferSize[i]/3));
   }
}
