// 0908.cpp : ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include "0908.h"


// D3D ���̺귯��,��� �߰�
#pragma comment(lib, "D3d9.lib") 
#pragma comment(lib, "D3dx9.lib") 
#include <D3D9.h>
#include <d3dx9math.h>
#include <D3DX9Shader.h>

#define _USE_VERTEXSHADER 1


#define MAX_LOADSTRING 100

#define DIR_LEFT	0
#define DIR_RIGHT	1
#define DIR_UP		2
#define DIR_DOWN	3


// ���� ����:
HINSTANCE hInst;								// ���� �ν��Ͻ��Դϴ�.
HWND	  g_hWnd;
TCHAR szTitle[MAX_LOADSTRING];					// ���� ǥ���� �ؽ�Ʈ�Դϴ�.
TCHAR szWindowClass[MAX_LOADSTRING];			// �⺻ â Ŭ���� �̸��Դϴ�.



// �� �ڵ� ��⿡ ��� �ִ� �Լ��� ������ �����Դϴ�.
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

// D3D �����߰�
LPDIRECT3D9 g_pD3D = NULL;
LPDIRECT3DDEVICE9 g_pD3DDevice9 = NULL;
LPDIRECT3DVERTEXBUFFER9 g_pVB = NULL; 
LPDIRECT3DVERTEXSHADER9 g_pVertexShader = NULL;
LPDIRECT3DTEXTURE9		g_pTexture=NULL;



// Custom D3D vertex format used by the vertex buffer
struct CUSTOMVERTEX
{	
	float		x; // ��ġ����(x, y, z)
	float		y; // ��ġ����(x, y, z)
	float		z; // ��ġ����(x, y, z)

	float		nx;
	float		ny;
	float		nz;

	float		tu;
	float		tv;	
};
// �� Ÿ���� �����ϴ�, FVF(Flexible Vertex Type) ����
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)  


CUSTOMVERTEX g_Vertices[]=
{	
	{  0.4f,  0.5f,0.5f ,	0.0f, 0.0f,-1.0f,   0.0f,0.0f	},
	{  0.3f, -0.5f,0.5f ,	0.0f, 0.0f,-1.0f,   0.0f,1.0f	},
	{ -0.4f, -0.4f,0.5f ,	0.0f, 0.0f,-1.0f,   1.0f,1.0f	},

	{ -0.6f, 0.5f,0.5f	,	0.0f, 0.0f,-1.0f,   1.0f,0.0f	},
	{  0.4f, 0.5f,0.5f	,	0.0f, 0.0f,-1.0f,   0.0f,0.0f	},
	{ -0.4f,-0.4f,0.5f ,	0.0f, 0.0f,-1.0f,   1.0f,1.0f	}	
};

D3DMATERIAL9 g_mtrl;	
D3DLIGHT9 g_light;




// D3D �ʱ�ȭ�Լ� 
void				InitD3D(HWND hWnd);

void				InitVB();
void				Render();
void				MoveVertex(int dir);
BOOL				LoadShader(LPCTSTR p_ShaderFileName);
BOOL				LoadTexture(LPCTSTR TextureFile);
void				SetupLight();

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO: ���⿡ �ڵ带 �Է��մϴ�.
	MSG msg;


	// ���� ���ڿ��� �ʱ�ȭ�մϴ�.
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_MY0908, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// ���� ���α׷� �ʱ�ȭ�� �����մϴ�.
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}
	InitD3D(g_hWnd);

	
	if(!LoadShader(L"basic.vs"))
		return FALSE;
	if(!LoadTexture(L"Ǫ�����.jpg"))
		return FALSE;

	InitVB();


	// �⺻ �޽��� �����Դϴ�.
	while (GetMessage(&msg, NULL, 0, 0))
	{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
	
			Render();
	}

	return (int) msg.wParam;
}


ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MY0908));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // �ν��Ͻ� �ڵ��� ���� ������ �����մϴ�.

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   g_hWnd=hWnd;
   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{
	case WM_COMMAND:
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: ���⿡ �׸��� �ڵ带 �߰��մϴ�.
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_KEYDOWN:	
		switch(wParam)
		{
		case VK_LEFT:
			MoveVertex(DIR_LEFT);
			break;
		case VK_RIGHT:
			MoveVertex(DIR_RIGHT);
			break;
		case VK_UP:
			MoveVertex(DIR_UP);
		    break;
		case VK_DOWN:
			MoveVertex(DIR_DOWN);
		    break;		
		}
		break;
	

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}
//---------------------------------------------
// Name: InitD3D()
// Desc: Initializes Direct3D
//---------------------------------------------
void InitD3D( HWND hWnd )
{
	// 1) D3D�� �����Ѵ�.
	g_pD3D = Direct3DCreate9( D3D_SDK_VERSION );

	// 2) Device�� ������ ���� Parameter�� �����Ѵ�.
	D3DPRESENT_PARAMETERS d3dpp; 
	ZeroMemory(&d3dpp, sizeof(d3dpp));

	d3dpp.Windowed	 = TRUE;
	d3dpp.SwapEffect	 = D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferFormat	 = D3DFMT_UNKNOWN;

	// 3) Device�� �����Ѵ�.
	g_pD3D->CreateDevice( 
		D3DADAPTER_DEFAULT, 
		D3DDEVTYPE_HAL, 
		hWnd,
		D3DCREATE_SOFTWARE_VERTEXPROCESSING,
		&d3dpp, 
		&g_pD3DDevice9 );

	SetupLight();

}


void Render()
{
	// 1) Render Target�� �����.
	g_pD3DDevice9->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,255), 1.0f, 0 );

	// 2) Begin the scene
	if( SUCCEEDED( g_pD3DDevice9->BeginScene() ) )
	{
		D3DXMATRIX tmWorld,tmView,tmProjection,tmViewProjection;
		D3DXMatrixIdentity(&tmWorld);
		D3DXMatrixIdentity(&tmView);
		D3DXMatrixIdentity(&tmProjection);
		D3DXMatrixMultiply(&tmViewProjection,&tmView,&tmProjection);

		g_pD3DDevice9->SetTexture(0,g_pTexture);


	
		g_pD3DDevice9->SetTransform (D3DTS_WORLD, &tmWorld );
		g_pD3DDevice9->SetTransform (D3DTS_VIEW, &tmView );
		g_pD3DDevice9->SetTransform (D3DTS_PROJECTION, &tmProjection );
	
		/*
		// 1) SetTransform�� SetVertexShaderConstant�� �ٲ�
		D3DXMATRIX	tempMatrix[2];
		D3DXMatrixTranspose(&tempMatrix[0], &tmWorld);
		D3DXMatrixTranspose(&tempMatrix[1], &tmViewProjection);
		g_pD3DDevice9->SetVertexShaderConstantF( 4, (float*)tempMatrix, 8);

		// 2) SetLight�� SetVertexShaderConstant�� �ٲ�
		g_pD3DDevice9->SetVertexShaderConstantF( 218, (float*) &g_mtrl.Diffuse,1);			// diffuse
		g_pD3DDevice9->SetVertexShaderConstantF( 219, (float*) &g_light.Direction,1);		// direction
		g_pD3DDevice9->SetVertexShaderConstantF( 220, (float*) &g_mtrl.Ambient,1);			// ambiant

		// 3) VertexShader�� ����
		g_pD3DDevice9->SetVertexShader(g_pVertexShader);
		*/
		


		// 3) Draw Primitive�Ѵ�.		
		g_pD3DDevice9->SetStreamSource( 0, g_pVB, 0,  sizeof(CUSTOMVERTEX) );
		g_pD3DDevice9->SetFVF(D3DFVF_CUSTOMVERTEX);
		g_pD3DDevice9->DrawPrimitive( D3DPT_TRIANGLELIST, 0, 2 );
		



		// 4) End the scene
		g_pD3DDevice9->EndScene();
	}

	// 5) Present�Ѵ�.
	g_pD3DDevice9->Present( NULL, NULL, NULL, NULL );
}

VOID InitVB()
{
	// 1) FVF�� �����ؼ� �ʿ���ũ�⸸ŭ VertexBuffer�� �����.
	g_pD3DDevice9->CreateVertexBuffer( 
		6*sizeof(CUSTOMVERTEX),
		0,
		D3DFVF_CUSTOMVERTEX,
		D3DPOOL_DEFAULT,
		&g_pVB,
		NULL);


	// 2) ������ Vertex Buffer�� Lock()�ؼ� ������ ��ִ´�.
	VOID* pVertices;
	g_pVB->Lock( 0, sizeof(g_Vertices), (void**)&pVertices, 0 );
	memcpy(pVertices,g_Vertices,sizeof(g_Vertices));
	g_pVB->Unlock();
}

void MoveVertex( int dir )
{
	float deltaX=0.0f;
	float deltaY=0.0f;

	switch(dir)
	{
	case DIR_LEFT:
		deltaX= -0.01f;
		break;
	case DIR_RIGHT:
		deltaX= 0.01f;
		break;
	case DIR_UP:
		deltaY= 0.01f;
	    break;
	case DIR_DOWN:
		deltaY= -0.01f;
	    break;

	}

	CUSTOMVERTEX* pVertices=NULL;
	g_pVB->Lock( 0, sizeof(g_Vertices), (void**)&pVertices, 0 );
	for (int i=0;i<3;i++)
	{
		pVertices[i].x+=deltaX;
		pVertices[i].y+=deltaY;
	}
	g_pVB->Unlock();
}

BOOL  LoadShader(LPCTSTR p_ShaderFileName)
{
	LPD3DXBUFFER        pCode;
	LPD3DXBUFFER        pError;

	if(D3DXAssembleShaderFromFile(p_ShaderFileName, NULL, NULL, D3DXSHADER_DEBUG, &pCode, &pError) != D3D_OK)
	{
		OutputDebugString((LPCWSTR)pError->GetBufferPointer());
		MessageBoxW(NULL,(LPCWSTR)pError->GetBufferPointer(),MB_OK,0);
		return	FALSE;
	}

	if(g_pD3DDevice9->CreateVertexShader((DWORD*)pCode->GetBufferPointer(), &g_pVertexShader) != D3D_OK)
	{
		return	FALSE;
	}
	return TRUE;
}

BOOL LoadTexture( LPCTSTR TextureFile )
{
	HRESULT hResult=D3DXCreateTextureFromFile(g_pD3DDevice9,TextureFile,&g_pTexture);
	if (!SUCCEEDED(hResult))
		return FALSE;
	return TRUE;
}

void SetupLight()
{
	
	ZeroMemory(&g_mtrl,sizeof(D3DMATERIAL9));
	g_mtrl.Diffuse.r = 1.0f;
	g_mtrl.Diffuse.g = 1.0f;
	g_mtrl.Diffuse.b = 1.0f;
	g_mtrl.Diffuse.a = 1.0f;

	g_mtrl.Ambient.r = 1.0f;
	g_mtrl.Ambient.g = 1.0f;
	g_mtrl.Ambient.b = 1.0f;
	g_mtrl.Ambient.a = 1.0f;
	g_pD3DDevice9->SetMaterial(&g_mtrl);


	ZeroMemory(&g_light,sizeof(D3DLIGHT9));
	g_light.Type	=	D3DLIGHT_DIRECTIONAL;

	g_light.Diffuse.r = 1.0f;
	g_light.Diffuse.g = 1.0f;
	g_light.Diffuse.b = 1.0f;
	g_light.Diffuse.a = 1.0f;

	g_light.Direction = D3DXVECTOR3(0.0f,0.0f,1.0f);		// Ÿ�� ����
	//	light.Range = 1000.0f;

	g_pD3DDevice9->SetLight(0,&g_light);
	g_pD3DDevice9->LightEnable(0,TRUE);
	g_pD3DDevice9->SetRenderState(D3DRS_LIGHTING,TRUE);
//	g_pD3DDevice9->SetRenderState(D3DRS_AMBIENT,0x00202020);
}