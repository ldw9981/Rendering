//-----------------------------------------------------------------------------
// Camera
// 
// A Fly Path Object with a few twists of being a camera and adds keyboard controls
// Also has some frustum cull helper functions.
//
//    Chris Brennan - ATI Research, Inc. - 2001
//-----------------------------------------------------------------------------
#include "Camera.h"
#include "dxutil.h"
#include "resource.h"

// -------------------------------------------------------------------------
// UI structures
typedef enum _MOTIONDIRECTIONS {
    DIR_Up = 0,
    DIR_Down,
    DIR_Left,
    DIR_Right,
    DIR_Forward,
    DIR_Backward,
    DIR_PitchUp,
    DIR_PitchDown,
    DIR_PitchLeft,
    DIR_PitchRight,
    DIR_RollLeft,
    DIR_RollRight,
    DIR_NumDirections
} MotionDirection;

struct { 
    MotionDirection dir;
    char key;
} s_KeyControls[DIR_NumDirections] = 
    {
        { DIR_Up,         'E'},
        { DIR_Down,       'D'},
        { DIR_Left,       'S'},
        { DIR_Right,      'F'},
        { DIR_Forward,    'A'},
        { DIR_Backward,   'Z'},
        { DIR_PitchUp,    VK_DOWN},
        { DIR_PitchDown,  VK_UP},
        { DIR_PitchLeft,  VK_LEFT},
        { DIR_PitchRight, VK_RIGHT},
        { DIR_RollLeft,   'W'},
        { DIR_RollRight,  'R'}
     };
// -------------------------------------------------------------------------

CCamera::CCamera()
{
    m_fMass = 1.0f;
    m_fAirResistance = 4.0f;
    m_fAngAirResistance = 4.0f;
    m_bGotFocus = TRUE;
}

const D3DXMATRIX& CCamera::GetViewTransform() 
{
    return GetInvWorldMatrix();
}

void CCamera::Advance(FLOAT fElapsedTime) 
{
    CFlyPathPEObject::Advance(fElapsedTime);

    if (!m_bGotFocus)
        return;

    if (m_pFlyPath && m_bAutoFlying)
        return;

    // Camera keyboard motion
    m_vObjForce = D3DXVECTOR3(0,0,0);
    m_vObjAngForce = D3DXVECTOR3(0,0,0);
    for (int i = 0; i < DIR_NumDirections; i++)
    {
        if (!(GetKeyState(VK_CONTROL) & 0x8000) && 
            !(GetKeyState(VK_SHIFT) & 0x8000) && 
            !(GetKeyState(VK_MENU) & 0x8000) &&
             (GetKeyState(s_KeyControls[i].key) & 0x8000))
        {
            switch (s_KeyControls[i].dir)
            {
            case DIR_Up:         m_vObjForce += D3DXVECTOR3( 0, 1, 0);  break;
            case DIR_Down:       m_vObjForce += D3DXVECTOR3( 0,-1, 0);  break;
            case DIR_Left:       m_vObjForce += D3DXVECTOR3(-1, 0, 0);  break;
            case DIR_Right:      m_vObjForce += D3DXVECTOR3( 1, 0, 0);  break;
            case DIR_Forward:    m_vObjForce += D3DXVECTOR3( 0, 0, 1);  break;
            case DIR_Backward:   m_vObjForce += D3DXVECTOR3( 0, 0,-1);  break;
            case DIR_PitchLeft:  m_vObjAngForce += D3DXVECTOR3( 0,-1, 0);  break;
            case DIR_PitchRight: m_vObjAngForce += D3DXVECTOR3( 0, 1, 0);  break;
            case DIR_PitchUp:    m_vObjAngForce += D3DXVECTOR3(-1, 0, 0);  break;
            case DIR_PitchDown:  m_vObjAngForce += D3DXVECTOR3( 1, 0, 0);  break;
            case DIR_RollLeft:   m_vObjAngForce += D3DXVECTOR3( 0, 0, 2);  break;
            case DIR_RollRight:  m_vObjAngForce += D3DXVECTOR3( 0, 0,-2);  break;
            }
        }
    }

    m_vObjForce *= 50;
    m_vObjAngForce *= 5;

    D3DXVECTOR3 vGravitySave = CPEObject::m_svGravity;
    CPEObject::m_svGravity = D3DXVECTOR3( 0, 0, 0 );
    while (fElapsedTime > 0)
    {
        CPEObject::Advance( min(fElapsedTime, 1/30.0f) );
        fElapsedTime -= min(fElapsedTime, 1/30.0f);
    }
    CPEObject::m_svGravity = vGravitySave;
}

//-----------------------------------------------------------------------------
// Transform matrix for mouse motion UI. 
//-----------------------------------------------------------------------------
const D3DXMATRIX& CCamera::GetMouseMotionTransform()
{
    static D3DXMATRIX mat;
    D3DXMatrixScaling(&mat, -4, 4, 10);
    D3DXMatrixMultiply(&mat, &mat, &m_matWorld);
    return mat;
}

D3DXVECTOR3 CCamera::GetMouseRotationSpeed()
{
    return D3DXVECTOR3(.4f, .4f, 0.8f);
}


//========================================================================================================================================================
static D3DXVECTOR3 sgFrustumCorners[8];
static D3DXPLANE   sgFrustumPlanes[6];

void CalculateFrustumPlanes (const D3DXVECTOR3& cameraPos, const D3DXMATRIX& matView, FLOAT perspectiveAngle, FLOAT aspect, FLOAT nearPlane, FLOAT farPlane)
{
   int i;
   FLOAT tmpf;
   FLOAT tmpf2;
   FLOAT distance;

   D3DXVECTOR3 tmpVec1;
   D3DXVECTOR3 tmpVec2;

   D3DXVECTOR3 sideVec;
   D3DXVECTOR3 upVec;
   D3DXVECTOR3 viewVec;

   /********************/
   /* Get view vectors */
   /********************/
   sideVec.x = matView.m[0][0];
   sideVec.y = matView.m[1][0];
   sideVec.z = matView.m[2][0];

   upVec.x = matView.m[0][1];
   upVec.y = matView.m[1][1];
   upVec.z = matView.m[2][1];

   viewVec.x = matView.m[0][2];
   viewVec.y = matView.m[1][2];
   viewVec.z = matView.m[2][2];

   /********************************************/
   /* Calculate 8 points on corners of frustum */
   /********************************************/
   for (i=0; i<8; i++)
   {
      //0 - Near bottom right
      //1 - Near bottom left
      //2 - Near top right
      //3 - Near top left
      //4 - Far bottom right
      //5 - Far bottom left
      //6 - Far top right
      //7 - Far top left

      if (i < 4)
         distance = nearPlane; // Near clip plane
      else
         distance = farPlane;  // Far clip plane

      sgFrustumCorners[i].x = cameraPos.x + (distance*viewVec.x);
      sgFrustumCorners[i].y = cameraPos.y + (distance*viewVec.y);
      sgFrustumCorners[i].z = cameraPos.z + (distance*viewVec.z);

      tmpf = distance * tanf((perspectiveAngle*0.5f)*D3DX_PI/180.0f);
      tmpf2 = (i&0x2) ? tmpf : -tmpf;
      sgFrustumCorners[i].x += upVec.x * tmpf2;
      sgFrustumCorners[i].y += upVec.y * tmpf2;
      sgFrustumCorners[i].z += upVec.z * tmpf2;

      tmpf2 = (i&0x1) ? -tmpf : tmpf;
      sgFrustumCorners[i].x += sideVec.x * tmpf2 * aspect;
      sgFrustumCorners[i].y += sideVec.y * tmpf2 * aspect;
      sgFrustumCorners[i].z += sideVec.z * tmpf2 * aspect;
   }

   /****************************/
   /* Calculate frustum planes */
   /****************************/
   //Near plane
   D3DXPlaneFromPoints(&sgFrustumPlanes[0], &sgFrustumCorners[0], &sgFrustumCorners[1], &sgFrustumCorners[2]);

   //Far plane
   D3DXPlaneFromPoints(&sgFrustumPlanes[1], &sgFrustumCorners[4], &sgFrustumCorners[6], &sgFrustumCorners[5]);

   //Left
   D3DXPlaneFromPoints(&sgFrustumPlanes[2], &sgFrustumCorners[5], &sgFrustumCorners[7], &sgFrustumCorners[1]);

   //Right
   D3DXPlaneFromPoints(&sgFrustumPlanes[3], &sgFrustumCorners[4], &sgFrustumCorners[0], &sgFrustumCorners[6]);

   //Bottom
   D3DXPlaneFromPoints(&sgFrustumPlanes[4], &sgFrustumCorners[4], &sgFrustumCorners[5], &sgFrustumCorners[0]);

   //Top
   D3DXPlaneFromPoints(&sgFrustumPlanes[5], &sgFrustumCorners[6], &sgFrustumCorners[2], &sgFrustumCorners[7]);
}

//========================================================================================================================================================
BOOL IsBoundingSphereInFrustum (FLOAT radius, const D3DXVECTOR3& center)
{
   int i;
   FLOAT tmpf;

   for (i=0; i<6; i++) //For each frustum plane
   {
      tmpf = (center.x*sgFrustumPlanes[i].a) + (center.y*sgFrustumPlanes[i].b) + (center.z*sgFrustumPlanes[i].c) + (sgFrustumPlanes[i].d);
      if (tmpf > radius) //If on back side
      {
         return FALSE;
      }
   }

   return TRUE;
}

